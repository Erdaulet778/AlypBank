import React from 'react';

export interface NavItem {
  icon: React.ReactNode;
  label: string;
  id: string;
}

export interface Service {
  id: string;
  icon: React.ReactElement;
  title: string;
  description: string;
  link: string;
  color: string;
  features?: string[];
}

export interface Achievement {
  icon: string;
  number: string;
  label: string;
  description: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export interface Notification {
  id: string;
  type: 'payment' | 'shop' | 'news' | 'system';
  title: string;
  message: string;
  date: string;
  read: boolean;
  amount?: string;
  status?: 'ordered' | 'shipped' | 'customs' | 'delivered';
}

export type ViewState = 'home' | 'login' | 'register' | 'dashboard' | 'settings' | 'magazin' | 'bank' | 'tolemder' | 'audarimdar' | 'messages';

export type Language = 'kk' | 'ru' | 'en';