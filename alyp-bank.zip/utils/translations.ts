import { Language } from '../types';

export const translations = {
  kk: {
    sidebar: {
      home: "Басты бет",
      dashboard: "Жеке кабинет",
      magazin: "Магазин",
      bank: "Менің банкім",
      tolemder: "Төлемдер",
      audarimdar: "Аударымдар",
      messages: "Хабарламалар",
      settings: "Баптаулар",
      profile: "Профиль",
      logout: "Шығу",
      login: "Кіру",
      search: "Іздеу..."
    },
    auth: {
      loginTitle: "Қош келдіңіз!",
      registerTitle: "Тіркелу",
      loginSubtitle: "Жалғастыру үшін жеке кабинетіңізге кіріңіз",
      registerSubtitle: "Алып Банк отбасының мүшесі болыңыз",
      name: "Аты-жөніңіз",
      email: "Email",
      password: "Құпия сөз",
      confirmPassword: "Құпия сөзді қайталау",
      passwordHint: "Кемінде 1 үлкен әріп, 1 кіші әріп, арнайы таңба (+-*!?), 7-20 ұзындық.",
      loginBtn: "Кіру",
      registerBtn: "Тіркелу",
      noAccount: "Аккаунтыңыз жоқ па?",
      hasAccount: "Аккаунтыңыз бар ма?",
      registerLink: "Тіркелу",
      loginLink: "Кіру",
      errors: {
          nameReq: "Аты-жөніңізді жазыңыз",
          emailInv: "Электронды пошта қате енгізілді",
          passLen: "Құпия сөз 6 таңбадан көп болуы керек",
          passMax: "Құпия сөз 20 таңбадан аспауы керек",
          passUpper: "Ең кемі 1 үлкен ағылшын әріпі болуы керек",
          passLower: "Ең кемі 1 кіші ағылшын әріпі болуы керек",
          passSpecial: "Ең кемі 1 арнайы таңба (+-*!?) болуы керек",
          passMatch: "Құпия сөздер сәйкес келмейді",
          emailExists: "Бұл поштамен тіркелген қолданушы бар",
          loginFail: "Пошта немесе құпия сөз қате"
      }
    },
    settings: {
        title: "Баптаулар",
        appearance: "Сыртқы көрініс",
        themeDesc: "Фон түсін өзгерту (Ақ / Қара)",
        language: "Тіл",
        languageDesc: "Қолданба тілін өзгерту",
        profile: "Жеке деректер",
        security: "Қауіпсіздік",
        save: "Сақтау",
        oldPassword: "Ескі құпия сөз",
        newPassword: "Жаңа құпия сөз",
        confirmPassword: "Құпия сөзді растау",
        updatePassword: "Құпия сөзді жаңарту",
        successProfile: "Профиль сәтті жаңартылды!",
        successPassword: "Құпия сөз сәтті өзгертілді!",
        errorUserNotFound: "Қолданушы табылмады",
        errorEmailExists: "Бұл пошта тіркелген",
        errorOldPass: "Ескі құпия сөз қате",
        errorPassMatch: "Жаңа құпия сөздер сәйкес келмейді"
    },
    profile: {
        title: "Менің Профилім",
        level: "Деңгей",
        levelDesc: "Сіздің белсенділік деңгейіңіз",
        trustScore: "Сенім ұпайы",
        memberSince: "Тіркелген күні",
        badges: "Жетістіктер",
        badgesDesc: "Сіздің жинаған медальдарыңыз",
        badgeNames: {
            earlyAdopter: "Алғашқы",
            saver: "Жинақтаушы",
            investor: "Инвестор",
            verified: "Расталған"
        },
        edit: "Өзгерту",
        changePhoto: "Фото өзгерту"
    },
    about: {
        title: "Alyp Bank Туралы",
        missionTitle: "Біздің Мақсатымыз",
        missionDesc: "Біз қаржылық қызметтерді қолжетімді, түсінікті және технологиялық тұрғыдан жетілдіруге ұмтыламыз. Жасанды интеллект пен адамгершілікті ұштастыра отырып, сіздің байлығыңызды арттыру - біздің басты миссиямыз.",
        whyUsTitle: "Неге бізді таңдау керек?",
        advantages: [
            { title: "0% Комиссия", desc: "Аударымдар мен төлемдер үшін артық шығын жоқ" },
            { title: "AI Қолдау", desc: "24/7 жұмыс істейтін ақылды көмекші" },
            { title: "Қауіпсіздік", desc: "Ең жоғары деңгейдегі деректерді қорғау" },
            { title: "Инновация", desc: "Gamification және заманауи интерфейс" }
        ],
        questionTitle: "Сұрағыңыз бар ма?",
        questionDesc: "Бізге өз сұрағыңызды немесе ұсынысыңызды жазыңыз",
        formName: "Атыңыз",
        formMessage: "Хабарламаңыз",
        send: "Жіберу",
        success: "Хабарламаңыз сәтті жіберілді! Рахмет."
    },
    dashboard: {
        title: "Жеке кабинет",
        welcome: "Қош келдіңіз",
        welcomeDesc: "Бұл жерде сіздің шоттарыңыз бен карталарыңыз көрсетіледі.",
        owner: "Иесі",
        cardName: "Universal Card"
    },
    bank: {
        title: "Менің банкім",
        bonusTitle: "AlypBank Бонус",
        openCard: "Карта ашу",
        openDeposit: "Депозит ашу",
        myCards: "Менің карталарым",
        myDeposits: "Депозиттер",
        successCard: "Жаңа карта сәтті ашылды!",
        successDeposit: "Депозит сәтті ашылды!",
        successTopUp: "Шот сәтті толтырылды!",
        currency: "₸",
        noCards: "Әзірге карталар жоқ",
        cardType: "Digital Gold",
        depositType: "Жинақ",
        rate: "Мөлшерлеме",
        actions: {
            topUp: "Толтыру",
            history: "Тарихы",
            block: "Бұғаттау",
            addFunds: "Ақша салу",
            enterAmount: "Соманы енгізіңіз",
            cancel: "Болдырмау",
            confirm: "Растау"
        },
        cardForm: {
            selectTier: "Карта түрін таңдаңыз",
            tierStandard: "Standard",
            tierGold: "Gold",
            tierVip: "VIP",
            cardNumber: "Карта нөмірі",
            cardHolder: "Карта иесі",
            expires: "Жарамдылық мерзімі",
            cvv: "CVV",
            submit: "Картаны рәсімдеу",
            month: "Ай",
            year: "Жыл"
        }
    },
    shop: {
        title: "Магазин",
        search: "Тауарларды іздеу...",
        catalog: "Каталог",
        magnum: "Magnum",
        magnumSearch: "Magnum ішінен іздеу...",
        magnumBack: "Магазинге қайту",
        popular: "Танымал тауарлар",
        hotDeals: "🔥 Ыстық жеңілдіктер",
        superBonus: "💎 Супер Бонус",
        discount: "Жеңілдік",
        bonus: "Бонус",
        installment: "бөліп төлеу",
        months: "ай",
        buy: "Сатып алу",
        addToCart: "Себетке салу",
        successOrder: "Тапсырыс сәтті рәсімделді!",
        deliveryDate: "Жеткізілу күні:",
        shippingDate: "Жөнелту:",
        moveToCart: "Себетке салу",
        wishlistTitle: "Қалаулар тізімі",
        emptyWishlist: "Тізім бос",
        appleStore: {
            heroTitle: "iPhone 15 Pro. Титан.",
            visit: "Apple Zone-ға кіру",
            learnMore: "Толығырақ"
        },
        samsungStore: {
            heroText: "Эпикалық өнімділік. Шығармашылық еркіндік.",
            explore: "Толығырақ"
        },
        asusStore: {
            join: "Republic of Gamers-ке қосыл",
            discover: "Танысу"
        },
        stories: {
            sale: "Жеңілдіктер",
            bonus: "Бонустар",
            new: "Жаңа",
            tech: "Техника"
        },
        categories: {
            phones: "Телефондар",
            computers: "Компьютерлер",
            groceries: "Азық-түлік",
            clothes: "Киім",
            home: "Үй тауарлары",
            sport: "Спорт",
            books: "Кітаптар"
        },
        magnumCategories: {
            fruits: "Жемістер",
            vegetables: "Көкөністер",
            dairy: "Сүт өнімдері",
            bakery: "Нан өнімдері",
            meat: "Ет & Тауық",
            drinks: "Сусындар",
            household: "Үйге арналған"
        },
        cart: {
            title: "Сіздің себетіңіз",
            empty: "Себетіңіз бос",
            total: "Барлығы",
            checkout: "Төлеуге өту",
            remove: "Өшіру"
        },
        payment: {
            title: "Қауіпсіз төлем",
            selectCard: "Төлем картасын таңдаңыз",
            processing: "Төлем өңделуде...",
            success: "Төлем сәтті өтті!",
            receipt: "Чек",
            transactionId: "Транзакция ID",
            totalPay: "Төленетін сома",
            pay: "Төлеу",
            date: "Уақыты",
            orderPlaced: "Тапсырыс қабылданды",
            deliveryEstimate: "Жеткізу болжамы"
        }
    },
    transfers: {
        title: "Аударымдар",
        tabs: {
            phone: "Телефон нөмірі",
            card: "Картадан картаға",
            international: "Шетелге"
        },
        phone: {
            label: "Телефон нөмірі",
            placeholder: "+7 (7__) ___ __ __",
            recipient: "Алушы"
        },
        card: {
            source: "Қай картадан",
            dest: "Карта нөмірі",
            placeholder: "0000 0000 0000 0000",
            saveCard: "Картаны сақтау"
        },
        international: {
            country: "Ел",
            method: "Аударым түрі",
            swift: "SWIFT",
            card: "Шетелдік карта",
            name: "Алушының аты-жөні"
        },
        amount: "Аударым сомасы",
        message: "Хабарлама (міндетті емес)",
        send: "Аудару",
        success: "Аударым сәтті орындалды!",
        recent: "Соңғы аударымдар",
        historyEmpty: "Аударымдар тарихы бос"
    },
    payments: {
        title: "Төлемдер",
        search: "Қызметтерді іздеу...",
        catalog: {
            mobile: "Мобильді байланыс",
            utilities: "Коммунальные қызметтер",
            internet: "Интернет және ТВ",
            education: "Білім беру",
            transport: "Көлік",
            fines: "Айыппұлдар мен салықтар",
            games: "Ойындар",
            other: "Басқалары"
        },
        history: "Төлемдер тарихы",
        pay: "Төлеу",
        success: "Төлем сәтті қабылданды!",
        enterDetails: "Деректерді енгізіңіз",
        accountNumber: "Дербес шот / Нөмір",
        amount: "Төлем сомасы"
    },
    messages: {
      title: "Хабарламалар орталығы",
      tabs: {
        all: "Барлығы",
        payments: "Төлемдер",
        shop: "Магазин",
        news: "Жаңалықтар",
        support: "Чат"
      },
      tracking: {
        title: "Тапсырысты қадағалау",
        ordered: "Тапсырыс берілді",
        shipped: "Жіберілді",
        customs: "Кеденде",
        delivery: "Жеткізілуде",
        delivered: "Жеткізілді",
        estimated: "Болжалды уақыт"
      },
      empty: "Хабарламалар жоқ",
      chatPlaceholder: "Хабарлама жазыңыз...",
      supportTitle: "AlypBank Қолдау қызметі"
    },
    loanCalculator: {
        title: "7-20-25 Бағдарламасы",
        subtitle: "Тұрғын үй несиесін есептеу",
        amount: "Несие сомасы",
        term: "Мерзімі",
        years: "жыл",
        monthlyPayment: "Ай сайынғы төлем",
        apply: "Өтінім беру",
        success: "Өтініміңіз қабылданды! Менеджер хабарласады.",
        loginRequired: "Өтінім беру үшін жүйеге тіркеліңіз."
    },
    home: {
        heroTitle: "Қаржылық болашағыңыз бізбен басталады",
        heroDesc: "Заманауи банктік шешімдер және жеке қаржылық кеңес - сіздің сәттілігіңіз біздің басты мақсатымыз",
        openAccount: "Шот ашу",
        moreInfo: "Толығырақ білу",
        servicesTitle: "Негізгі қызметтер",
        more: "Толығырақ",
        promoTitle: "Жаңа несие бағдарламасы!",
        promoDesc: "7% жылдық мөлшерлеме бойынша арнайы ұсыныс. Арманыңыздағы үйге қол жеткізіңіз.",
        promoBtn: "Толығырақ алу",
        statsTitle: "Біздің жетістіктеріміз"
    },
    services: {
        shop: { title: "Магазин", desc: "Онлайн дүкен арқылы қолайлы бағамен сатып алу, жеңіл төлем жүйесі", features: ["0% комиссия", "Кашбэк 5%", "Тегін жеткізу"] },
        bank: { title: "Менің банкім", desc: "Шоттар мен карталарды оңай басқару, 24/7 қолжетімділік", features: ["24/7 Қолжетімділік", "Қауіпсіздік", "Жылдам аударымдар"] },
        payments: { title: "Төлемдер", desc: "Коммуналдық және басқа төлемдерді жеңіл төлеу, автоматты төлемдер", features: ["Автоматты төлемдер", "Түбіртек тарихы", "Комиссиясыз"] },
        transfers: { title: "Аударымдар", desc: "Ақшаны жылдам және қауіпсіз аудару, кез келген уақытта", features: ["Әлем бойынша", "Жылдам аударым", "Минималды комиссия"] }
    },
    stats: {
        clients: { label: "Қанағаттанған клиент" },
        branches: { label: "Филиалдар желісі" },
        experience: { label: "Жылдық тәжірибе" },
        reviews: { label: "Оң пікірлер" }
    },
    footer: {
        desc: "Сенімді қаржылық серіктес. Заманауи шешімдер мен дәстүрлі құндылықтардың үйлесімі.",
        projects: "Жобаларымыз",
        clients: "Клиенттерге",
        contact: "Байланыс",
        rights: "Барлық құқықтар қорғалған.",
        links: {
            trade: "AlypSat — Сауда",
            auto: "AlypCar — Автокөліктер",
            travel: "Travel — Саяхат",
            market: "AlypMarket — Маркетплейс",
            tariffs: "Тарифтер",
            security: "Қауіпсіздік",
            map: "Филиалдар картасы",
            feedback: "Кері байланыс"
        }
    },
    chat: {
        title: "Алып Банк Көмекшісі",
        placeholder: "Сұрағыңызды жазыңыз...",
        welcome: "Сәлеметсіз бе! Мен Алып Банк көмекшісімін. Сізге қалай көмектесе аламын?",
        actions: [
            "Несие туралы ақпарат",
            "Шотты қалай ашуға болады",
            "Карталар туралы",
            "Төлемдер қалай жүргізіледі"
        ]
    }
  },
  ru: {
    sidebar: {
      home: "Главная",
      dashboard: "Дашборд",
      magazin: "Магазин",
      bank: "Мой банк",
      tolemder: "Платежи",
      audarimdar: "Переводы",
      messages: "Сообщения",
      settings: "Настройки",
      profile: "Профиль",
      logout: "Выход",
      login: "Войти",
      search: "Поиск..."
    },
    auth: {
      loginTitle: "Добро пожаловать!",
      registerTitle: "Регистрация",
      loginSubtitle: "Войдите в личный кабинет для продолжения",
      registerSubtitle: "Станьте частью семьи Алып Банк",
      name: "Ваше имя",
      email: "Email",
      password: "Пароль",
      confirmPassword: "Повторите пароль",
      passwordHint: "Минимум 1 заглавная, 1 строчная, спец. символ (+-*!?), длина 7-20.",
      loginBtn: "Войти",
      registerBtn: "Регистрация",
      noAccount: "Нет аккаунта?",
      hasAccount: "Есть аккаунт?",
      registerLink: "Зарегистрироваться",
      loginLink: "Войти",
      errors: {
          nameReq: "Введите ваше имя",
          emailInv: "Неверный формат email",
          passLen: "Пароль должен быть длиннее 6 символов",
          passMax: "Пароль не должен превышать 20 символов",
          passUpper: "Минимум 1 заглавная английская буква",
          passLower: "Минимум 1 строчная английская буква",
          passSpecial: "Минимум 1 спец. символ (+-*!?)",
          passMatch: "Пароли не совпадают",
          emailExists: "Пользователь с таким email уже существует",
          loginFail: "Неверный email или пароль"
      }
    },
    settings: {
        title: "Настройки",
        appearance: "Внешний вид",
        themeDesc: "Изменить цвет фона (Белый / Черный)",
        language: "Язык",
        languageDesc: "Изменить язык приложения",
        profile: "Личные данные",
        security: "Безопасность",
        save: "Сохранить",
        oldPassword: "Старый пароль",
        newPassword: "Новый пароль",
        confirmPassword: "Подтвердите пароль",
        updatePassword: "Обновить пароль",
        successProfile: "Профиль успешно обновлен!",
        successPassword: "Пароль успешно изменен!",
        errorUserNotFound: "Пользователь не найден",
        errorEmailExists: "Этот email уже зарегистрирован",
        errorOldPass: "Старый пароль неверен",
        errorPassMatch: "Новые пароли не совпадают"
    },
    profile: {
        title: "Мой Профиль",
        level: "Уровень",
        levelDesc: "Ваш уровень активности",
        trustScore: "Рейтинг доверия",
        memberSince: "Дата регистрации",
        badges: "Достижения",
        badgesDesc: "Ваши собранные медали",
        badgeNames: {
            earlyAdopter: "Первопроходец",
            saver: "Сберегатель",
            investor: "Инвестор",
            verified: "Верифицирован"
        },
        edit: "Редактировать",
        changePhoto: "Изменить фото"
    },
    about: {
        title: "О Банке Alyp",
        missionTitle: "Наша Миссия",
        missionDesc: "Мы стремимся сделать финансовые услуги доступными, понятными и технологичными. Объединяя искусственный интеллект и человечность, приумножение вашего благосостояния - наша главная миссия.",
        whyUsTitle: "Почему выбирают нас?",
        advantages: [
            { title: "0% Комиссия", desc: "Никаких лишних затрат на переводы и платежи" },
            { title: "AI Поддержка", desc: "Умный помощник, работающий 24/7" },
            { title: "Безопасность", desc: "Защита данных высочайшего уровня" },
            { title: "Инновации", desc: "Геймификация и современный интерфейс" }
        ],
        questionTitle: "Есть вопрос?",
        questionDesc: "Напишите нам свой вопрос или предложение",
        formName: "Ваше имя",
        formMessage: "Ваше сообщение",
        send: "Отправить",
        success: "Ваше сообщение успешно отправлено! Спасибо."
    },
    dashboard: {
        title: "Личный кабинет",
        welcome: "Добро пожаловать",
        welcomeDesc: "Здесь отображаются ваши счета и карты.",
        owner: "Владелец",
        cardName: "Universal Card"
    },
    bank: {
        title: "Мой банк",
        bonusTitle: "AlypBank Бонус",
        openCard: "Открыть карту",
        openDeposit: "Открыть депозит",
        myCards: "Мои карты",
        myDeposits: "Депозиты",
        successCard: "Новая карта успешно открыта!",
        successDeposit: "Депозит успешно открыт!",
        successTopUp: "Счет успешно пополнен!",
        currency: "₸",
        noCards: "Пока нет карт",
        cardType: "Digital Gold",
        depositType: "Сберегательный",
        rate: "Ставка",
        actions: {
            topUp: "Пополнить",
            history: "История",
            block: "Блокировать",
            addFunds: "Пополнить",
            enterAmount: "Введите сумму",
            cancel: "Отмена",
            confirm: "Подтвердить"
        },
        cardForm: {
            selectTier: "Выберите тип карты",
            tierStandard: "Standard",
            tierGold: "Gold",
            tierVip: "VIP",
            cardNumber: "Номер карты",
            cardHolder: "Владелец карты",
            expires: "Срок действия",
            cvv: "CVV",
            submit: "Оформить карту",
            month: "Месяц",
            year: "Год"
        }
    },
    shop: {
        title: "Магазин",
        search: "Поиск товаров...",
        catalog: "Каталог",
        magnum: "Magnum",
        magnumSearch: "Поиск в Magnum...",
        magnumBack: "Вернуться в магазин",
        popular: "Популярное",
        hotDeals: "🔥 Горячие скидки",
        superBonus: "💎 Супер Бонус",
        discount: "Скидка",
        bonus: "Бонус",
        installment: "в рассрочку",
        months: "мес",
        buy: "Купить",
        addToCart: "В корзину",
        successOrder: "Заказ успешно оформлен!",
        deliveryDate: "Дата доставки:",
        shippingDate: "Отправка:",
        moveToCart: "В корзину",
        wishlistTitle: "Избранное",
        emptyWishlist: "Список пуст",
        appleStore: {
            heroTitle: "iPhone 15 Pro. Титан.",
            visit: "Посетить Apple Zone",
            learnMore: "Узнать больше"
        },
        samsungStore: {
            heroText: "Эпическая продуктивность. Творчество.",
            explore: "Подробнее"
        },
        asusStore: {
            join: "Вступить в Republic of Gamers",
            discover: "Открыть"
        },
        stories: {
            sale: "Скидки",
            bonus: "Бонусы",
            new: "Новинки",
            tech: "Техника"
        },
        categories: {
            phones: "Телефоны",
            computers: "Компьютеры",
            groceries: "Продукты",
            clothes: "Одежда",
            home: "Дом",
            sport: "Спорт",
            books: "Книги"
        },
        magnumCategories: {
            fruits: "Фрукты",
            vegetables: "Овощи",
            dairy: "Молочные",
            bakery: "Выпечка",
            meat: "Мясо & Птица",
            drinks: "Напитки",
            household: "Для дома"
        },
        cart: {
            title: "Ваша корзина",
            empty: "Корзина пуста",
            total: "Итого",
            checkout: "Оформить",
            remove: "Удалить"
        },
        payment: {
            title: "Безопасная оплата",
            selectCard: "Выберите карту",
            processing: "Обработка платежа...",
            success: "Оплата прошла успешно!",
            receipt: "Квитанция",
            transactionId: "ID транзакции",
            totalPay: "К оплате",
            pay: "Оплатить",
            date: "Дата",
            orderPlaced: "Заказ оформлен",
            deliveryEstimate: "Ожидаемая доставка"
        }
    },
    transfers: {
        title: "Переводы",
        tabs: {
            phone: "По номеру телефона",
            card: "С карты на карту",
            international: "Международные"
        },
        phone: {
            label: "Номер телефона",
            placeholder: "+7 (7__) ___ __ __",
            recipient: "Получатель"
        },
        card: {
            source: "Откуда",
            dest: "Номер карты",
            placeholder: "0000 0000 0000 0000",
            saveCard: "Сохранить карту"
        },
        international: {
            country: "Страна",
            method: "Способ перевода",
            swift: "SWIFT",
            card: "Зарубежная карта",
            name: "ФИО получателя"
        },
        amount: "Сумма перевода",
        message: "Сообщение (необязательно)",
        send: "Перевести",
        success: "Перевод успешно выполнен!",
        recent: "Последние переводы",
        historyEmpty: "История переводов пуста"
    },
    payments: {
        title: "Платежи",
        search: "Поиск услуг...",
        catalog: {
            mobile: "Мобильная связь",
            utilities: "Коммунальные услуги",
            internet: "Интернет и ТВ",
            education: "Образование",
            transport: "Транспорт",
            fines: "Штрафы и налоги",
            games: "Игры",
            other: "Прочее"
        },
        history: "История платежей",
        pay: "Оплатить",
        success: "Платеж успешно принят!",
        enterDetails: "Введите данные",
        accountNumber: "Лицевой счет / Номер",
        amount: "Сумма платежа"
    },
    messages: {
      title: "Центр сообщений",
      tabs: {
        all: "Все",
        payments: "Платежи",
        shop: "Магазин",
        news: "Новости",
        support: "Чат"
      },
      tracking: {
        title: "Отслеживание заказа",
        ordered: "Заказано",
        shipped: "Отправлено",
        customs: "На таможне",
        delivery: "В доставке",
        delivered: "Доставлено",
        estimated: "Ожидается"
      },
      empty: "Нет сообщений",
      chatPlaceholder: "Напишите сообщение...",
      supportTitle: "Служба поддержки AlypBank"
    },
    loanCalculator: {
        title: "Программа 7-20-25",
        subtitle: "Ипотечный калькулятор",
        amount: "Сумма кредита",
        term: "Срок",
        years: "лет",
        monthlyPayment: "Ежемесячный платеж",
        apply: "Подать заявку",
        success: "Ваша заявка принята! Менеджер свяжется с вами.",
        loginRequired: "Пожалуйста, зарегистрируйтесь, чтобы подать заявку."
    },
    home: {
        heroTitle: "Ваше финансовое будущее начинается с нами",
        heroDesc: "Современные банковские решения и личные финансовые консультации — ваш успех наша главная цель",
        openAccount: "Открыть счет",
        moreInfo: "Узнать больше",
        servicesTitle: "Основные услуги",
        more: "Подробнее",
        promoTitle: "Новая кредитная программа!",
        promoDesc: "Специальное предложение под 7% годовых. Осуществите мечту о доме.",
        promoBtn: "Получить подробности",
        statsTitle: "Наши достижения"
    },
    services: {
        shop: { title: "Магазин", desc: "Покупки онлайн по выгодным ценам, удобная система оплаты", features: ["0% комиссия", "Кэшбэк 5%", "Бесплатная доставка"] },
        bank: { title: "Мой банк", desc: "Удобное управление счетами и картами, доступ 24/7", features: ["Доступ 24/7", "Безопасность", "Мгновенные переводы"] },
        payments: { title: "Платежи", desc: "Легкая оплата коммунальных и других услуг, автоплатежи", features: ["Автоплатежи", "История чеков", "Без комиссии"] },
        transfers: { title: "Переводы", desc: "Быстрые и безопасные переводы денег в любое время", features: ["По всему миру", "Мгновенно", "Мин. комиссия"] }
    },
    stats: {
        clients: { label: "Довольных клиентов" },
        branches: { label: "Сеть филиалов" },
        experience: { label: "Лет опыта" },
        reviews: { label: "Положительных отзывов" }
    },
    footer: {
        desc: "Надежный финансовый партнер. Сочетание современных решений и традиционных ценностей.",
        projects: "Наши проекты",
        clients: "Клиентам",
        contact: "Контакты",
        rights: "Все права защищены.",
        links: {
            trade: "AlypSat — Торговля",
            auto: "AlypCar — Автомобили",
            travel: "Travel — Путешествия",
            market: "AlypMarket — Маркетплейс",
            tariffs: "Тарифы",
            security: "Безопасность",
            map: "Карта филиалов",
            feedback: "Обратная связь"
        }
    },
    chat: {
        title: "Помощник Алып Банк",
        placeholder: "Напишите ваш вопрос...",
        welcome: "Здравствуйте! Я помощник Алып Банк. Как я могу вам помочь?",
        actions: [
            "Информация о кредитах",
            "Как открыть счет",
            "О картах",
            "Как проводятся платежи"
        ]
    }
  },
  en: {
    sidebar: {
      home: "Home",
      dashboard: "Dashboard",
      magazin: "Shop",
      bank: "My Bank",
      tolemder: "Payments",
      audarimdar: "Transfers",
      messages: "Messages",
      settings: "Settings",
      profile: "Profile",
      logout: "Logout",
      login: "Login",
      search: "Search..."
    },
    auth: {
      loginTitle: "Welcome Back!",
      registerTitle: "Register",
      loginSubtitle: "Sign in to access your personal account",
      registerSubtitle: "Become a member of Alyp Bank family",
      name: "Full Name",
      email: "Email",
      password: "Password",
      confirmPassword: "Confirm Password",
      passwordHint: "Min 1 uppercase, 1 lowercase, special char (+-*!?), length 7-20.",
      loginBtn: "Login",
      registerBtn: "Register",
      noAccount: "Don't have an account?",
      hasAccount: "Already have an account?",
      registerLink: "Register",
      loginLink: "Login",
      errors: {
          nameReq: "Enter your full name",
          emailInv: "Invalid email format",
          passLen: "Password must be longer than 6 characters",
          passMax: "Password must not exceed 20 characters",
          passUpper: "At least 1 uppercase English letter required",
          passLower: "At least 1 lowercase English letter required",
          passSpecial: "At least 1 special character (+-*!?) required",
          passMatch: "Passwords do not match",
          emailExists: "User with this email already exists",
          loginFail: "Invalid email or password"
      }
    },
    settings: {
        title: "Settings",
        appearance: "Appearance",
        themeDesc: "Change background color (White / Black)",
        language: "Language",
        languageDesc: "Change application language",
        profile: "Personal Data",
        security: "Security",
        save: "Save",
        oldPassword: "Old Password",
        newPassword: "New Password",
        confirmPassword: "Confirm Password",
        updatePassword: "Update Password",
        successProfile: "Profile successfully updated!",
        successPassword: "Password successfully changed!",
        errorUserNotFound: "User not found",
        errorEmailExists: "Email already registered",
        errorOldPass: "Incorrect old password",
        errorPassMatch: "New passwords do not match"
    },
    profile: {
        title: "My Profile",
        level: "Level",
        levelDesc: "Your activity level",
        trustScore: "Trust Score",
        memberSince: "Member Since",
        badges: "Achievements",
        badgesDesc: "Badges you have collected",
        badgeNames: {
            earlyAdopter: "Early Adopter",
            saver: "Saver",
            investor: "Investor",
            verified: "Verified"
        },
        edit: "Edit Profile",
        changePhoto: "Change Photo"
    },
    about: {
        title: "About Alyp Bank",
        missionTitle: "Our Mission",
        missionDesc: "We strive to make financial services accessible, understandable, and technologically advanced. Combining artificial intelligence with humanity, increasing your wealth is our main mission.",
        whyUsTitle: "Why Choose Us?",
        advantages: [
            { title: "0% Commission", desc: "No extra costs for transfers and payments" },
            { title: "AI Support", desc: "Smart assistant working 24/7" },
            { title: "Security", desc: "Top-level data protection" },
            { title: "Innovation", desc: "Gamification and modern interface" }
        ],
        questionTitle: "Have a Question?",
        questionDesc: "Write your question or suggestion to us",
        formName: "Your Name",
        formMessage: "Your Message",
        send: "Send",
        success: "Your message has been sent successfully! Thank you."
    },
    dashboard: {
        title: "Personal Cabinet",
        welcome: "Welcome",
        welcomeDesc: "Here you can see your accounts and cards.",
        owner: "Owner",
        cardName: "Universal Card"
    },
    bank: {
        title: "My Bank",
        bonusTitle: "AlypBank Bonus",
        openCard: "Open Card",
        openDeposit: "Open Deposit",
        myCards: "My Cards",
        myDeposits: "My Deposits",
        successCard: "New card opened successfully!",
        successDeposit: "Deposit opened successfully!",
        successTopUp: "Account topped up successfully!",
        currency: "₸",
        noCards: "No cards yet",
        cardType: "Digital Gold",
        depositType: "Savings",
        rate: "Rate",
        actions: {
            topUp: "Top Up",
            history: "History",
            block: "Block",
            addFunds: "Add Funds",
            enterAmount: "Enter Amount",
            cancel: "Cancel",
            confirm: "Confirm"
        },
        cardForm: {
            selectTier: "Select Card Tier",
            tierStandard: "Standard",
            tierGold: "Gold",
            tierVip: "VIP",
            cardNumber: "Card Number",
            cardHolder: "Card Holder",
            expires: "Expires",
            cvv: "CVV",
            submit: "Open Card",
            month: "Month",
            year: "Year"
        }
    },
    shop: {
        title: "Shop",
        search: "Search products...",
        catalog: "Catalog",
        magnum: "Magnum",
        magnumSearch: "Search in Magnum...",
        magnumBack: "Back to Shop",
        popular: "Popular",
        hotDeals: "🔥 Hot Deals",
        superBonus: "💎 Super Bonus",
        discount: "Discount",
        bonus: "Bonus",
        installment: "installments",
        months: "mo",
        buy: "Buy Now",
        addToCart: "Add to Cart",
        successOrder: "Order placed successfully!",
        deliveryDate: "Delivery:",
        shippingDate: "Shipping:",
        moveToCart: "Move to Cart",
        wishlistTitle: "Wishlist",
        emptyWishlist: "Wishlist is empty",
        appleStore: {
            heroTitle: "iPhone 15 Pro. Titanium.",
            visit: "Visit Apple Zone",
            learnMore: "Learn More"
        },
        samsungStore: {
            heroText: "Epic productivity. Epic creativity. Epic play.",
            explore: "Explore"
        },
        asusStore: {
            join: "Join the Republic of Gamers",
            discover: "Discover"
        },
        stories: {
            sale: "Sale",
            bonus: "Bonus",
            new: "New",
            tech: "Tech"
        },
        categories: {
            phones: "Phones",
            computers: "Computers",
            groceries: "Groceries",
            clothes: "Clothes",
            home: "Home",
            sport: "Sport",
            books: "Books"
        },
        magnumCategories: {
            fruits: "Fruits",
            vegetables: "Vegetables",
            dairy: "Dairy",
            bakery: "Bakery",
            meat: "Meat & Poultry",
            drinks: "Drinks",
            household: "Household"
        },
        cart: {
            title: "Your Cart",
            empty: "Your cart is empty",
            total: "Total",
            checkout: "Checkout",
            remove: "Remove"
        },
        payment: {
            title: "Secure Payment",
            selectCard: "Select Card",
            processing: "Processing...",
            success: "Payment Successful!",
            receipt: "Receipt",
            transactionId: "Transaction ID",
            totalPay: "Total to Pay",
            pay: "Pay",
            date: "Date",
            orderPlaced: "Order Placed",
            deliveryEstimate: "Est. Delivery"
        }
    },
    transfers: {
        title: "Transfers",
        tabs: {
            phone: "By Phone Number",
            card: "Card to Card",
            international: "International"
        },
        phone: {
            label: "Phone Number",
            placeholder: "+7 (7__) ___ __ __",
            recipient: "Recipient"
        },
        card: {
            source: "From Card",
            dest: "To Card Number",
            placeholder: "0000 0000 0000 0000",
            saveCard: "Save card"
        },
        international: {
            country: "Country",
            method: "Transfer Method",
            swift: "SWIFT",
            card: "Foreign Card",
            name: "Recipient Name"
        },
        amount: "Amount",
        message: "Message (optional)",
        send: "Transfer",
        success: "Transfer Successful!",
        recent: "Recent Transfers",
        historyEmpty: "Transfer history is empty"
    },
    payments: {
        title: "Payments",
        search: "Search services...",
        catalog: {
            mobile: "Mobile",
            utilities: "Utilities",
            internet: "Internet & TV",
            education: "Education",
            transport: "Transport",
            fines: "Taxes & Fines",
            games: "Games",
            other: "Other"
        },
        history: "Payment History",
        pay: "Pay",
        success: "Payment Successful!",
        enterDetails: "Enter Details",
        accountNumber: "Account / Number",
        amount: "Amount"
    },
    messages: {
      title: "Message Center",
      tabs: {
        all: "All",
        payments: "Payments",
        shop: "Shop",
        news: "News",
        support: "Chat"
      },
      tracking: {
        title: "Order Tracking",
        ordered: "Ordered",
        shipped: "Shipped",
        customs: "Customs",
        delivery: "Delivery",
        delivered: "Delivered",
        estimated: "Estimated"
      },
      empty: "No messages",
      chatPlaceholder: "Type a message...",
      supportTitle: "AlypBank Support"
    },
    loanCalculator: {
        title: "7-20-25 Program",
        subtitle: "Housing Loan Calculator",
        amount: "Loan Amount",
        term: "Term",
        years: "years",
        monthlyPayment: "Monthly Payment",
        apply: "Apply Now",
        success: "Your application has been received!",
        loginRequired: "Please login to apply."
    },
    home: {
        heroTitle: "Your financial future starts with us",
        heroDesc: "Modern banking solutions and personal financial advice — your success is our main goal",
        openAccount: "Open Account",
        moreInfo: "Learn More",
        servicesTitle: "Main Services",
        more: "Details",
        promoTitle: "New Loan Program!",
        promoDesc: "Special offer at 7% annual rate. Achieve your dream home.",
        promoBtn: "Get Details",
        statsTitle: "Our Achievements"
    },
    services: {
        shop: { title: "Shop", desc: "Buy online at great prices, easy payment system", features: ["0% commission", "5% Cashback", "Free Shipping"] },
        bank: { title: "My Bank", desc: "Easy management of accounts and cards, 24/7 access", features: ["24/7 Access", "Secure", "Instant Transfers"] },
        payments: { title: "Payments", desc: "Easy payment of utilities and others, auto-payments", features: ["Auto-payments", "Receipt History", "No Commission"] },
        transfers: { title: "Transfers", desc: "Fast and secure money transfers, anytime", features: ["Worldwide", "Instant", "Min. Commission"] }
    },
    stats: {
        clients: { label: "Satisfied Clients" },
        branches: { label: "Branch Network" },
        experience: { label: "Years Experience" },
        reviews: { label: "Positive Reviews" }
    },
    footer: {
        desc: "Trusted financial partner. Combination of modern solutions and traditional values.",
        projects: "Our Projects",
        clients: "For Clients",
        contact: "Contact",
        rights: "All rights reserved.",
        links: {
            trade: "AlypSat — Trade",
            auto: "AlypCar — Cars",
            travel: "Travel — Tourism",
            market: "AlypMarket — Marketplace",
            tariffs: "Tariffs",
            security: "Security",
            map: "Branch Map",
            feedback: "Feedback"
        }
    },
    chat: {
        title: "Alyp Bank Assistant",
        placeholder: "Type your question...",
        welcome: "Hello! I am Alyp Bank assistant. How can I help you?",
        actions: [
            "Loan Information",
            "How to open account",
            "About Cards",
            "How payments work"
        ]
    }
  }
};