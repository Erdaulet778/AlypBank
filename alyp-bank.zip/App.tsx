

import React, { useState, useEffect } from 'react';
import { Menu, ShoppingBag, Wallet, CreditCard, ArrowRightLeft, Users, Building2, Star, ThumbsUp, ArrowRight, X, Calculator, Check, MessageSquare, Info, Shield, Brain, Send } from 'lucide-react';
import Background from './components/Background';
import Sidebar from './components/Sidebar';
import ChatBot from './components/ChatBot';
import AuthForms from './components/AuthForms';
import Footer from './components/Footer';
import Settings from './components/Settings';
import BankView from './components/BankView';
import MessagesView from './components/MessagesView';
import TransfersView from './components/TransfersView';
import PaymentsView from './components/PaymentsView';
import Dashboard from './components/Dashboard';
import UserProfile from './components/UserProfile';
import ShopView from './components/ShopView';
import { ViewState, Language, Service } from './types';
import { translations } from './utils/translations';

function App() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [currentView, setCurrentView] = useState<ViewState | 'profile'>('home');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userName, setUserName] = useState('');
  const [currentUserEmail, setCurrentUserEmail] = useState('');
  const [displayedText, setDisplayedText] = useState('');
  
  // Modal States
  const [showLoanModal, setShowLoanModal] = useState(false);
  const [showAboutModal, setShowAboutModal] = useState(false);
  const [loanAmount, setLoanAmount] = useState(15000000);
  const [loanTerm, setLoanTerm] = useState(15);
  const [loanSuccessMsg, setLoanSuccessMsg] = useState<string | null>(null);

  // About Form State
  const [aboutFormName, setAboutFormName] = useState('');
  const [aboutFormMsg, setAboutFormMsg] = useState('');
  const [aboutFormSuccess, setAboutFormSuccess] = useState(false);

  // Service Modal State
  const [selectedService, setSelectedService] = useState<Service | null>(null);

  // Language State
  const [language, setLanguage] = useState<Language>(() => {
    if (typeof window !== 'undefined') {
        const saved = localStorage.getItem('language');
        return (saved === 'kk' || saved === 'ru' || saved === 'en') ? (saved as Language) : 'kk';
    }
    return 'kk';
  });

  useEffect(() => {
    localStorage.setItem('language', language);
  }, [language]);

  const t = translations[language];

  // Dark Mode State
  const [isDarkMode, setIsDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
        return localStorage.getItem('theme') === 'dark';
    }
    return false;
  });

  // Apply Theme & Accent on Mount
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }

    // Apply Accent
    const savedAccent = localStorage.getItem('accentTheme') || 'theme-blue';
    document.body.classList.add(savedAccent);
  }, [isDarkMode]);
  
  // Session Persistence
  useEffect(() => {
      const session = localStorage.getItem('alypbank_session');
      if (session) {
          try {
              const { name, email } = JSON.parse(session);
              if (name && email) {
                  setUserName(name);
                  setCurrentUserEmail(email);
                  setIsLoggedIn(true);
              }
          } catch (e) {
              localStorage.removeItem('alypbank_session');
          }
      }
  }, []);

  const toggleTheme = () => setIsDarkMode(!isDarkMode);

  // Typewriter effect state
  const fullText = t.home.heroTitle;
  
  useEffect(() => {
    setDisplayedText(''); // Reset text when lang changes
    let index = 0;
    const interval = setInterval(() => {
      setDisplayedText(fullText.slice(0, index));
      index++;
      if (index > fullText.length) clearInterval(interval);
    }, 50);
    return () => clearInterval(interval);
  }, [fullText, language]);

  const handleAuthSuccess = (name: string, email: string) => {
    setUserName(name);
    setCurrentUserEmail(email);
    setIsLoggedIn(true);
    localStorage.setItem('alypbank_session', JSON.stringify({ name, email }));
    setCurrentView('dashboard');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUserName('');
    setCurrentUserEmail('');
    localStorage.removeItem('alypbank_session');
    setCurrentView('home');
  };

  const handleProfileUpdate = (newName: string, newEmail: string) => {
      setUserName(newName);
      setCurrentUserEmail(newEmail);
      // Update session if email matches current user
      const session = localStorage.getItem('alypbank_session');
      if (session) {
           localStorage.setItem('alypbank_session', JSON.stringify({ name: newName, email: newEmail }));
      }
  };

  const handleOpenAccountClick = () => {
    if (isLoggedIn) {
      setCurrentView('bank');
    } else {
      setCurrentView('register');
    }
  };

  const handleAboutSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      setAboutFormSuccess(true);
      setTimeout(() => {
          setAboutFormSuccess(false);
          setAboutFormName('');
          setAboutFormMsg('');
      }, 3000);
  };

  // Loan Logic
  const calculateMonthlyPayment = () => {
      const r = 0.07 / 12; // 7% annual rate
      const n = loanTerm * 12; // months
      const amount = loanAmount;
      
      const payment = (amount * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
      return Math.round(payment).toLocaleString();
  };

  const handleLoanApply = () => {
      if (isLoggedIn) {
          setLoanSuccessMsg(t.loanCalculator.success);
          setTimeout(() => {
              setLoanSuccessMsg(null);
              setShowLoanModal(false);
          }, 3000);
      } else {
          // Redirect to auth
          setShowLoanModal(false);
          setCurrentView('register');
      }
  };

  const handleServiceClick = (serviceId: string) => {
      if (isLoggedIn) {
        // Map service ID to view ID
        const viewMap: {[key: string]: ViewState} = {
            'shop': 'magazin',
            'bank': 'bank',
            'payments': 'tolemder',
            'transfers': 'audarimdar'
        };
        if (viewMap[serviceId]) {
            setCurrentView(viewMap[serviceId]);
        }
      } else {
        setCurrentView('login');
      }
      setSelectedService(null);
  };

  const services = [
    { id: 'shop', icon: <ShoppingBag size={32} />, title: t.services.shop.title, description: t.services.shop.desc, features: t.services.shop.features, link: t.home.more, color: "from-pink-500 to-rose-500" },
    { id: 'bank', icon: <Wallet size={32} />, title: t.services.bank.title, description: t.services.bank.desc, features: t.services.bank.features, link: t.home.more, color: "from-blue-500 to-indigo-500" },
    { id: 'payments', icon: <CreditCard size={32} />, title: t.services.payments.title, description: t.services.payments.desc, features: t.services.payments.features, link: t.home.more, color: "from-emerald-500 to-teal-500" },
    { id: 'transfers', icon: <ArrowRightLeft size={32} />, title: t.services.transfers.title, description: t.services.transfers.desc, features: t.services.transfers.features, link: t.home.more, color: "from-amber-500 to-orange-500" },
  ];

  const stats = [
    { icon: <Users size={24} />, number: "500K+", label: t.stats.clients.label, color: "text-blue-600", bg: "bg-blue-50" },
    { icon: <Building2 size={24} />, number: "150+", label: t.stats.branches.label, color: "text-indigo-600", bg: "bg-indigo-50" },
    { icon: <Star size={24} />, number: "25+", label: t.stats.experience.label, color: "text-amber-600", bg: "bg-amber-50" },
    { icon: <ThumbsUp size={24} />, number: "98%", label: t.stats.reviews.label, color: "text-emerald-600", bg: "bg-emerald-50" },
  ];

  return (
    <div className="min-h-screen relative font-sans text-slate-800 dark:text-slate-100 transition-colors duration-500">
      <Background />
      
      {/* Sidebar */}
      <Sidebar 
        collapsed={sidebarCollapsed} 
        setCollapsed={setSidebarCollapsed}
        mobileOpen={mobileMenuOpen}
        setMobileOpen={setMobileMenuOpen}
        currentView={currentView as ViewState}
        onNavigate={setCurrentView}
        isLoggedIn={isLoggedIn}
        onLogout={handleLogout}
        lang={language}
      />

      {/* Main Content Area */}
      <main 
        className={`transition-all duration-500 min-h-screen flex flex-col
          ${sidebarCollapsed ? 'md:ml-[88px]' : 'md:ml-80'} 
          ${mobileMenuOpen ? 'blur-sm md:blur-0' : ''}
        `}
      >
        {/* Mobile Header */}
        <div className="md:hidden p-4 flex items-center justify-between sticky top-0 bg-white/80 dark:bg-black/60 backdrop-blur-md z-30 border-b border-white/10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-accent-600 to-purple-600 flex items-center justify-center text-white font-bold">A</div>
            <span className="font-bold text-slate-800 dark:text-white">Alyp Bank</span>
          </div>
          <button onClick={() => setMobileMenuOpen(true)} className="p-2 text-slate-600 dark:text-slate-300">
            <Menu size={24} />
          </button>
        </div>

        {/* Content Switcher */}
        {(currentView === 'login' || currentView === 'register') ? (
          <div className="flex-1 flex items-center justify-center p-4">
            <AuthForms 
              view={currentView} 
              onSwitch={setCurrentView} 
              onSuccess={handleAuthSuccess}
              lang={language}
            />
          </div>
        ) : currentView === 'settings' ? (
           <Settings 
             currentUserEmail={currentUserEmail}
             isDarkMode={isDarkMode}
             toggleTheme={toggleTheme}
             onProfileUpdate={handleProfileUpdate}
             lang={language}
             setLang={setLanguage}
           />
        ) : currentView === 'profile' ? (
            <UserProfile 
                userName={userName}
                email={currentUserEmail}
                lang={language}
                onNavigate={setCurrentView}
            />
        ) : currentView === 'bank' ? (
           <BankView lang={language} userName={userName} />
        ) : currentView === 'magazin' ? (
            <ShopView lang={language} />
        ) : currentView === 'messages' ? (
            <MessagesView lang={language} />
        ) : currentView === 'tolemder' ? (
            <PaymentsView lang={language} />
        ) : currentView === 'audarimdar' ? (
            <TransfersView lang={language} />
        ) : currentView === 'dashboard' ? (
           <Dashboard userName={userName} lang={language} />
        ) : (
          /* Home View */
          <div className="flex-1">
            {/* Hero Section */}
            <section className="relative pt-24 pb-32 px-6 text-center overflow-hidden">
              <div className="relative z-10 max-w-5xl mx-auto">
                <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-accent-600 via-purple-600 to-pink-600 dark:from-white dark:via-accent-300 dark:to-purple-300 mb-8 min-h-[1.2em] leading-tight filter drop-shadow-sm">
                   {displayedText}
                   <span className="animate-pulse text-accent-500">|</span>
                </h1>
                <p 
                  className="text-lg md:text-2xl text-slate-600 dark:text-slate-300 max-w-2xl mx-auto mb-12 leading-relaxed opacity-0 animate-fade-in-up font-medium" 
                  style={{ animationDelay: '0.3s' }}
                >
                  {t.home.heroDesc}
                </p>
                <div 
                  className="flex flex-col sm:flex-row items-center justify-center gap-6 opacity-0 animate-fade-in-up" 
                  style={{ animationDelay: '0.5s' }}
                >
                  <button onClick={handleOpenAccountClick} className="px-10 py-5 bg-accent-600 text-white rounded-full font-bold text-lg shadow-[0_10px_40px_-10px_rgba(79,70,229,0.5)] hover:shadow-[0_20px_50px_-10px_rgba(79,70,229,0.6)] hover:-translate-y-1 transition-all active:scale-95 ring-2 ring-white/20">
                    {t.home.openAccount}
                  </button>
                  <button 
                    onClick={() => setShowAboutModal(true)}
                    className="px-10 py-5 bg-white/50 dark:bg-slate-800/50 backdrop-blur-md text-slate-800 dark:text-white border border-slate-200 dark:border-slate-700 rounded-full font-bold text-lg hover:bg-white dark:hover:bg-slate-700 transition-colors"
                  >
                    {t.home.moreInfo}
                  </button>
                </div>
              </div>
            </section>

            {/* Services Grid */}
            <section className="px-6 py-20 max-w-7xl mx-auto">
              <div className="flex items-center gap-4 mb-16">
                <div className="h-1.5 w-16 bg-accent-600 dark:bg-accent-400 rounded-full"></div>
                <h2 className="text-4xl font-bold text-slate-800 dark:text-white tracking-tight">{t.home.servicesTitle}</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {services.map((service, idx) => (
                  <div key={idx} className="group p-8 bg-white/70 dark:bg-black/40 backdrop-blur-xl rounded-[2.5rem] border border-white/50 dark:border-white/5 shadow-xl hover:shadow-2xl hover:shadow-accent-500/10 hover:-translate-y-2 transition-all duration-500">
                    <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${service.color} flex items-center justify-center text-white mb-8 shadow-lg transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-500`}>
                      {service.icon}
                    </div>
                    <h3 className="text-2xl font-bold text-slate-800 dark:text-white mb-4">{service.title}</h3>
                    <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed mb-8">{service.description}</p>
                    <button 
                        onClick={() => setSelectedService(service as any)}
                        className="flex items-center gap-2 text-accent-600 dark:text-accent-400 font-bold text-sm group-hover:gap-4 transition-all"
                    >
                      {t.home.more} <ArrowRight size={18} />
                    </button>
                  </div>
                ))}
              </div>
            </section>

            {/* Promo Banner */}
            <section className="px-6 py-16 max-w-7xl mx-auto">
              <div className="relative rounded-[3rem] overflow-hidden bg-gradient-to-r from-accent-600 to-purple-600 text-white shadow-2xl shadow-accent-900/30 group">
                {/* Promo Background Animation */}
                <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-white/10 rounded-full blur-3xl -mr-32 -mt-32 transition-transform duration-1000 group-hover:translate-x-10 group-hover:-translate-y-10"></div>
                <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-black/20 rounded-full blur-3xl -ml-20 -mb-20 transition-transform duration-1000 group-hover:-translate-x-10 group-hover:translate-y-10"></div>
                
                <div className="relative z-10 p-12 md:p-24 text-center">
                  <div className="inline-block px-4 py-1.5 rounded-full bg-white/20 backdrop-blur-sm border border-white/30 text-sm font-bold mb-6">New Offer</div>
                  <h2 className="text-4xl md:text-6xl font-extrabold mb-8 leading-tight tracking-tight">{t.home.promoTitle}</h2>
                  <p className="text-blue-50 text-xl md:text-2xl max-w-3xl mx-auto mb-12 leading-relaxed font-medium">
                    {t.home.promoDesc}
                  </p>
                  <button 
                    onClick={() => setShowLoanModal(true)}
                    className="px-12 py-5 bg-white text-accent-600 rounded-full font-bold text-lg hover:scale-105 active:scale-95 transition-all shadow-xl hover:shadow-2xl"
                  >
                    {t.home.promoBtn}
                  </button>
                </div>
              </div>
            </section>

            {/* Achievements */}
            <section className="px-6 py-16 max-w-7xl mx-auto mb-12">
              <div className="text-center mb-20">
                <h2 className="text-4xl font-bold text-slate-800 dark:text-white mb-6">{t.home.statsTitle}</h2>
                <div className="h-1.5 w-24 bg-gradient-to-r from-accent-600 to-purple-600 mx-auto rounded-full"></div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                {stats.map((stat, idx) => (
                  <div key={idx} className="p-8 bg-white/50 dark:bg-slate-900/50 backdrop-blur-lg rounded-3xl border border-slate-100 dark:border-slate-800 text-center hover:border-accent-200 dark:hover:border-accent-800 transition-colors group">
                    <div className={`w-14 h-14 ${stat.bg} ${stat.color} rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform`}>
                      {stat.icon}
                    </div>
                    <div className={`text-4xl font-extrabold ${stat.color} mb-2 tracking-tight`}>{stat.number}</div>
                    <div className="text-sm text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider">{stat.label}</div>
                  </div>
                ))}
              </div>
            </section>

            <Footer lang={language} />
          </div>
        )}
      </main>
      
      {/* Global Chat Bot */}
      {currentView !== 'messages' && <ChatBot lang={language} />}

      {/* About Modal */}
      {showAboutModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md p-4 animate-in fade-in duration-300">
             <div className="bg-white dark:bg-slate-900 w-full max-w-3xl h-[85vh] rounded-[2.5rem] overflow-hidden relative shadow-2xl animate-in zoom-in-95 duration-300 border border-white/10 flex flex-col">
                 
                 {/* Modal Header */}
                 <div className="bg-gradient-to-r from-accent-600 to-purple-600 p-8 text-white relative shrink-0">
                     <button 
                        onClick={() => setShowAboutModal(false)}
                        className="absolute top-6 right-6 p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors"
                     >
                        <X size={20} />
                     </button>
                     <div className="flex items-center gap-4 mb-4">
                         <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
                             <Info size={28} />
                         </div>
                         <h2 className="text-3xl font-bold">{t.about.title}</h2>
                     </div>
                     <p className="text-blue-100 max-w-xl">{t.about.missionDesc}</p>
                 </div>

                 {/* Modal Body */}
                 <div className="flex-1 overflow-y-auto p-8 space-y-10">
                     
                     {/* Advantages Grid */}
                     <section>
                         <h3 className="text-xl font-bold dark:text-white mb-6 flex items-center gap-2">
                             <Star className="text-accent-500" /> {t.about.whyUsTitle}
                         </h3>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                             {t.about.advantages.map((adv: any, idx: number) => (
                                 <div key={idx} className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-white/5 flex gap-4">
                                     <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 
                                        ${idx === 0 ? 'bg-blue-100 text-blue-600' : ''}
                                        ${idx === 1 ? 'bg-purple-100 text-purple-600' : ''}
                                        ${idx === 2 ? 'bg-green-100 text-green-600' : ''}
                                        ${idx === 3 ? 'bg-orange-100 text-orange-600' : ''}
                                     `}>
                                         {idx === 0 ? <CreditCard size={20} /> : idx === 1 ? <Brain size={20} /> : idx === 2 ? <Shield size={20} /> : <ShoppingBag size={20} />}
                                     </div>
                                     <div>
                                         <h4 className="font-bold text-slate-800 dark:text-white">{adv.title}</h4>
                                         <p className="text-sm text-slate-500 dark:text-slate-400">{adv.desc}</p>
                                     </div>
                                 </div>
                             ))}
                         </div>
                     </section>

                     {/* Question Form */}
                     <section className="bg-gradient-to-br from-slate-100 to-white dark:from-slate-800 dark:to-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-700">
                         <h3 className="text-xl font-bold dark:text-white mb-2 flex items-center gap-2">
                             <MessageSquare className="text-accent-500" /> {t.about.questionTitle}
                         </h3>
                         <p className="text-sm text-slate-500 mb-6">{t.about.questionDesc}</p>
                         
                         {aboutFormSuccess ? (
                             <div className="p-4 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 rounded-xl flex items-center gap-3 animate-in fade-in">
                                 <Check size={20} />
                                 {t.about.success}
                             </div>
                         ) : (
                             <form onSubmit={handleAboutSubmit} className="space-y-4">
                                 <div>
                                     <input 
                                        required
                                        type="text" 
                                        placeholder={t.about.formName}
                                        value={aboutFormName}
                                        onChange={(e) => setAboutFormName(e.target.value)}
                                        className="w-full px-4 py-3 rounded-xl bg-white dark:bg-black/50 border border-slate-200 dark:border-slate-600 focus:ring-2 focus:ring-accent-500 outline-none dark:text-white"
                                     />
                                 </div>
                                 <div>
                                     <textarea 
                                        required
                                        rows={3}
                                        placeholder={t.about.formMessage}
                                        value={aboutFormMsg}
                                        onChange={(e) => setAboutFormMsg(e.target.value)}
                                        className="w-full px-4 py-3 rounded-xl bg-white dark:bg-black/50 border border-slate-200 dark:border-slate-600 focus:ring-2 focus:ring-accent-500 outline-none dark:text-white resize-none"
                                     />
                                 </div>
                                 <button className="px-6 py-3 bg-accent-600 text-white font-bold rounded-xl hover:bg-accent-700 transition-colors flex items-center gap-2 shadow-lg shadow-accent-500/20">
                                     <Send size={18} /> {t.about.send}
                                 </button>
                             </form>
                         )}
                     </section>
                 </div>
             </div>
        </div>
      )}

      {/* Loan Calculator Modal */}
      {showLoanModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md p-4 animate-in fade-in duration-300">
             <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-3xl p-8 relative shadow-2xl animate-in zoom-in-95 duration-300 border border-white/10">
                <button 
                    onClick={() => setShowLoanModal(false)}
                    className="absolute top-6 right-6 p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 transition-colors"
                >
                    <X size={20} />
                </button>
                
                {loanSuccessMsg ? (
                    <div className="text-center py-10">
                        <div className="w-24 h-24 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center text-green-600 dark:text-green-400 mx-auto mb-6 animate-in zoom-in">
                            <Check size={48} />
                        </div>
                        <h3 className="text-2xl font-bold mb-2 dark:text-white">{t.loanCalculator.success}</h3>
                    </div>
                ) : (
                    <>
                        <div className="mb-8">
                            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent-100 dark:bg-accent-900/30 text-accent-700 dark:text-accent-300 text-xs font-bold uppercase tracking-wider mb-4">
                                7-20-25
                            </div>
                            <h3 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t.loanCalculator.title}</h3>
                            <p className="text-slate-500 dark:text-slate-400">{t.loanCalculator.subtitle}</p>
                        </div>

                        <div className="space-y-8">
                            {/* Amount */}
                            <div>
                                <div className="flex justify-between mb-2">
                                    <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t.loanCalculator.amount}</label>
                                    <span className="text-sm font-bold text-accent-600 dark:text-accent-400">{loanAmount.toLocaleString()} ₸</span>
                                </div>
                                <input 
                                    type="range" 
                                    min="5000000" 
                                    max="25000000" 
                                    step="500000" 
                                    value={loanAmount}
                                    onChange={(e) => setLoanAmount(Number(e.target.value))}
                                    className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-accent-600"
                                />
                            </div>

                            {/* Term */}
                            <div>
                                <div className="flex justify-between mb-2">
                                    <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t.loanCalculator.term}</label>
                                    <span className="text-sm font-bold text-accent-600 dark:text-accent-400">{loanTerm} {t.loanCalculator.years}</span>
                                </div>
                                <input 
                                    type="range" 
                                    min="5" 
                                    max="25" 
                                    step="1" 
                                    value={loanTerm}
                                    onChange={(e) => setLoanTerm(Number(e.target.value))}
                                    className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-accent-600"
                                />
                            </div>

                            {/* Result */}
                            <div className="bg-slate-50 dark:bg-black/50 rounded-2xl p-6 border border-slate-100 dark:border-white/5">
                                <div className="flex items-center gap-3 mb-1 text-slate-500 dark:text-slate-400">
                                    <Calculator size={18} />
                                    <span className="text-sm font-medium">{t.loanCalculator.monthlyPayment}</span>
                                </div>
                                <div className="text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                                    {calculateMonthlyPayment()} <span className="text-2xl text-slate-400 font-normal">₸</span>
                                </div>
                            </div>

                            <button 
                                onClick={handleLoanApply}
                                className="w-full py-4 bg-gradient-to-r from-accent-600 to-purple-600 text-white rounded-xl font-bold shadow-lg shadow-accent-500/30 hover:scale-[1.02] active:scale-95 transition-all"
                            >
                                {t.loanCalculator.apply}
                            </button>
                            
                            {!isLoggedIn && (
                                <p className="text-center text-xs text-slate-400">
                                    {t.loanCalculator.loginRequired}
                                </p>
                            )}
                        </div>
                    </>
                )}
             </div>
        </div>
      )}

      {/* Service Detail Modal */}
      {selectedService && (
         <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md p-4 animate-in fade-in duration-300">
            <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-3xl p-8 relative shadow-2xl animate-in zoom-in-95 duration-300 border border-white/10">
               <button 
                   onClick={() => setSelectedService(null)}
                   className="absolute top-6 right-6 p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 transition-colors"
               >
                   <X size={20} />
               </button>

               <div className="text-center mb-8">
                  <div className={`w-24 h-24 mx-auto rounded-3xl bg-gradient-to-br ${selectedService.color} flex items-center justify-center text-white mb-6 shadow-xl`}>
                     {React.cloneElement(selectedService.icon as any, { size: 48 })}
                  </div>
                  <h3 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{selectedService.title}</h3>
                  <p className="text-slate-500 dark:text-slate-400 leading-relaxed text-lg">{selectedService.description}</p>
               </div>

               {selectedService.features && (
                   <div className="space-y-3 mb-8">
                       {selectedService.features.map((feature: string, idx: number) => (
                           <div key={idx} className="flex items-center gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 text-left border border-slate-100 dark:border-white/5">
                               <div className="w-8 h-8 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center text-green-600 dark:text-green-400 shrink-0">
                                   <Check size={16} />
                               </div>
                               <span className="text-base font-medium text-slate-700 dark:text-slate-200">{feature}</span>
                           </div>
                       ))}
                   </div>
               )}

               <button 
                   onClick={() => handleServiceClick(selectedService.id)}
                   className="w-full py-4 bg-gradient-to-r from-accent-600 to-purple-600 text-white rounded-xl font-bold shadow-lg shadow-accent-500/30 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2"
               >
                   {selectedService.link} <ArrowRight size={20} />
               </button>
            </div>
         </div>
      )}
    </div>
  );
}

export default App;
