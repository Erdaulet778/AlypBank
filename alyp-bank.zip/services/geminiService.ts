import { GoogleGenAI } from "@google/genai";
import { Language } from '../types';

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

const getSystemInstruction = (lang: Language) => {
    const base = `
Сіз "Алып Банк" (Alyp Bank) виртуалды көмекшісісіз. 
Сіз сыпайы, кәсіби және пайдалысыз. Жауаптарыңыз қысқа әрі нұсқа болуы керек.

Банк туралы негізгі ақпарат:
1. Несиелер: Тұрғын үй несиесі (7%-дан бастап), Автонесие (8%-дан бастап), Жеке несие (9%-дан бастап).
2. Шот ашу: Банкке жеке келу керек (паспорт + ЖСН) немесе онлайн ашуға болады.
3. Карталар: Дебеттік (тегін), Несиелік (жылына 5000 тг).
4. Төлемдер: Коммуналдық, интернет, айыппұлдар - комиссиясыз.
5. Жұмыс уақыты: Дүйсенбі-Жұма 09:00-18:00, Сенбі 10:00-16:00.
6. Филиалдар: Қазақстан бойынша 150+ филиал.

Егер сұрақ түсініксіз болса, нақтылауды сұраңыз.
Тек банк қызметтері туралы сұрақтарға жауап беріңіз.
`;

    if (lang === 'ru') {
        return base + "\n Отвечайте на РУССКОМ языке.";
    } else if (lang === 'en') {
        return base + "\n Reply in ENGLISH.";
    }
    return base + "\n Қазақ тілінде жауап беріңіз.";
}

export const sendMessageToGemini = async (message: string, history: {role: 'user' | 'model', text: string}[], lang: Language = 'kk') => {
  try {
    const model = 'gemini-2.5-flash';
    
    const chat = ai.chats.create({
      model: model,
      config: {
        systemInstruction: getSystemInstruction(lang),
      },
      history: history.map(h => ({
        role: h.role,
        parts: [{ text: h.text }]
      }))
    });

    const result = await chat.sendMessage({ message });
    return result.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    if (lang === 'ru') return "Извините, сейчас я не могу ответить. Попробуйте позже.";
    if (lang === 'en') return "Sorry, I cannot reply right now. Please try again later.";
    return "Кешіріңіз, қазір жауап бере алмай тұрмын. Кейінірек қайталап көріңіз.";
  }
};