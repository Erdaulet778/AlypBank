
import React, { useState, useRef } from 'react';
import { Shield, Award, Star, TrendingUp, Calendar, Zap, Edit, CheckCircle, Camera } from 'lucide-react';
import { Language, ViewState } from '../types';
import { translations } from '../utils/translations';

interface UserProfileProps {
  userName: string;
  email: string;
  lang: Language;
  onNavigate: (view: ViewState) => void;
}

const UserProfile: React.FC<UserProfileProps> = ({ userName, email, lang, onNavigate }) => {
  const t = translations[lang].profile;
  
  // Graceful fallbacks for empty data
  const displayName = userName || "User";
  const displayEmail = email || "user@alypbank.kz";
  const initial = displayName.charAt(0).toUpperCase() || "U";
  
  // Profile Photo State
  const [avatar, setAvatar] = useState<string | null>(localStorage.getItem('alypbank_avatar'));
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const reader = new FileReader();
          reader.onloadend = () => {
              const base64 = reader.result as string;
              setAvatar(base64);
              localStorage.setItem('alypbank_avatar', base64);
          };
          reader.readAsDataURL(file);
      }
  };

  return (
    <div className="p-4 md:p-8 animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-5xl mx-auto">
      
      {/* Unified Profile Header Card */}
      <div className="relative mb-8 rounded-[2.5rem] bg-gradient-to-r from-accent-600 via-indigo-600 to-purple-600 p-8 md:p-12 overflow-hidden shadow-2xl group">
          
          {/* Decorative Background Elements */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none"></div>
          <div className="absolute bottom-0 left-0 w-80 h-80 bg-black/10 rounded-full blur-3xl -ml-20 -mb-20 pointer-events-none"></div>
          <div className="absolute top-1/2 left-1/2 w-full h-full bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 pointer-events-none"></div>

          {/* Edit Button */}
          <button 
            onClick={() => onNavigate('settings')}
            className="absolute top-6 right-6 p-3 bg-white/20 hover:bg-white/30 backdrop-blur-md rounded-2xl text-white transition-all hover:scale-105 active:scale-95 shadow-lg z-20"
            title={t.edit}
          >
              <Edit size={20} />
          </button>
          
          {/* Content Wrapper */}
          <div className="relative z-10 flex flex-col md:flex-row items-center gap-8 text-center md:text-left">
              
              {/* Avatar Box with Upload */}
              <div className="relative group/avatar">
                  <div className="w-32 h-32 md:w-40 md:h-40 rounded-[2rem] bg-white/20 backdrop-blur-md p-2 shadow-xl ring-1 ring-white/30 shrink-0 overflow-hidden">
                      {avatar ? (
                          <img src={avatar} alt="Profile" className="w-full h-full rounded-[1.5rem] object-cover shadow-inner" />
                      ) : (
                          <div className="w-full h-full rounded-[1.5rem] bg-white text-accent-600 flex items-center justify-center text-5xl md:text-6xl font-black shadow-inner">
                              {initial}
                          </div>
                      )}
                  </div>
                  
                  {/* Upload Overlay */}
                  <div 
                      onClick={() => fileInputRef.current?.click()}
                      className="absolute inset-0 bg-black/40 rounded-[2rem] flex items-center justify-center opacity-0 group-hover/avatar:opacity-100 transition-opacity cursor-pointer z-20 backdrop-blur-sm"
                  >
                      <Camera className="text-white" size={32} />
                  </div>
                  <input 
                      type="file" 
                      ref={fileInputRef} 
                      className="hidden" 
                      accept="image/*"
                      onChange={handleFileChange}
                  />
                  <div className="absolute -bottom-2 -right-2 bg-white text-accent-600 p-2 rounded-full shadow-lg z-30 pointer-events-none">
                      <Camera size={16} />
                  </div>
              </div>

              {/* User Details */}
              <div className="flex-1 space-y-2">
                  <h1 className="text-3xl md:text-5xl font-extrabold text-white tracking-tight drop-shadow-sm">
                      {displayName}
                  </h1>
                  
                  <div className="flex flex-col md:flex-row items-center gap-3 justify-center md:justify-start">
                      <span className="text-blue-100 font-medium text-lg">{displayEmail}</span>
                      <span className="hidden md:block text-blue-300">•</span>
                      <div className="px-3 py-1 rounded-full bg-white/20 backdrop-blur-md border border-white/20 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm">
                          <CheckCircle size={14} className="text-green-300" /> 
                          <span className="uppercase tracking-wider">Verified</span>
                      </div>
                  </div>

                  {/* Quick Stats in Header */}
                  <div className="pt-4 flex items-center gap-6 justify-center md:justify-start text-blue-100/80 text-sm font-medium">
                      <div className="flex items-center gap-2">
                          <Calendar size={16} /> Since 2023
                      </div>
                      <div className="flex items-center gap-2">
                           <Shield size={16} /> High Security
                      </div>
                  </div>
              </div>
          </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
          
          {/* Level Card */}
          <div className="bg-white/60 dark:bg-slate-900/60 backdrop-blur-xl border border-white/50 dark:border-white/5 p-6 rounded-[2rem] shadow-xl hover:-translate-y-1 transition-transform duration-300">
              <div className="flex justify-between items-start mb-4">
                  <div>
                      <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">{t.level}</h3>
                      <div className="flex items-baseline gap-2">
                          <span className="text-4xl font-black text-slate-800 dark:text-white">5</span>
                          <span className="text-lg font-bold text-accent-600">Gold</span>
                      </div>
                  </div>
                  <div className="p-3 bg-amber-100 dark:bg-amber-900/20 rounded-2xl text-amber-500">
                      <Zap size={24} />
                  </div>
              </div>
              
              <div className="space-y-2">
                  <div className="flex justify-between text-xs font-bold text-slate-400">
                      <span>Progress</span>
                      <span>750 / 1000 XP</span>
                  </div>
                  <div className="w-full h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full w-[75%] bg-gradient-to-r from-amber-400 to-orange-500 rounded-full shadow-[0_0_10px_rgba(251,191,36,0.5)]"></div>
                  </div>
              </div>
          </div>

          {/* Trust Score */}
          <div className="bg-white/60 dark:bg-slate-900/60 backdrop-blur-xl border border-white/50 dark:border-white/5 p-6 rounded-[2rem] shadow-xl hover:-translate-y-1 transition-transform duration-300">
              <div className="flex justify-between items-start mb-4">
                   <div>
                      <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">{t.trustScore}</h3>
                      <div className="flex items-baseline gap-2">
                          <span className="text-4xl font-black text-slate-800 dark:text-white">980</span>
                          <span className="px-2 py-0.5 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-lg text-xs font-bold uppercase">Excellent</span>
                      </div>
                   </div>
                   <div className="p-3 bg-emerald-100 dark:bg-emerald-900/20 rounded-2xl text-emerald-500">
                      <Shield size={24} />
                  </div>
              </div>
              <p className="text-sm font-medium text-slate-500 dark:text-slate-400 mt-4">
                  {t.memberSince}: <span className="text-slate-800 dark:text-white font-bold">2023</span>
              </p>
          </div>

          {/* Activity Stats */}
           <div className="bg-white/60 dark:bg-slate-900/60 backdrop-blur-xl border border-white/50 dark:border-white/5 p-6 rounded-[2rem] shadow-xl hover:-translate-y-1 transition-transform duration-300 flex flex-col justify-center gap-6">
              <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-900/20 flex items-center justify-center text-blue-600 dark:text-blue-400 shrink-0">
                      <TrendingUp size={24} />
                  </div>
                  <div>
                      <div className="text-2xl font-black text-slate-800 dark:text-white">1,240</div>
                      <div className="text-xs font-bold text-slate-400 uppercase">Transactions</div>
                  </div>
              </div>
              <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-purple-50 dark:bg-purple-900/20 flex items-center justify-center text-purple-600 dark:text-purple-400 shrink-0">
                      <Calendar size={24} />
                  </div>
                  <div>
                      <div className="text-2xl font-black text-slate-800 dark:text-white">124</div>
                      <div className="text-xs font-bold text-slate-400 uppercase">Days Active</div>
                  </div>
              </div>
          </div>
      </div>

      {/* Badges Section */}
      <div className="mt-12">
          <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-6 flex items-center gap-3">
              <div className="p-2 bg-accent-100 dark:bg-accent-900/30 rounded-xl text-accent-600">
                  <Award size={24} /> 
              </div>
              {t.badges}
          </h2>
          
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {[
                  { id: 'early', label: t.badgeNames.earlyAdopter, icon: <Star size={24} />, color: "bg-amber-50 text-amber-600 border-amber-100 dark:bg-amber-900/10 dark:border-amber-900/30 dark:text-amber-400" },
                  { id: 'saver', label: t.badgeNames.saver, icon: <Shield size={24} />, color: "bg-emerald-50 text-emerald-600 border-emerald-100 dark:bg-emerald-900/10 dark:border-emerald-900/30 dark:text-emerald-400" },
                  { id: 'investor', label: t.badgeNames.investor, icon: <TrendingUp size={24} />, color: "bg-blue-50 text-blue-600 border-blue-100 dark:bg-blue-900/10 dark:border-blue-900/30 dark:text-blue-400" },
                  { id: 'verified', label: t.badgeNames.verified, icon: <Zap size={24} />, color: "bg-purple-50 text-purple-600 border-purple-100 dark:bg-purple-900/10 dark:border-purple-900/30 dark:text-purple-400" },
              ].map((badge) => (
                  <div key={badge.id} className={`p-4 rounded-[1.5rem] border ${badge.color} backdrop-blur-sm flex flex-col items-center justify-center text-center gap-3 transition-all hover:scale-105 hover:shadow-lg cursor-pointer group`}>
                      <div className="p-3 rounded-full bg-white dark:bg-slate-800 shadow-sm group-hover:scale-110 transition-transform duration-300">
                          {badge.icon}
                      </div>
                      <span className="font-bold text-sm">{badge.label}</span>
                  </div>
              ))}
          </div>
      </div>
    </div>
  );
};

export default UserProfile;
