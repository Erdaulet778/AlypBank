import React from 'react';

const Background: React.FC = () => {
  return (
    <div className="fixed inset-0 w-full h-full overflow-hidden -z-10 pointer-events-none bg-slate-50 dark:bg-[#050505] transition-colors duration-700">
      
      {/* Dynamic Gradients */}
      <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-accent-50/50 via-white to-slate-100 dark:from-accent-900/20 dark:via-black dark:to-black opacity-100 transition-colors duration-700" />
      
      {/* Animated Blobs */}
      <div className="dark:opacity-30 opacity-60 transition-opacity duration-700">
          <div className="absolute top-[10%] left-[15%] w-96 h-96 bg-accent-500/20 rounded-full mix-blend-multiply dark:mix-blend-screen filter blur-[80px] animate-blob" />
          <div className="absolute top-[20%] right-[15%] w-96 h-96 bg-purple-500/20 rounded-full mix-blend-multiply dark:mix-blend-screen filter blur-[80px] animate-blob animation-delay-2000" />
          <div className="absolute bottom-[20%] left-[30%] w-96 h-96 bg-pink-500/20 rounded-full mix-blend-multiply dark:mix-blend-screen filter blur-[80px] animate-blob animation-delay-4000" />
      </div>

      {/* Grid Pattern Overlay */}
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 dark:opacity-10 mix-blend-soft-light"></div>
      
      {/* Floating Particles */}
      <div className="absolute top-[15%] left-[10%] w-4 h-4 bg-accent-500/30 rounded-full animate-float blur-[1px]" />
      <div className="absolute top-[45%] right-[20%] w-3 h-3 bg-purple-500/30 rounded-full animate-float delay-1000 blur-[1px]" />
      <div className="absolute bottom-[30%] left-[20%] w-6 h-6 bg-pink-500/30 rounded-full animate-float delay-2000 blur-[2px]" />
      <div className="absolute top-[70%] right-[30%] w-2 h-2 bg-accent-400/40 rounded-full animate-float delay-500" />
    </div>
  );
};

export default Background;