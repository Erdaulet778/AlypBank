
import React, { useState, useEffect, useRef } from 'react';
import { 
  Bell, 
  CreditCard, 
  ShoppingBag, 
  MessageSquare, 
  Info, 
  Package, 
  Truck, 
  CheckCircle, 
  Clock,
  Send,
  User,
  MoreVertical,
  Shield
} from 'lucide-react';
import { Language, Notification, ChatMessage } from '../types';
import { translations } from '../utils/translations';
import { sendMessageToGemini } from '../services/geminiService';

interface MessagesViewProps {
  lang: Language;
}

const MessagesView: React.FC<MessagesViewProps> = ({ lang }) => {
  const t = translations[lang].messages;
  const tGlobal = translations[lang];
  
  const [activeTab, setActiveTab] = useState<'all' | 'payments' | 'shop' | 'news' | 'support'>('all');
  
  // State for notifications including dynamic ones
  const [notifications, setNotifications] = useState<Notification[]>([]);

  // Base Dummy Data
  const dummyNotifications: Notification[] = [
    { id: '1', type: 'payment', title: 'Payment Sent', message: 'You sent 5000 ₸ to Alibek', date: '10:30 AM', read: false, amount: '-5000 ₸' },
    { id: '2', type: 'shop', title: 'Order #8921', message: 'Your order has arrived at customs', date: 'Yesterday', read: true, status: 'customs' },
    { id: '3', type: 'news', title: 'New Loan Program', message: '7-20-25 program is now available for application.', date: '2 days ago', read: true },
    { id: '4', type: 'payment', title: 'Internet Bill', message: 'Automatic payment for KazakhTelecom', date: '3 days ago', read: true, amount: '-4500 ₸' },
    { id: '5', type: 'shop', title: 'Order #8920', message: 'Delivered successfully', date: 'Last week', read: true, status: 'delivered' },
  ];

  // Load notifications
  useEffect(() => {
      // Get dynamic notifications from local storage (e.g., recent orders)
      const stored = JSON.parse(localStorage.getItem('alypbank_notifications') || '[]');
      setNotifications([...stored, ...dummyNotifications]);
  }, []);

  // Chat State
  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatLoading, setChatLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initial Chat Message
    setChatMessages([
        { id: 'welcome', role: 'model', text: tGlobal.chat.welcome, timestamp: new Date() }
    ]);
  }, [lang]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, activeTab]);

  const handleSendChat = async () => {
    if (!chatInput.trim()) return;
    const userMsg: ChatMessage = { id: Date.now().toString(), role: 'user', text: chatInput, timestamp: new Date() };
    setChatMessages(prev => [...prev, userMsg]);
    setChatInput('');
    setChatLoading(true);

    try {
        const history = chatMessages.map(m => ({ role: m.role, text: m.text }));
        const response = await sendMessageToGemini(chatInput, history, lang);
        setChatMessages(prev => [...prev, { 
            id: (Date.now()+1).toString(), 
            role: 'model', 
            text: response || "Error", 
            timestamp: new Date() 
        }]);
    } catch (e) {
        console.error(e);
    } finally {
        setChatLoading(false);
    }
  };

  const getFilteredNotifications = () => {
    if (activeTab === 'all') return notifications;
    if (activeTab === 'support') return []; // Handled separately
    return notifications.filter(n => n.type === activeTab);
  };

  const getIcon = (type: string) => {
    switch (type) {
        case 'payment': return <CreditCard size={20} />;
        case 'shop': return <ShoppingBag size={20} />;
        case 'news': return <Info size={20} />;
        case 'support': return <MessageSquare size={20} />;
        default: return <Bell size={20} />;
    }
  };

  const getStatusStep = (status?: string) => {
      switch(status) {
          case 'ordered': return 1;
          case 'shipped': return 2;
          case 'customs': return 3;
          case 'delivery': return 4;
          case 'delivered': return 5;
          default: return 0;
      }
  };

  return (
    <div className="p-4 md:p-8 animate-in fade-in slide-in-from-bottom-4 duration-500 h-full flex flex-col">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold dark:text-white">{t.title}</h1>
        <div className="bg-white dark:bg-slate-900 rounded-xl p-1 shadow-sm border border-slate-100 dark:border-slate-800 flex">
            {(['all', 'payments', 'shop', 'news', 'support'] as const).map(tab => (
                <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                        activeTab === tab 
                        ? 'bg-blue-600 text-white shadow-md' 
                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                >
                    {t.tabs[tab]}
                </button>
            ))}
        </div>
      </div>

      <div className="flex-1 bg-white dark:bg-slate-900 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden relative">
        {activeTab === 'support' ? (
            // Support Chat Interface
            <div className="flex flex-col h-[600px] md:h-[calc(100vh-250px)]">
                <div className="p-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white">
                        <MessageSquare size={20} />
                    </div>
                    <div>
                        <h3 className="font-bold text-slate-800 dark:text-white">{t.supportTitle}</h3>
                        <p className="text-xs text-green-500 flex items-center gap-1">
                            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span> Online
                        </p>
                    </div>
                </div>
                
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {chatMessages.map(msg => (
                        <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            {msg.role === 'model' && (
                                <div className="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center text-indigo-600 dark:text-indigo-400 mr-2 shrink-0">
                                    <MessageSquare size={14} />
                                </div>
                            )}
                            <div className={`max-w-[70%] p-3 rounded-2xl text-sm ${
                                msg.role === 'user' 
                                ? 'bg-blue-600 text-white rounded-tr-none' 
                                : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-white rounded-tl-none'
                            }`}>
                                {msg.text}
                            </div>
                        </div>
                    ))}
                    {chatLoading && (
                        <div className="flex justify-start">
                             <div className="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center text-indigo-600 dark:text-indigo-400 mr-2 shrink-0">
                                    <MessageSquare size={14} />
                            </div>
                            <div className="bg-slate-100 dark:bg-slate-800 p-3 rounded-2xl rounded-tl-none">
                                <div className="flex gap-1">
                                    <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></span>
                                    <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce delay-100"></span>
                                    <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce delay-200"></span>
                                </div>
                            </div>
                        </div>
                    )}
                    <div ref={chatEndRef}></div>
                </div>

                <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900">
                    <div className="flex gap-2">
                        <input 
                            type="text" 
                            value={chatInput}
                            onChange={(e) => setChatInput(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleSendChat()}
                            placeholder={t.chatPlaceholder}
                            className="flex-1 px-4 py-3 rounded-xl bg-slate-50 dark:bg-black border border-slate-200 dark:border-slate-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                        <button onClick={handleSendChat} className="p-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors">
                            <Send size={20} />
                        </button>
                    </div>
                </div>
            </div>
        ) : (
            // Notification List
            <div className="divide-y divide-slate-100 dark:divide-slate-800 overflow-y-auto h-[600px] md:h-[calc(100vh-250px)]">
                {getFilteredNotifications().length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-slate-400 p-8">
                        <Bell size={48} className="mb-4 opacity-20" />
                        <p>{t.empty}</p>
                    </div>
                ) : (
                    getFilteredNotifications().map((item) => (
                        <div key={item.id} className="p-6 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors group">
                            <div className="flex items-start gap-4">
                                <div className={`w-12 h-12 rounded-full flex items-center justify-center shrink-0
                                    ${item.type === 'payment' ? 'bg-emerald-100 text-emerald-600 dark:bg-emerald-900/30' : ''}
                                    ${item.type === 'shop' ? 'bg-pink-100 text-pink-600 dark:bg-pink-900/30' : ''}
                                    ${item.type === 'news' ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/30' : ''}
                                `}>
                                    {getIcon(item.type)}
                                </div>
                                <div className="flex-1">
                                    <div className="flex justify-between items-start mb-1">
                                        <h4 className="font-bold text-slate-800 dark:text-white">{item.title}</h4>
                                        <span className="text-xs text-slate-400">{item.date}</span>
                                    </div>
                                    <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">{item.message}</p>
                                    
                                    {item.amount && (
                                        <div className="text-lg font-bold text-slate-800 dark:text-white">
                                            {item.amount}
                                        </div>
                                    )}

                                    {/* Tracking Visualization for Shop Items */}
                                    {item.type === 'shop' && item.status && (
                                        <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800">
                                            <h5 className="text-xs font-bold uppercase text-slate-400 mb-4">{t.tracking.title}</h5>
                                            <div className="relative flex justify-between items-center px-2">
                                                {/* Connecting Line */}
                                                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-0.5 bg-slate-200 dark:bg-slate-700 -z-10"></div>
                                                <div className={`absolute left-0 top-1/2 -translate-y-1/2 h-0.5 bg-green-500 -z-10 transition-all duration-1000`} style={{ width: `${(getStatusStep(item.status) - 1) * 25}%` }}></div>

                                                {[
                                                    { id: 'ordered', icon: <Package size={14} />, label: t.tracking.ordered },
                                                    { id: 'shipped', icon: <Truck size={14} />, label: t.tracking.shipped },
                                                    { id: 'customs', icon: <Shield size={14} />, label: t.tracking.customs }, // Using Shield as Customs icon
                                                    { id: 'delivery', icon: <Truck size={14} />, label: t.tracking.delivery },
                                                    { id: 'delivered', icon: <CheckCircle size={14} />, label: t.tracking.delivered },
                                                ].map((step, idx) => {
                                                    const isCompleted = getStatusStep(item.status) >= idx + 1;
                                                    const isCurrent = getStatusStep(item.status) === idx + 1;
                                                    return (
                                                        <div key={step.id} className="flex flex-col items-center gap-2 bg-white dark:bg-slate-900 px-1">
                                                            <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 transition-all
                                                                ${isCompleted ? 'bg-green-500 border-green-500 text-white' : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-300'}
                                                                ${isCurrent ? 'ring-4 ring-green-100 dark:ring-green-900/30' : ''}
                                                            `}>
                                                                {step.icon}
                                                            </div>
                                                            <span className={`text-[10px] font-medium text-center max-w-[60px] ${isCompleted ? 'text-green-600 dark:text-green-400' : 'text-slate-400'}`}>
                                                                {step.label}
                                                            </span>
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                            {item.status === 'customs' && (
                                                <div className="mt-4 p-3 bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400 text-xs rounded-lg flex items-center gap-2">
                                                    <Clock size={14} />
                                                    {t.tracking.estimated}: 3-5 days
                                                </div>
                                            )}
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    ))
                )}
            </div>
        )}
      </div>
    </div>
  );
};

export default MessagesView;
