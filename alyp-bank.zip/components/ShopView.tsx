import React, { useState } from 'react';
import { Search, ShoppingCart, Star, Heart, Monitor, Smartphone, ShoppingBasket, Shirt, Home, Dumbbell, BookOpen, ChevronRight, X, Check, Zap, Percent, Gift, Apple, Milk, Croissant, Beef, Coffee, ArrowLeft, Minus, Plus, Trash2, CreditCard, Loader2, CheckCircle, Truck, Package, RotateCcw, ChevronLeft, Shield, Gamepad2 } from 'lucide-react';
import { Language, Notification } from '../types';
import { translations } from '../utils/translations';

interface ShopViewProps {
  lang: Language;
}

interface Product {
    id: number;
    title: string;
    price: number;
    originalPrice: number | null;
    bonusPercent: number;
    image: string;
    category: string;
    isMagnum?: boolean;
    isApple?: boolean;
    isSamsung?: boolean;
    isAsus?: boolean;
    colors?: string[];
}

interface CartItem {
    product: Product;
    quantity: number;
}

const ShopView: React.FC<ShopViewProps> = ({ lang }) => {
  const t = translations[lang].shop;
  
  const [viewMode, setViewMode] = useState<'general' | 'magnum' | 'iphone' | 'samsung' | 'asus'>('general');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  
  // Filters
  const [magnumFilter, setMagnumFilter] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [activeStory, setActiveStory] = useState<string | null>(null);
  
  // Cart State
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  
  // Wishlist State
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);

  // Payment State
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [paymentStep, setPaymentStep] = useState<'method' | 'processing' | 'success'>('method');
  const [selectedCard, setSelectedCard] = useState('gold');

  // Helper to generate dates
  const getDeliveryDates = () => {
      const today = new Date();
      const shippingDate = new Date(today); // Ships today
      const deliveryDate = new Date(today.setDate(today.getDate() + 3)); // 3 days later
      
      return {
          ship: shippingDate.toLocaleDateString(),
          deliver: deliveryDate.toLocaleDateString()
      };
  };

  const dates = getDeliveryDates();

  // Categories
  const categories = [
    { id: 'phones', label: t.categories.phones, icon: <Smartphone size={24} />, color: "bg-blue-100 text-blue-600" },
    { id: 'computers', label: t.categories.computers, icon: <Monitor size={24} />, color: "bg-purple-100 text-purple-600" },
    { id: 'groceries', label: t.categories.groceries, icon: <ShoppingBasket size={24} />, color: "bg-red-100 text-red-600" },
    { id: 'clothes', label: t.categories.clothes, icon: <Shirt size={24} />, color: "bg-pink-100 text-pink-600" },
    { id: 'home', label: t.categories.home, icon: <Home size={24} />, color: "bg-orange-100 text-orange-600" },
    { id: 'sport', label: t.categories.sport, icon: <Dumbbell size={24} />, color: "bg-green-100 text-green-600" },
    { id: 'books', label: t.categories.books, icon: <BookOpen size={24} />, color: "bg-yellow-100 text-yellow-600" },
  ];

  const magnumCategories = [
      { id: 'fruits', label: t.magnumCategories.fruits, icon: <Apple size={24} />, color: "bg-red-100 text-red-600" },
      { id: 'vegetables', label: t.magnumCategories.vegetables, icon: <Apple size={24} />, color: "bg-green-100 text-green-600" },
      { id: 'dairy', label: t.magnumCategories.dairy, icon: <Milk size={24} />, color: "bg-blue-100 text-blue-600" },
      { id: 'bakery', label: t.magnumCategories.bakery, icon: <Croissant size={24} />, color: "bg-yellow-100 text-yellow-600" },
      { id: 'meat', label: t.magnumCategories.meat, icon: <Beef size={24} />, color: "bg-rose-100 text-rose-600" },
      { id: 'drinks', label: t.magnumCategories.drinks, icon: <Coffee size={24} />, color: "bg-amber-100 text-amber-600" },
  ];

  // Promo Stories
  const stories = [
      { id: 'sale', label: t.stories.sale, color: "from-red-500 to-pink-500", icon: <Percent size={24} /> },
      { id: 'bonus', label: t.stories.bonus, color: "from-green-400 to-emerald-600", icon: <Gift size={24} /> },
      { id: 'new', label: t.stories.new, color: "from-blue-400 to-indigo-600", icon: <Zap size={24} /> },
      { id: 'tech', label: t.stories.tech, color: "from-purple-500 to-violet-600", icon: <Smartphone size={24} /> },
  ];

  // Enhanced Products
  const products: Product[] = [
    { id: 1, title: 'iPhone 15 Pro', price: 549990, originalPrice: 650000, bonusPercent: 10, image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&q=80&w=300&h=300', category: 'phones', isApple: true, colors: ['#5e5e5e', '#f2f2f2', '#2e3a59'] },
    { id: 2, title: 'MacBook Air M2', price: 629990, originalPrice: null, bonusPercent: 5, image: 'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?auto=format&fit=crop&q=80&w=300&h=300', category: 'computers', isApple: true },
    { id: 3, title: 'Magnum Milk 3.2%', price: 450, originalPrice: 500, bonusPercent: 0, image: 'https://images.unsplash.com/photo-1563636619-e9143da7973b?auto=format&fit=crop&q=80&w=300&h=300', category: 'dairy', isMagnum: true },
    { id: 4, title: 'Sony WH-1000XM5', price: 159990, originalPrice: 199990, bonusPercent: 15, image: 'https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?auto=format&fit=crop&q=80&w=300&h=300', category: 'phones' },
    { id: 5, title: 'Fresh Bread', price: 180, originalPrice: null, bonusPercent: 0, image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&q=80&w=300&h=300', category: 'bakery', isMagnum: true },
    { id: 6, title: 'Nike Air Max', price: 41990, originalPrice: 59990, bonusPercent: 30, image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=300&h=300', category: 'clothes' },
    { id: 7, title: 'PlayStation 5', price: 299990, originalPrice: 350000, bonusPercent: 25, image: 'https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?auto=format&fit=crop&q=80&w=300&h=300', category: 'computers' },
    // Samsung S24 Ultra
    { id: 8, title: 'Samsung S24 Ultra', price: 699990, originalPrice: null, bonusPercent: 10, image: 'https://images.unsplash.com/photo-1610945265078-386f3b58d86f?auto=format&fit=crop&q=80&w=300&h=300', category: 'phones', isSamsung: true, colors: ['#000000', '#cccccc', '#f2c300'] },
    
    // Magnum Items
    { id: 9, title: 'Coca-Cola 1L', price: 400, originalPrice: 450, bonusPercent: 0, image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&q=80&w=300&h=300', category: 'drinks', isMagnum: true },
    { id: 10, title: 'Bananas (kg)', price: 850, originalPrice: 950, bonusPercent: 5, image: 'https://images.unsplash.com/photo-1603833665858-e61d17a86224?auto=format&fit=crop&q=80&w=300&h=300', category: 'fruits', isMagnum: true },
    { id: 11, title: 'Chicken Fillet', price: 2200, originalPrice: null, bonusPercent: 0, image: 'https://images.unsplash.com/photo-1604503468506-a8da13d82791?auto=format&fit=crop&q=80&w=300&h=300', category: 'meat', isMagnum: true },
    { id: 12, title: 'Red Apples (kg)', price: 600, originalPrice: 750, bonusPercent: 0, image: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&q=80&w=300&h=300', category: 'fruits', isMagnum: true },
    { id: 13, title: 'Croissant', price: 450, originalPrice: null, bonusPercent: 0, image: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&q=80&w=300&h=300', category: 'bakery', isMagnum: true },
    
    // Apple Specific
    { id: 14, title: 'iPhone 15', price: 499990, originalPrice: null, bonusPercent: 5, image: 'https://images.unsplash.com/photo-1696446701796-da61225697cc?auto=format&fit=crop&q=80&w=300&h=300', category: 'phones', isApple: true, colors: ['#e3e3e3', '#f9e5c9', '#a9c5db', '#000000'] },
    { id: 15, title: 'Apple Watch Ultra 2', price: 399990, originalPrice: 450000, bonusPercent: 10, image: 'https://images.unsplash.com/photo-1695663737526-79c3132e0163?auto=format&fit=crop&q=80&w=300&h=300', category: 'phones', isApple: true },
    { id: 16, title: 'AirPods Max', price: 289990, originalPrice: null, bonusPercent: 5, image: 'https://images.unsplash.com/photo-1613040996389-58f094a147d3?auto=format&fit=crop&q=80&w=300&h=300', category: 'phones', isApple: true, colors: ['#ffffff', '#000000', '#ffb6c1', '#87ceeb'] },

    // Samsung Specific
    { id: 17, title: 'Samsung Z Fold 5', price: 999990, originalPrice: 1200000, bonusPercent: 15, image: 'https://images.unsplash.com/photo-1626958390843-2d2571c042eb?auto=format&fit=crop&q=80&w=300&h=300', category: 'phones', isSamsung: true },
    { id: 18, title: 'Galaxy Watch 6', price: 149990, originalPrice: 179990, bonusPercent: 5, image: 'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?auto=format&fit=crop&q=80&w=300&h=300', category: 'phones', isSamsung: true },
    { id: 19, title: 'Galaxy Buds2 Pro', price: 79990, originalPrice: 99990, bonusPercent: 5, image: 'https://images.unsplash.com/photo-1649007604537-293672522759?auto=format&fit=crop&q=80&w=300&h=300', category: 'phones', isSamsung: true },

    // Asus ROG Specific
    { id: 20, title: 'ROG Phone 8 Pro', price: 649990, originalPrice: null, bonusPercent: 10, image: 'https://images.unsplash.com/photo-1592899677712-a503855c9b6b?auto=format&fit=crop&q=80&w=300&h=300', category: 'phones', isAsus: true },
    { id: 21, title: 'ROG Zephyrus G14', price: 899990, originalPrice: 950000, bonusPercent: 5, image: 'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?auto=format&fit=crop&q=80&w=300&h=300', category: 'computers', isAsus: true },
    { id: 22, title: 'ROG Ally', price: 349990, originalPrice: 399990, bonusPercent: 5, image: 'https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&q=80&w=300&h=300', category: 'computers', isAsus: true },
  ];

  const getMonthlyPrice = (price: number) => {
    return Math.round(price / 12).toLocaleString();
  };

  const calculateDiscount = (price: number, original: number) => {
      return Math.round(((original - price) / original) * 100);
  };

  const addToCart = (product: Product, quantity: number = 1) => {
    setCartItems(prev => {
        const existing = prev.find(item => item.product.id === product.id);
        if (existing) {
            return prev.map(item => item.product.id === product.id ? { ...item, quantity: item.quantity + quantity } : item);
        }
        return [...prev, { product, quantity }];
    });
  };

  const removeFromCart = (id: number) => {
      setCartItems(prev => prev.filter(item => item.product.id !== id));
  };

  const updateQuantity = (id: number, delta: number) => {
      setCartItems(prev => prev.map(item => {
          if (item.product.id === id) {
              const newQty = Math.max(1, item.quantity + delta);
              return { ...item, quantity: newQty };
          }
          return item;
      }));
  };

  const toggleWishlist = (e: React.MouseEvent, id: number) => {
      e.stopPropagation();
      setWishlist(prev => prev.includes(id) ? prev.filter(wid => wid !== id) : [...prev, id]);
  };

  const handleBuyNow = () => {
      if (selectedProduct) {
          addToCart(selectedProduct);
          setSelectedProduct(null);
          setIsCartOpen(false);
          setIsPaymentOpen(true);
          setPaymentStep('method');
      }
  };

  const openCheckout = () => {
      setIsCartOpen(false);
      setIsPaymentOpen(true);
      setPaymentStep('method');
  };

  const handleCategoryClick = (catId: string) => {
      if (catId === 'groceries') {
          setViewMode('magnum');
          return;
      }
      setActiveCategory(activeCategory === catId ? null : catId);
      setActiveStory(null);
  };

  const handleStoryClick = (storyId: string) => {
      setActiveStory(activeStory === storyId ? null : storyId);
      setActiveCategory(null);
  };

  // Helper to create notification on purchase
  const createOrderNotification = () => {
      const orderId = Math.floor(1000 + Math.random() * 9000);
      const newNotification: Notification = {
          id: Date.now().toString(),
          type: 'shop',
          title: `Order #${orderId}`,
          message: `Order #${orderId} has been placed. Expected delivery: ${dates.deliver}`,
          date: 'Just now',
          read: false,
          status: 'ordered'
      };
      
      // Save to localStorage so MessagesView can pick it up
      const existing = JSON.parse(localStorage.getItem('alypbank_notifications') || '[]');
      localStorage.setItem('alypbank_notifications', JSON.stringify([newNotification, ...existing]));
  };

  const processPayment = () => {
      setPaymentStep('processing');
      setTimeout(() => {
          setPaymentStep('success');
          createOrderNotification(); // Create notification
          setCartItems([]); // Clear cart
      }, 2000);
  };

  const filteredProducts = products.filter(p => {
      if (viewMode === 'iphone') return p.isApple;
      if (viewMode === 'samsung') return p.isSamsung;
      if (viewMode === 'asus') return p.isAsus;

      const modeMatch = viewMode === 'magnum' ? p.isMagnum : !p.isMagnum;
      if (!modeMatch) return false;

      // Search filter
      if (searchQuery && !p.title.toLowerCase().includes(searchQuery.toLowerCase())) return false;

      // Magnum specific category/deals filter
      if (viewMode === 'magnum' && magnumFilter) {
          if (magnumFilter === 'deals') return !!p.originalPrice;
          return p.category === magnumFilter;
      }

      // General View Filters
      if (viewMode === 'general') {
          if (activeCategory) {
              return p.category === activeCategory;
          }
          if (activeStory) {
              if (activeStory === 'sale') return !!p.originalPrice;
              if (activeStory === 'bonus') return p.bonusPercent > 0;
              if (activeStory === 'new') return p.id > 4; 
              if (activeStory === 'tech') return ['phones', 'computers'].includes(p.category);
          }
      }

      return true;
  });

  const cartTotal = cartItems.reduce((acc, item) => acc + (item.product.price * item.quantity), 0);
  const cartItemCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  // Filter products for wishlist
  const wishlistProducts = products.filter(p => wishlist.includes(p.id));

  // Determine styles based on view mode
  const getThemeStyles = () => {
      if (viewMode === 'iphone') return 'bg-[#1a1a1a] text-white border-white/10';
      if (viewMode === 'asus') return 'bg-zinc-900 text-white border-red-900/30 shadow-[0_0_15px_rgba(220,38,38,0.1)]';
      if (viewMode === 'samsung') return 'bg-white text-black border-slate-200';
      return 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800';
  };

  // Product Card Component
  const ProductCard = ({ product }: { product: Product }) => {
    const isLiked = wishlist.includes(product.id);
    const themeClass = getThemeStyles();

    return (
        <div 
            onClick={() => setSelectedProduct(product)}
            className={`
                rounded-2xl p-4 transition-all cursor-pointer group relative flex flex-col h-full border shadow-sm hover:shadow-xl hover:-translate-y-1
                ${themeClass}
                ${viewMode === 'asus' ? 'hover:shadow-[0_0_20px_rgba(220,38,38,0.4)] hover:border-red-600' : ''}
            `}
        >
            {/* Badges Container */}
            <div className="absolute top-4 left-4 z-10 flex flex-col gap-1.5">
                {product.originalPrice && (
                    <span className="px-2 py-1 bg-red-500 text-white text-[10px] font-bold rounded-lg shadow-sm">
                        -{calculateDiscount(product.price, product.originalPrice)}%
                    </span>
                )}
                {product.bonusPercent > 0 && (
                    <span className={`px-2 py-1 text-[10px] font-bold rounded-lg shadow-sm ${viewMode === 'asus' ? 'bg-red-600 text-white' : 'bg-green-500 text-white'}`}>
                        +{product.bonusPercent}% B
                    </span>
                )}
            </div>

            {/* Favorite Button */}
            <button 
                onClick={(e) => toggleWishlist(e, product.id)}
                className={`absolute top-4 right-4 p-2 backdrop-blur-sm rounded-full transition-colors z-10 ${isLiked ? 'bg-red-50 text-red-500' : 'bg-white/50 hover:bg-white text-slate-500 hover:text-red-500'}`}
            >
                <Heart size={18} fill={isLiked ? "currentColor" : "none"} />
            </button>

            {/* Image */}
            <div className={`aspect-square rounded-xl overflow-hidden mb-4 flex items-center justify-center ${viewMode === 'asus' ? 'bg-black border border-white/5' : viewMode === 'iphone' ? 'bg-black' : 'bg-slate-50 dark:bg-slate-800'}`}>
                <img src={product.image} alt={product.title} className="max-w-full max-h-full object-cover group-hover:scale-110 transition-transform duration-500" />
            </div>

            {/* Info */}
            <div className="flex-1 flex flex-col">
                <h3 className={`font-medium line-clamp-2 h-10 mb-1 leading-snug ${viewMode === 'iphone' || viewMode === 'asus' ? 'font-bold text-lg' : ''}`}>
                    {product.title}
                </h3>
                
                {/* Installment Badge */}
                {!product.isMagnum && (
                    <div className={`inline-block self-start px-2 py-0.5 rounded-md mb-2 ${viewMode === 'iphone' || viewMode === 'asus' ? 'bg-white/10 text-white/70' : 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400'}`}>
                        <span className="text-xs font-bold">
                            {getMonthlyPrice(product.price)} ₸ x 12
                        </span>
                    </div>
                )}

                {/* Colors Mockup */}
                {(viewMode === 'iphone' || viewMode === 'samsung') && product.colors && (
                    <div className="flex gap-2 mb-2">
                        {product.colors.map(c => (
                            <div key={c} className="w-3 h-3 rounded-full border border-black/10" style={{ backgroundColor: c }}></div>
                        ))}
                    </div>
                )}

                <div className="mt-auto">
                    {product.originalPrice && (
                        <div className="text-xs opacity-50 line-through mb-0.5">
                            {product.originalPrice.toLocaleString()} ₸
                        </div>
                    )}
                    <div className="flex items-center justify-between">
                        <span className={`text-lg font-bold ${product.originalPrice ? 'text-red-500' : ''}`}>
                            {product.price.toLocaleString()} ₸
                        </span>
                        <button 
                            onClick={(e) => { e.stopPropagation(); addToCart(product); setIsCartOpen(true); }}
                            className={`p-2 rounded-lg transition-colors ${viewMode === 'magnum' ? 'bg-red-50 text-red-600 hover:bg-red-100' : viewMode === 'iphone' || viewMode === 'asus' ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 hover:bg-blue-100'}`}
                        >
                            <ShoppingCart size={18} />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
  };

  const getPageBackground = () => {
      if (viewMode === 'magnum') return 'bg-red-50 dark:bg-red-950/20';
      if (viewMode === 'iphone') return 'bg-black text-white';
      if (viewMode === 'asus') return 'bg-[#060606] text-white';
      if (viewMode === 'samsung') return 'bg-[#f4f4f4] text-black';
      return '';
  };

  return (
    <div className={`min-h-screen transition-colors duration-500 ${getPageBackground()}`}>
        <div className="p-4 md:p-8 animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between mb-8 gap-4">
            {viewMode !== 'general' ? (
                 <div className="flex items-center gap-4">
                     <button onClick={() => { setViewMode('general'); setMagnumFilter(null); }} className={`p-2 rounded-full shadow-sm transition-all ${viewMode === 'iphone' || viewMode === 'asus' ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-white text-slate-700 hover:bg-slate-100'}`}>
                         <ArrowLeft size={24} />
                     </button>
                     {viewMode === 'iphone' && <h1 className="text-3xl font-bold tracking-tight"> Apple Zone</h1>}
                     {viewMode === 'samsung' && <h1 className="text-3xl font-bold tracking-tight text-blue-700">SAMSUNG</h1>}
                     {viewMode === 'asus' && <h1 className="text-3xl font-extrabold tracking-widest text-red-600 font-mono italic">ROG</h1>}
                     {viewMode === 'magnum' && <h1 className="text-3xl font-bold text-red-600 italic">Magnum</h1>}
                 </div>
            ) : (
                <h1 className="text-3xl font-bold dark:text-white hidden md:block">{t.title}</h1>
            )}
            
            {/* Search */}
            <div className="flex-1 max-w-2xl relative">
                <input 
                    type="text" 
                    placeholder={viewMode === 'magnum' ? t.magnumSearch : t.search}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className={`w-full pl-12 pr-4 py-3 rounded-2xl border shadow-sm focus:ring-2 outline-none transition-all
                        ${viewMode === 'magnum' ? 'bg-white border-red-100 focus:ring-red-500 placeholder:text-red-300 text-red-900' :
                          viewMode === 'iphone' ? 'bg-[#1a1a1a] border-white/10 focus:ring-white placeholder:text-gray-500 text-white' :
                          viewMode === 'asus' ? 'bg-zinc-900 border-red-900/50 focus:ring-red-600 placeholder:text-zinc-600 text-white' :
                          viewMode === 'samsung' ? 'bg-white border-blue-200 focus:ring-blue-600 text-black' :
                          'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800 focus:ring-blue-500 dark:text-white'}
                    `}
                />
                <Search className={`absolute left-4 top-1/2 -translate-y-1/2 opacity-50 ${viewMode === 'magnum' ? 'text-red-400' : ''}`} size={20} />
            </div>

            {/* Actions */}
            <div className="flex gap-2">
                <button 
                    onClick={() => setIsWishlistOpen(true)}
                    className={`relative p-3 rounded-xl border border-transparent transition-all ${viewMode === 'iphone' || viewMode === 'asus' ? 'hover:bg-white/10 text-white' : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-white'}`}
                >
                    <Heart size={24} fill={wishlist.length > 0 ? "currentColor" : "none"} className={wishlist.length > 0 ? "text-red-500" : ""} />
                    {wishlist.length > 0 && (
                        <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center animate-in zoom-in">
                            {wishlist.length}
                        </span>
                    )}
                </button>
                <button 
                    onClick={() => setIsCartOpen(true)}
                    className={`relative p-3 rounded-xl border transition-colors ${
                        viewMode === 'magnum' ? 'bg-white border-red-100 hover:bg-red-50 text-red-600' : 
                        viewMode === 'iphone' || viewMode === 'asus' ? 'bg-white/5 border-white/10 hover:bg-white/10 text-white' : 
                        viewMode === 'samsung' ? 'bg-white border-slate-200 hover:bg-slate-50 text-black' :
                        'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-white'
                    }`}
                >
                    <ShoppingCart size={24} />
                    {cartItemCount > 0 && (
                        <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center animate-in zoom-in">
                            {cartItemCount}
                        </span>
                    )}
                </button>
            </div>
        </div>

        {/* Wishlist Drawer */}
        <div className={`fixed inset-y-0 right-0 w-full md:w-[400px] bg-white dark:bg-slate-900 shadow-2xl transform transition-transform duration-300 z-50 flex flex-col ${isWishlistOpen ? 'translate-x-0' : 'translate-x-full'}`}>
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                 <h2 className="text-2xl font-bold dark:text-white flex items-center gap-2">
                     <Heart className="text-red-500" fill="currentColor" /> {t.wishlistTitle}
                 </h2>
                 <button onClick={() => setIsWishlistOpen(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full dark:text-white">
                     <X size={24} />
                 </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {wishlistProducts.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-slate-400">
                        <Heart size={64} className="mb-4 opacity-20" />
                        <p>{t.emptyWishlist}</p>
                    </div>
                ) : (
                    wishlistProducts.map(product => (
                        <div key={product.id} className="flex gap-4 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                            <div className="w-20 h-20 rounded-lg bg-white dark:bg-slate-800 shrink-0 overflow-hidden">
                                <img src={product.image} alt="" className="w-full h-full object-cover" />
                            </div>
                            <div className="flex-1 flex flex-col justify-between">
                                <h4 className="font-bold text-slate-800 dark:text-white line-clamp-1">{product.title}</h4>
                                <div className="text-sm font-bold text-slate-500">{product.price.toLocaleString()} ₸</div>
                                <button 
                                    onClick={() => { addToCart(product); toggleWishlist({ stopPropagation: () => {} } as any, product.id); }}
                                    className="text-xs bg-blue-600 text-white px-3 py-1.5 rounded-lg self-start mt-1 hover:bg-blue-700"
                                >
                                    {t.moveToCart}
                                </button>
                            </div>
                            <button onClick={(e) => toggleWishlist(e, product.id)} className="text-slate-400 hover:text-red-500 self-start">
                                <X size={16} />
                            </button>
                        </div>
                    ))
                )}
            </div>
        </div>

        {/* VIEW MODES */}
        {viewMode === 'general' ? (
            <>
                {/* Stories */}
                <div className="flex gap-6 overflow-x-auto no-scrollbar mb-10 pb-2">
                    {stories.map(story => (
                        <div key={story.id} onClick={() => handleStoryClick(story.id)} className="flex flex-col items-center gap-2 cursor-pointer group">
                            <div className={`w-18 h-18 p-1 rounded-full bg-gradient-to-br ${story.color} transition-transform ${activeStory === story.id ? 'ring-4 ring-offset-2 ring-accent-500 scale-110' : 'group-hover:scale-105'}`}>
                                <div className="w-16 h-16 rounded-full bg-white dark:bg-slate-900 border-2 border-transparent flex items-center justify-center text-slate-700 dark:text-white">
                                        {story.icon}
                                </div>
                            </div>
                            <span className={`text-xs font-semibold ${activeStory === story.id ? 'text-accent-600 dark:text-accent-400' : 'dark:text-slate-200'}`}>{story.label}</span>
                        </div>
                    ))}
                    {categories.slice(0, 4).map(cat => (
                        <div key={cat.id} onClick={() => handleCategoryClick(cat.id)} className={`flex flex-col items-center gap-2 cursor-pointer group transition-opacity ${activeCategory && activeCategory !== cat.id ? 'opacity-50' : 'opacity-80 hover:opacity-100'}`}>
                            <div className={`w-16 h-16 rounded-full ${cat.color} flex items-center justify-center shadow-sm transition-transform ${activeCategory === cat.id ? 'ring-4 ring-offset-2 ring-blue-500 scale-110' : 'group-hover:scale-105'}`}>
                                {React.cloneElement(cat.icon as any, { size: 20 })}
                            </div>
                            <span className={`text-xs font-medium whitespace-nowrap ${activeCategory === cat.id ? 'text-blue-600 font-bold' : 'text-slate-600 dark:text-slate-300'}`}>{cat.label}</span>
                        </div>
                    ))}
                </div>

                {/* Brand Zones Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
                    {/* Apple Banner */}
                    <div 
                        onClick={() => setViewMode('iphone')}
                        className="col-span-1 md:col-span-2 relative h-[300px] rounded-[2.5rem] overflow-hidden bg-black text-white p-8 md:p-12 shadow-2xl group cursor-pointer"
                    >
                        <div className="absolute top-0 right-0 w-96 h-96 bg-gray-800/50 rounded-full blur-[100px] -mr-10 -mt-10 group-hover:scale-110 transition-transform duration-700"></div>
                        <div className="relative z-10 flex flex-col h-full justify-between">
                            <div>
                                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-sm font-bold mb-4 border border-white/20">
                                     Apple Zone
                                </div>
                                <h2 className="text-4xl md:text-5xl font-bold mb-2 tracking-tight">iPhone 15 Pro</h2>
                                <p className="text-gray-400 text-lg">Titanium. So strong. So light. So Pro.</p>
                            </div>
                            <button className="self-start px-8 py-3 bg-white text-black rounded-full font-bold shadow-lg hover:bg-gray-200 transition-all">
                                {t.appleStore.visit}
                            </button>
                        </div>
                    </div>

                    {/* Samsung Banner */}
                    <div 
                        onClick={() => setViewMode('samsung')}
                        className="relative h-64 rounded-[2.5rem] overflow-hidden bg-white border border-slate-200 text-black p-8 shadow-xl group cursor-pointer"
                    >
                        <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-white opacity-50"></div>
                        <div className="absolute top-[-50%] right-[-20%] w-64 h-64 bg-blue-500/10 rounded-full blur-3xl group-hover:scale-125 transition-transform duration-700"></div>
                        
                        <div className="relative z-10">
                            <h2 className="text-2xl font-bold text-blue-600 mb-2 tracking-widest">SAMSUNG</h2>
                            <h3 className="text-3xl md:text-4xl font-extrabold mb-4">Galaxy S24 Ultra</h3>
                            <p className="text-slate-500 mb-6 font-medium">Galaxy AI is here</p>
                            <button className="px-6 py-2 bg-black text-white rounded-full font-bold text-sm group-hover:bg-blue-600 transition-colors">
                                {t.samsungStore?.explore || 'Explore'}
                            </button>
                        </div>
                    </div>

                    {/* Asus ROG Banner */}
                    <div 
                        onClick={() => setViewMode('asus')}
                        className="relative h-64 rounded-[2.5rem] overflow-hidden bg-black text-white p-8 shadow-xl group cursor-pointer border border-white/10"
                    >
                        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20"></div>
                        <div className="absolute bottom-0 right-0 w-80 h-80 bg-red-600/20 rounded-full blur-[80px] group-hover:bg-red-600/30 transition-colors duration-500"></div>
                        
                        <div className="relative z-10">
                            <h2 className="text-2xl font-extrabold text-red-600 mb-2 italic tracking-widest font-mono">ROG</h2>
                            <h3 className="text-3xl md:text-4xl font-bold mb-4 font-mono">Republic of Gamers</h3>
                            <p className="text-gray-400 mb-6 font-mono text-sm">For Those Who Dare</p>
                            <button className="px-6 py-2 bg-transparent border-2 border-red-600 text-red-600 rounded-full font-bold text-sm group-hover:bg-red-600 group-hover:text-white transition-all">
                                {t.asusStore?.join || 'Join'}
                            </button>
                        </div>
                    </div>
                </div>

                {/* Magnum Banner */}
                <div 
                    onClick={() => setViewMode('magnum')}
                    className="mb-12 relative rounded-[2rem] overflow-hidden bg-gradient-to-r from-red-600 to-red-500 text-white p-8 md:p-12 shadow-xl shadow-red-500/20 group cursor-pointer"
                >
                    <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -mr-10 -mt-10 group-hover:scale-110 transition-transform duration-700"></div>
                    <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
                        <div>
                            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-sm font-bold mb-4">
                                <ShoppingBasket size={16} /> Grocery Delivery
                            </div>
                            <h2 className="text-4xl md:text-5xl font-extrabold mb-4 italic tracking-tight">Magnum GO</h2>
                            <p className="text-red-100 text-lg max-w-md">Fresh groceries delivered to your door in 30 minutes. 0 ₸ delivery fee for orders over 5000 ₸.</p>
                        </div>
                        <button className="px-8 py-4 bg-white text-red-600 rounded-full font-bold shadow-lg hover:scale-105 active:scale-95 transition-all">
                            Shop Groceries
                        </button>
                    </div>
                </div>

                {/* Standard Grid Logic */}
                {(!activeCategory && !activeStory) ? (
                    <div>
                        <h2 className="text-2xl font-bold dark:text-white mb-6">{t.popular}</h2>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            {filteredProducts.slice(0, 8).map(product => (
                                <ProductCard key={product.id} product={product} />
                            ))}
                        </div>
                    </div>
                ) : (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {filteredProducts.map(product => (
                            <ProductCard key={product.id} product={product} />
                        ))}
                    </div>
                )}
            </>
        ) : viewMode === 'samsung' ? (
            // SAMSUNG VIEW
            <div className="animate-in fade-in duration-700 font-sans">
                <div className="text-center py-20 bg-white border-b border-slate-100 mb-12">
                    <h2 className="text-blue-600 font-bold tracking-widest mb-4">GALAXY AI IS HERE</h2>
                    <h1 className="text-6xl font-black text-black mb-6">Galaxy S24 Ultra</h1>
                    <p className="text-xl text-slate-500 mb-8 max-w-2xl mx-auto">{t.samsungStore?.heroText || 'Epic productivity. Epic creativity. Epic play.'}</p>
                    <button className="px-10 py-4 bg-black text-white rounded-full font-bold hover:bg-blue-600 transition-colors">
                        {t.buy}
                    </button>
                </div>
                
                <h3 className="text-3xl font-bold text-black mb-8 px-8">Latest Galaxy Devices</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6 px-8 pb-12">
                    {filteredProducts.map(product => (
                        <ProductCard key={product.id} product={product} />
                    ))}
                </div>
            </div>
        ) : viewMode === 'asus' ? (
            // ASUS ROG VIEW
            <div className="animate-in fade-in duration-700 font-mono">
                <div className="relative h-[400px] rounded-3xl overflow-hidden mb-12 border border-red-900/50 shadow-[0_0_50px_rgba(220,38,38,0.2)]">
                    <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-30 z-0"></div>
                    <div className="absolute inset-0 bg-gradient-to-r from-black via-transparent to-black z-0"></div>
                    <div className="absolute inset-0 flex flex-col justify-center items-center z-10 text-center p-8">
                        <div className="w-24 h-24 mb-6">
                            <Gamepad2 size={80} className="text-red-600 mx-auto animate-pulse" />
                        </div>
                        <h1 className="text-5xl md:text-7xl font-black text-white italic tracking-tighter mb-4 drop-shadow-[0_0_10px_rgba(255,0,0,0.8)]">ROG PHONE 8</h1>
                        <p className="text-red-500 font-bold text-xl tracking-widest mb-8">BEYOND GAMING</p>
                        <button className="px-10 py-3 border-2 border-red-600 text-red-600 font-bold uppercase tracking-widest hover:bg-red-600 hover:text-white transition-all shadow-[0_0_20px_rgba(220,38,38,0.4)]">
                            {t.asusStore?.discover || 'Discover'}
                        </button>
                    </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {filteredProducts.map(product => (
                        <ProductCard key={product.id} product={product} />
                    ))}
                </div>
            </div>
        ) : viewMode === 'iphone' ? (
            // IPHONE VIEW (Existing logic)
            <div className="animate-in fade-in duration-700">
                <div className="text-center py-16 md:py-24 relative overflow-hidden rounded-[3rem] bg-[#111] mb-12">
                    <div className="relative z-10">
                        <h2 className="text-5xl md:text-7xl font-bold tracking-tighter mb-4 bg-clip-text text-transparent bg-gradient-to-b from-white to-gray-500">iPhone 15 Pro</h2>
                        <p className="text-xl md:text-2xl text-gray-400 font-light mb-8">{t.appleStore.heroTitle}</p>
                        <div className="flex gap-4 justify-center">
                            <button className="px-8 py-3 bg-blue-600 text-white rounded-full font-medium hover:bg-blue-700 transition-colors">
                                {t.buy}
                            </button>
                        </div>
                    </div>
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-900/20 rounded-full blur-[120px]"></div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {filteredProducts.map(product => (
                        <ProductCard key={product.id} product={product} />
                    ))}
                </div>
            </div>
        ) : (
            // MAGNUM VIEW (Existing)
            <div className="animate-in slide-in-from-right fade-in duration-500">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
                     <div onClick={() => setMagnumFilter('deals')} className="md:col-span-2 relative h-48 rounded-3xl bg-red-600 overflow-hidden flex items-center p-8 shadow-lg shadow-red-500/20 cursor-pointer hover:opacity-90 transition-opacity">
                          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -mr-10 -mt-10"></div>
                          <div className="relative z-10 text-white">
                              <h2 className="text-3xl font-extrabold italic mb-2">Fresh Morning!</h2>
                              <p className="text-red-100 mb-4">Get 20% off on all bakery and dairy products before 10 AM.</p>
                              <button className="px-6 py-2 bg-white text-red-600 font-bold rounded-full text-sm hover:scale-105 transition-transform">See Offers</button>
                          </div>
                     </div>
                     <div onClick={() => alert("You have 450 Bonus Points available for redemption in Magnum!")} className="h-48 rounded-3xl bg-slate-900 text-white p-6 flex flex-col justify-between shadow-xl relative overflow-hidden cursor-pointer hover:-translate-y-1 transition-transform">
                          <div className="absolute top-0 right-0 w-32 h-32 bg-red-600 rounded-full blur-2xl -mr-6 -mt-6 opacity-50"></div>
                          <div className="flex justify-between items-start">
                              <span className="font-bold italic text-lg">Magnum Club</span>
                              <div className="p-2 bg-white/10 rounded-lg"><Zap size={20} /></div>
                          </div>
                          <div>
                              <div className="text-xs text-slate-400 mb-1">Your Bonuses</div>
                              <div className="text-2xl font-bold">450 B</div>
                          </div>
                     </div>
                </div>
                <div className="flex gap-4 overflow-x-auto no-scrollbar mb-10 p-2">
                     {magnumCategories.map(cat => (
                         <div key={cat.id} onClick={() => setMagnumFilter(cat.id === magnumFilter ? null : cat.id)} className="flex flex-col items-center gap-2 min-w-[80px] cursor-pointer group">
                             <div className={`w-20 h-20 rounded-full ${cat.color} flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform border-4 ${magnumFilter === cat.id ? 'border-red-600' : 'border-white'}`}>
                                 {cat.icon}
                             </div>
                             <span className={`text-sm font-medium ${magnumFilter === cat.id ? 'text-red-600 font-bold' : 'text-slate-700 dark:text-slate-300'}`}>{cat.label}</span>
                         </div>
                     ))}
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                     {filteredProducts.length > 0 ? (
                         filteredProducts.map(product => <ProductCard key={product.id} product={product} />)
                     ) : (
                         <div className="col-span-full py-12 text-center text-slate-400">
                             <ShoppingBasket size={48} className="mx-auto mb-4 opacity-20" />
                             <p>No products found in this category</p>
                             <button onClick={() => setMagnumFilter(null)} className="mt-4 text-red-600 font-bold hover:underline">Clear Filter</button>
                         </div>
                     )}
                </div>
            </div>
        )}

        {/* Product Detail Modal */}
        {selectedProduct && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md p-4 animate-in fade-in">
                <div className={`bg-white dark:bg-slate-900 w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-[2rem] shadow-2xl animate-in zoom-in-95 relative flex flex-col md:flex-row overflow-hidden ${viewMode === 'iphone' ? 'bg-[#111] text-white border border-white/10' : viewMode === 'asus' ? 'bg-[#0a0a0a] text-white border border-red-900/30 font-mono' : ''}`}>
                    <button 
                        onClick={() => setSelectedProduct(null)}
                        className={`absolute top-4 right-4 p-2 rounded-full z-10 ${viewMode === 'iphone' || viewMode === 'asus' ? 'bg-white/10 hover:bg-white/20' : 'bg-slate-100 dark:bg-slate-800'}`}
                    >
                        <X size={24} />
                    </button>

                    {/* Image Section */}
                    <div className={`w-full md:w-1/2 flex items-center justify-center p-8 relative ${viewMode === 'iphone' || viewMode === 'asus' ? 'bg-black' : 'bg-slate-50 dark:bg-slate-800'}`}>
                        {selectedProduct.originalPrice && (
                            <span className="absolute top-6 left-6 px-3 py-1.5 bg-red-500 text-white font-bold rounded-xl text-lg shadow-lg">
                                -{calculateDiscount(selectedProduct.price, selectedProduct.originalPrice)}%
                            </span>
                        )}
                        <img src={selectedProduct.image} alt={selectedProduct.title} className="max-w-full max-h-[400px] object-contain drop-shadow-2xl" />
                    </div>

                    {/* Info Section */}
                    <div className="w-full md:w-1/2 p-8 md:p-12 flex flex-col">
                        <h2 className={`text-3xl font-bold mb-2 ${viewMode === 'iphone' || viewMode === 'asus' ? 'text-white' : 'text-slate-900 dark:text-white'}`}>{selectedProduct.title}</h2>
                        
                        {/* Tags */}
                        <div className="flex flex-wrap gap-2 mb-6">
                            <div className={`px-3 py-1 rounded-lg text-sm font-bold ${viewMode === 'iphone' ? 'bg-green-500/20 text-green-400' : 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400'}`}>
                                In Stock
                            </div>
                            {selectedProduct.bonusPercent > 0 && (
                                    <div className={`px-3 py-1 rounded-lg text-sm font-bold ${viewMode === 'iphone' ? 'bg-purple-500/20 text-purple-400' : 'bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-400'}`}>
                                    +{selectedProduct.bonusPercent}% Bonus
                                </div>
                            )}
                        </div>
                        
                        {/* iPhone Colors Selection in Modal */}
                        {(viewMode === 'iphone' || viewMode === 'samsung') && selectedProduct.colors && (
                            <div className="mb-6">
                                <label className="text-sm font-bold text-gray-400 mb-2 block">Color</label>
                                <div className="flex gap-3">
                                    {selectedProduct.colors.map(c => (
                                        <button 
                                            key={c} 
                                            className="w-8 h-8 rounded-full border border-white/20 hover:scale-110 transition-transform focus:ring-2 focus:ring-white" 
                                            style={{ backgroundColor: c }}
                                        />
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* Delivery Info */}
                        <div className={`mb-6 p-4 rounded-xl flex flex-col gap-2 ${viewMode === 'iphone' ? 'bg-white/5' : 'bg-slate-50 dark:bg-slate-800'}`}>
                             <div className={`flex items-center gap-2 text-sm ${viewMode === 'iphone' ? 'text-gray-300' : 'text-slate-600 dark:text-slate-300'}`}>
                                 <Truck size={16} className="text-blue-500" />
                                 <span>{t.shippingDate} <span className="font-bold">{dates.ship}</span></span>
                             </div>
                             <div className={`flex items-center gap-2 text-sm ${viewMode === 'iphone' ? 'text-gray-300' : 'text-slate-600 dark:text-slate-300'}`}>
                                 <Package size={16} className="text-green-500" />
                                 <span>{t.deliveryDate} <span className="font-bold">{dates.deliver}</span></span>
                             </div>
                        </div>

                        {!selectedProduct.isMagnum && (
                            <div className={`mb-8 p-4 rounded-2xl border ${viewMode === 'iphone' ? 'bg-white/5 border-white/10' : 'bg-slate-50 dark:bg-slate-800/50 border-slate-100 dark:border-slate-800'}`}>
                                <div className="text-sm text-slate-500 mb-1">{t.installment}</div>
                                <div className={`text-2xl font-bold flex items-baseline gap-1 ${viewMode === 'iphone' ? 'text-white' : 'text-slate-900 dark:text-white'}`}>
                                    {getMonthlyPrice(selectedProduct.price)} ₸ 
                                    <span className="text-sm font-normal text-slate-400">x {viewMode === 'iphone' ? '24' : '12'} {t.months}</span>
                                </div>
                            </div>
                        )}

                        <div className="mb-8">
                            {selectedProduct.originalPrice && (
                                <div className="text-lg text-slate-400 line-through mb-1">
                                    {selectedProduct.originalPrice.toLocaleString()} ₸
                                </div>
                            )}
                            <div className={`text-4xl font-extrabold ${viewMode === 'iphone' ? 'text-white' : 'text-slate-900 dark:text-white'}`}>
                                {selectedProduct.price.toLocaleString()} ₸
                            </div>
                        </div>

                        <div className="mt-auto space-y-3">
                            <button 
                                    onClick={handleBuyNow}
                                    className={`w-full py-4 text-white rounded-xl font-bold text-lg transition-colors shadow-lg ${viewMode === 'magnum' ? 'bg-red-600 hover:bg-red-700 shadow-red-500/30' : viewMode === 'iphone' ? 'bg-blue-600 hover:bg-blue-700' : viewMode === 'asus' ? 'bg-red-600 hover:bg-red-700 font-mono tracking-widest' : 'bg-accent-600 hover:bg-accent-700 shadow-accent-500/30'}`}
                            >
                                {t.buy}
                            </button>
                            <button 
                                onClick={() => { addToCart(selectedProduct); setSelectedProduct(null); setIsCartOpen(true); }}
                                className={`w-full py-4 rounded-xl font-bold text-lg transition-colors ${viewMode === 'iphone' ? 'bg-white/10 text-white hover:bg-white/20' : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-white hover:bg-slate-200 dark:hover:bg-slate-700'}`}
                            >
                                {t.addToCart}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        )}

        {/* Cart Drawer */}
        <div className={`fixed inset-y-0 right-0 w-full md:w-[450px] bg-white dark:bg-slate-900 shadow-2xl transform transition-transform duration-300 z-50 flex flex-col ${isCartOpen ? 'translate-x-0' : 'translate-x-full'}`}>
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                 <h2 className="text-2xl font-bold dark:text-white">{t.cart.title}</h2>
                 <button onClick={() => setIsCartOpen(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full dark:text-white">
                     <X size={24} />
                 </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {cartItems.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-slate-400">
                        <ShoppingBasket size={64} className="mb-4 opacity-20" />
                        <p>{t.cart.empty}</p>
                    </div>
                ) : (
                    cartItems.map(item => (
                        <div key={item.product.id} className="flex gap-4">
                            <div className="w-20 h-20 rounded-xl bg-slate-50 dark:bg-slate-800 shrink-0 overflow-hidden">
                                <img src={item.product.image} alt="" className="w-full h-full object-cover" />
                            </div>
                            <div className="flex-1">
                                <h4 className="font-bold text-slate-800 dark:text-white line-clamp-1">{item.product.title}</h4>
                                <div className="text-sm text-slate-500 mb-2">{item.product.price.toLocaleString()} ₸</div>
                                <div className="flex items-center gap-3">
                                    <button onClick={() => updateQuantity(item.product.id, -1)} className="p-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:text-white"><Minus size={16} /></button>
                                    <span className="font-bold w-6 text-center dark:text-white">{item.quantity}</span>
                                    <button onClick={() => updateQuantity(item.product.id, 1)} className="p-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:text-white"><Plus size={16} /></button>
                                    <button onClick={() => removeFromCart(item.product.id)} className="ml-auto text-red-500 p-2 hover:bg-red-50 rounded-lg"><Trash2 size={18} /></button>
                                </div>
                            </div>
                        </div>
                    ))
                )}
            </div>

            {cartItems.length > 0 && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-black/20">
                    <div className="flex justify-between items-center mb-6">
                        <span className="text-slate-500 font-medium">{t.cart.total}</span>
                        <span className="text-3xl font-extrabold text-slate-900 dark:text-white">{cartTotal.toLocaleString()} ₸</span>
                    </div>
                    <button onClick={openCheckout} className="w-full py-4 bg-accent-600 text-white rounded-xl font-bold shadow-lg shadow-accent-500/30 hover:bg-accent-700 transition-colors">
                        {t.cart.checkout}
                    </button>
                </div>
            )}
        </div>

        {/* Payment Modal */}
        {isPaymentOpen && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 backdrop-blur-md p-4 animate-in fade-in">
                <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-3xl p-8 relative shadow-2xl animate-in zoom-in-95 border border-white/10">
                    <button onClick={() => setIsPaymentOpen(false)} className="absolute top-6 right-6 p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 transition-colors"><X size={20} /></button>
                    {paymentStep === 'method' && (
                        <>
                            <h3 className="text-2xl font-bold mb-6 dark:text-white">{t.payment.title}</h3>
                            <div className="space-y-4 mb-8">
                                <label className="text-sm font-bold text-slate-500 uppercase">{t.payment.totalPay}</label>
                                <div className="text-4xl font-black text-slate-900 dark:text-white">{(cartTotal || selectedProduct?.price || 0).toLocaleString()} ₸</div>
                            </div>
                            <button onClick={processPayment} className="w-full py-4 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-colors shadow-lg shadow-green-500/30">{t.payment.pay}</button>
                        </>
                    )}
                    {paymentStep === 'processing' && <div className="py-12 flex flex-col items-center justify-center text-center"><Loader2 size={48} className="text-accent-600 animate-spin mb-6" /><h3 className="text-xl font-bold dark:text-white animate-pulse">{t.payment.processing}</h3></div>}
                    {paymentStep === 'success' && (
                        <div className="py-8 flex flex-col items-center text-center animate-in zoom-in">
                            <div className="w-24 h-24 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center text-green-600 dark:text-green-400 mb-6"><Check size={48} /></div>
                            <h3 className="text-2xl font-bold mb-2 dark:text-white">{t.payment.success}</h3>
                            <button onClick={() => setIsPaymentOpen(false)} className="mt-8 px-8 py-3 bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white font-bold rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700">Close</button>
                        </div>
                    )}
                </div>
            </div>
        )}

        </div>
    </div>
  );
};

export default ShopView;
