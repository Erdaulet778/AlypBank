
import React from 'react';
import { 
  Home, 
  ShoppingBag, 
  Wallet, 
  CreditCard, 
  ArrowRightLeft, 
  Settings, 
  LogOut, 
  ChevronLeft, 
  ChevronRight,
  Search,
  LogIn,
  MessageSquare,
  User,
  LayoutGrid
} from 'lucide-react';
import { ViewState, Language } from '../types';
import { translations } from '../utils/translations';

interface SidebarProps {
  collapsed: boolean;
  setCollapsed: (v: boolean) => void;
  mobileOpen: boolean;
  setMobileOpen: (v: boolean) => void;
  currentView: ViewState;
  onNavigate: (view: ViewState) => void;
  isLoggedIn: boolean;
  onLogout: () => void;
  lang: Language;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  collapsed, 
  setCollapsed, 
  mobileOpen, 
  setMobileOpen,
  currentView,
  onNavigate,
  isLoggedIn,
  onLogout,
  lang
}) => {
  const t = translations[lang].sidebar;

  // Base menu items
  let menuItems = [
    { id: 'home', label: t.home, icon: <Home size={22} /> },
    { id: 'magazin', label: t.magazin, icon: <ShoppingBag size={22} /> },
    { id: 'bank', label: t.bank, icon: <Wallet size={22} /> },
    { id: 'tolemder', label: t.tolemder, icon: <CreditCard size={22} /> },
    { id: 'audarimdar', label: t.audarimdar, icon: <ArrowRightLeft size={22} /> },
    { id: 'messages', label: t.messages, icon: <MessageSquare size={22} /> },
  ];

  // If logged in, add Dashboard at the top and Profile at the bottom of main list
  if (isLoggedIn) {
      menuItems = [
          { id: 'dashboard', label: t.dashboard, icon: <LayoutGrid size={22} /> },
          ...menuItems,
          { id: 'profile', label: t.profile, icon: <User size={22} /> }
      ];
  }

  const secondaryItems = [
    { id: 'settings', label: t.settings, icon: <Settings size={22} /> },
  ];

  const handleLogoClick = () => {
      if (isLoggedIn) {
          onNavigate('dashboard');
      } else {
          onNavigate('home');
      }
  };

  return (
    <>
      {/* Mobile Overlay */}
      {mobileOpen && (
        <div 
          className="fixed inset-0 bg-black/60 z-40 md:hidden backdrop-blur-sm transition-opacity"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar Container */}
      <aside 
        className={`fixed top-0 left-0 h-full z-50 transition-all duration-500 ease-[cubic-bezier(0.25,0.8,0.25,1)]
          ${mobileOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
          ${collapsed ? 'md:w-[88px]' : 'md:w-80'}
          w-72
          glass border-r border-white/20 dark:border-white/5 shadow-2xl
        `}
      >
        <div className="flex flex-col h-full p-6">
          
          {/* Header */}
          <div className="flex items-center justify-between mb-10 relative">
            <div 
              className="flex items-center gap-3 cursor-pointer overflow-hidden group"
              onClick={handleLogoClick}
              title={isLoggedIn ? t.dashboard : t.home}
            >
              <img 
                  src="https://i.ibb.co.com/vCN59q6B/95e7c81d-66e6-42d4-bb3e-46875952e46e.jpg" 
                  alt="Alyp Bank" 
                  className="w-12 h-12 rounded-xl object-cover shadow-lg shadow-accent-500/30 group-hover:scale-105 transition-transform duration-500" 
              />
              <span className={`font-bold text-2xl text-slate-800 dark:text-white whitespace-nowrap transition-all duration-500 ${collapsed ? 'md:opacity-0 md:w-0' : 'opacity-100'}`}>
                Alyp Bank
              </span>
            </div>
            
            <button 
              onClick={() => setCollapsed(!collapsed)}
              className="absolute -right-10 top-3 w-8 h-8 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-full items-center justify-center hidden md:flex hover:bg-accent-50 dark:hover:bg-slate-700 hover:text-accent-600 transition-all shadow-md text-slate-500 dark:text-slate-400 z-50"
            >
              {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
            </button>
          </div>

          {/* Search */}
          <div className="mb-8 group">
            <div className={`flex items-center gap-3 px-4 py-3.5 bg-slate-100/50 dark:bg-black/20 rounded-2xl border border-transparent group-focus-within:border-accent-500 group-focus-within:bg-white dark:group-focus-within:bg-black/40 group-focus-within:shadow-lg transition-all ${collapsed ? 'justify-center cursor-pointer px-0 w-12 h-12 mx-auto' : ''}`}>
              <Search size={22} className={`text-slate-400 group-focus-within:text-accent-500 transition-colors ${collapsed ? 'mx-auto' : ''}`} />
              <input 
                type="text" 
                placeholder={t.search} 
                className={`bg-transparent outline-none w-full text-sm font-medium text-slate-700 dark:text-slate-200 placeholder:text-slate-400 ${collapsed ? 'hidden' : 'block'}`}
              />
            </div>
          </div>

          {/* Navigation */}
          <div className="flex-1 overflow-y-auto no-scrollbar space-y-2">
            <nav className="space-y-2">
              {menuItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id as ViewState)}
                  className={`w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl transition-all duration-300 group relative overflow-hidden
                    ${currentView === item.id 
                      ? 'bg-accent-600 text-white shadow-lg shadow-accent-500/40' 
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/10 hover:text-slate-900 dark:hover:text-white'}
                    ${collapsed ? 'justify-center px-0 w-12 h-12 mx-auto' : ''}
                  `}
                >
                  <div className={`relative z-10 ${currentView === item.id ? 'scale-110' : 'group-hover:scale-110'} transition-transform duration-300`}>
                    {item.icon}
                  </div>
                  <span className={`whitespace-nowrap font-semibold tracking-wide relative z-10 ${collapsed ? 'hidden' : 'block'}`}>
                    {item.label}
                  </span>
                  
                  {/* Tooltip for collapsed state */}
                  {collapsed && (
                    <div className="absolute left-14 ml-4 px-3 py-1.5 bg-slate-900 text-white text-sm font-medium rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none transition-all z-50 whitespace-nowrap shadow-xl translate-x-[-10px] group-hover:translate-x-0">
                      {item.label}
                    </div>
                  )}
                </button>
              ))}
            </nav>

            <div className="h-px bg-gradient-to-r from-transparent via-slate-200 dark:via-slate-700 to-transparent my-6" />

            <nav className="space-y-2">
              {secondaryItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id as ViewState)}
                  className={`w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl transition-all duration-300 group relative
                    ${currentView === item.id 
                      ? 'bg-accent-600 text-white shadow-lg' 
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/10'}
                    ${collapsed ? 'justify-center px-0 w-12 h-12 mx-auto' : ''}
                  `}
                >
                  <div className={`relative z-10 transition-transform duration-300 group-hover:rotate-45`}>
                    {item.icon}
                  </div>
                  <span className={`whitespace-nowrap font-medium relative z-10 ${collapsed ? 'hidden' : 'block'}`}>
                    {item.label}
                  </span>
                  {collapsed && (
                    <div className="absolute left-14 ml-4 px-3 py-1.5 bg-slate-900 text-white text-sm font-medium rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none transition-all z-50 whitespace-nowrap shadow-xl translate-x-[-10px] group-hover:translate-x-0">
                      {item.label}
                    </div>
                  )}
                </button>
              ))}
            </nav>
          </div>

          {/* Footer / Login */}
          <div className="mt-auto pt-6">
            {isLoggedIn ? (
              <button 
                onClick={onLogout}
                className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all group ${collapsed ? 'justify-center px-0 w-12 mx-auto' : ''}`}
              >
                <LogOut size={22} className="group-hover:-translate-x-1 transition-transform" />
                <span className={`font-bold ${collapsed ? 'hidden' : 'block'}`}>{t.logout}</span>
              </button>
            ) : (
              <button 
                onClick={() => onNavigate('login')}
                className={`w-full flex items-center gap-3 px-4 py-4 rounded-2xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:shadow-lg hover:shadow-slate-500/30 hover:-translate-y-1 transition-all active:scale-95 ${collapsed ? 'justify-center px-0 w-12 mx-auto' : ''}`}
              >
                {collapsed ? <LogIn size={22} /> : (
                  <>
                    <LogIn size={22} />
                    <span className="font-bold">{t.login}</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
