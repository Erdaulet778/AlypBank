
import React, { useState } from 'react';
import { Smartphone, Zap, Wifi, GraduationCap, Bus, ShieldAlert, Gamepad2, MoreHorizontal, Search, Clock, ChevronRight } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../utils/translations';

interface PaymentsViewProps {
  lang: Language;
}

const PaymentsView: React.FC<PaymentsViewProps> = ({ lang }) => {
  const t = translations[lang].payments;
  
  const categories = [
    { id: 'mobile', label: t.catalog.mobile, icon: <Smartphone size={24} />, color: "text-blue-500", bg: "bg-blue-50 dark:bg-blue-900/20" },
    { id: 'utilities', label: t.catalog.utilities, icon: <Zap size={24} />, color: "text-amber-500", bg: "bg-amber-50 dark:bg-amber-900/20" },
    { id: 'internet', label: t.catalog.internet, icon: <Wifi size={24} />, color: "text-emerald-500", bg: "bg-emerald-50 dark:bg-emerald-900/20" },
    { id: 'education', label: t.catalog.education, icon: <GraduationCap size={24} />, color: "text-indigo-500", bg: "bg-indigo-50 dark:bg-indigo-900/20" },
    { id: 'transport', label: t.catalog.transport, icon: <Bus size={24} />, color: "text-pink-500", bg: "bg-pink-50 dark:bg-pink-900/20" },
    { id: 'fines', label: t.catalog.fines, icon: <ShieldAlert size={24} />, color: "text-red-500", bg: "bg-red-50 dark:bg-red-900/20" },
    { id: 'games', label: t.catalog.games, icon: <Gamepad2 size={24} />, color: "text-purple-500", bg: "bg-purple-50 dark:bg-purple-900/20" },
    { id: 'other', label: t.catalog.other, icon: <MoreHorizontal size={24} />, color: "text-slate-500", bg: "bg-slate-50 dark:bg-slate-800" },
  ];

  return (
    <div className="p-4 md:p-8 animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-5xl mx-auto">
       <h1 className="text-3xl font-bold mb-8 dark:text-white">{t.title}</h1>

       {/* Search */}
       <div className="relative mb-8">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
                type="text" 
                placeholder={t.search}
                className="w-full pl-12 pr-4 py-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 shadow-sm focus:ring-2 focus:ring-blue-500 outline-none text-lg dark:text-white"
            />
       </div>

       {/* Catalog Grid */}
       <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
            {categories.map((cat) => (
                <button 
                    key={cat.id}
                    className="flex flex-col items-center justify-center p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-md hover:-translate-y-1 transition-all group"
                >
                    <div className={`w-14 h-14 rounded-2xl ${cat.bg} ${cat.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                        {cat.icon}
                    </div>
                    <span className="font-semibold text-slate-700 dark:text-slate-200 text-center text-sm">{cat.label}</span>
                </button>
            ))}
       </div>

       {/* History Section */}
       <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 shadow-sm border border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between mb-6">
                 <h2 className="text-xl font-bold dark:text-white flex items-center gap-2">
                    <Clock className="text-slate-400" />
                    {t.history}
                 </h2>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800">
                 {[
                    { title: "Beeline", desc: "+7 (777) 123 45 67", amount: "2 590 ₸", icon: <Smartphone size={18} />, color: "bg-yellow-100 text-yellow-600" },
                    { title: "Kazakhtelecom", desc: "ID: 100200300", amount: "5 400 ₸", icon: <Wifi size={18} />, color: "bg-blue-100 text-blue-600" },
                    { title: "Onay!", desc: "Card: 99001122", amount: "1 000 ₸", icon: <Bus size={18} />, color: "bg-red-100 text-red-600" },
                 ].map((item, idx) => (
                     <div key={idx} className="flex items-center justify-between py-4 group cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50 rounded-xl px-2 transition-colors">
                         <div className="flex items-center gap-4">
                             <div className={`w-10 h-10 rounded-full ${item.color} flex items-center justify-center`}>
                                 {item.icon}
                             </div>
                             <div>
                                 <div className="font-bold text-slate-800 dark:text-white">{item.title}</div>
                                 <div className="text-xs text-slate-500">{item.desc}</div>
                             </div>
                         </div>
                         <div className="flex items-center gap-4">
                             <div className="font-bold text-slate-800 dark:text-white">{item.amount}</div>
                             <ChevronRight size={16} className="text-slate-300 group-hover:text-blue-500" />
                         </div>
                     </div>
                 ))}
            </div>
       </div>
    </div>
  );
};

export default PaymentsView;
