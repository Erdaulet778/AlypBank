import React, { useState, useEffect, useMemo } from 'react';
import { Plus, CreditCard, PiggyBank, Sparkles, Check, X, Shield, History, ArrowUpCircle } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../utils/translations';

interface BankViewProps {
    lang: Language;
    userName: string;
}

interface Card {
    id: number;
    number: string;
    balance: number;
    type: 'Standard' | 'Gold' | 'VIP';
    color: string;
    holder: string;
    expiry: string;
}

interface Deposit {
    id: number;
    name: string;
    balance: number;
    rate: string;
}

const BankView: React.FC<BankViewProps> = ({ lang, userName }) => {
    const t = translations[lang].bank;
    const tGlobal = translations[lang];
    
    // State
    const [successMsg, setSuccessMsg] = useState<string | null>(null);
    const [showCardModal, setShowCardModal] = useState(false);
    const [showTopUpModal, setShowTopUpModal] = useState(false);
    const [selectedTier, setSelectedTier] = useState<'Standard' | 'Gold' | 'VIP' | null>(null);
    const [selectedItemForTopUp, setSelectedItemForTopUp] = useState<{type: 'card'|'deposit', id: number} | null>(null);
    const [topUpAmount, setTopUpAmount] = useState('');

    const [cards, setCards] = useState<Card[]>([
        { id: 1, number: "**** **** **** 4589", balance: 1250000, type: "Gold", color: "from-amber-400 to-orange-500", holder: userName.toUpperCase(), expiry: "12/28" }
    ]);

    const [deposits, setDeposits] = useState<Deposit[]>([
        { id: 1, name: "Alyp Deposit", balance: 500000, rate: "14.5%" }
    ]);

    // Handlers
    const handleSuccess = (msg: string) => {
        setSuccessMsg(msg);
        setTimeout(() => setSuccessMsg(null), 3000);
    };

    const handleOpenCardStart = () => {
        setSelectedTier(null);
        setShowCardModal(true);
    };

    const confirmCardCreation = (cardData: Partial<Card>) => {
        const newCard: Card = {
            id: Date.now(),
            number: cardData.number || `**** **** **** ${Math.floor(1000 + Math.random() * 9000)}`,
            balance: 0,
            type: selectedTier || 'Standard',
            color: selectedTier === 'Gold' ? "from-amber-400 to-orange-500" 
                  : selectedTier === 'VIP' ? "from-slate-900 via-slate-800 to-black" 
                  : "from-blue-600 to-indigo-600",
            holder: cardData.holder || userName.toUpperCase(),
            expiry: cardData.expiry || "12/28"
        };
        setCards([...cards, newCard]);
        setShowCardModal(false);
        handleSuccess(t.successCard);
    };

    const handleOpenDeposit = () => {
        const newDeposit: Deposit = {
            id: Date.now(),
            name: `${t.depositType} ${new Date().getFullYear()}`,
            balance: 0,
            rate: "13.2%"
        };
        setDeposits([...deposits, newDeposit]);
        handleSuccess(t.successDeposit);
    };

    const openTopUp = (type: 'card'|'deposit', id: number) => {
        setSelectedItemForTopUp({ type, id });
        setTopUpAmount('');
        setShowTopUpModal(true);
    };

    const handleTopUpSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const amount = parseFloat(topUpAmount);
        if (!amount || amount <= 0) return;

        if (selectedItemForTopUp?.type === 'card') {
            setCards(cards.map(c => c.id === selectedItemForTopUp.id ? { ...c, balance: c.balance + amount } : c));
        } else if (selectedItemForTopUp?.type === 'deposit') {
            setDeposits(deposits.map(d => d.id === selectedItemForTopUp.id ? { ...d, balance: d.balance + amount } : d));
        }

        setShowTopUpModal(false);
        handleSuccess(t.successTopUp);
    };

    return (
        <div className="p-4 md:p-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Header */}
            <h1 className="text-3xl font-bold mb-8 dark:text-white">{t.title}</h1>

            {/* Success Toast */}
            {successMsg && (
                <div className="fixed top-24 right-6 bg-green-500 text-white px-6 py-3 rounded-xl shadow-xl flex items-center gap-3 animate-in slide-in-from-right fade-in z-50">
                    <div className="bg-white/20 p-1 rounded-full"><Check size={16} /></div>
                    {successMsg}
                </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left Column - Actions & Bonus */}
                <div className="space-y-6">
                    {/* Bonus Card */}
                    <div className="bg-gradient-to-br from-indigo-500 to-purple-600 p-6 rounded-3xl text-white shadow-lg shadow-purple-500/20 relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-32 h-32 bg-white/20 rounded-full blur-2xl -mr-10 -mt-10"></div>
                        <div className="relative z-10">
                            <div className="flex items-center gap-2 mb-2 opacity-90">
                                <Sparkles size={20} />
                                <span className="font-medium text-sm uppercase tracking-wider">{t.bonusTitle}</span>
                            </div>
                            <div className="text-4xl font-bold mb-1">12,450 {t.currency}</div>
                            <div className="text-sm opacity-80">Cashback +1.5%</div>
                        </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="grid grid-cols-2 gap-4">
                        <button 
                            onClick={handleOpenCardStart}
                            className="p-5 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-sm hover:shadow-md hover:border-blue-500 dark:hover:border-blue-500 transition-all group text-left"
                        >
                            <div className="w-10 h-10 bg-blue-50 dark:bg-blue-900/30 rounded-full flex items-center justify-center text-blue-600 dark:text-blue-400 mb-3 group-hover:scale-110 transition-transform">
                                <Plus size={20} />
                            </div>
                            <div className="font-bold text-slate-800 dark:text-white leading-tight">{t.openCard}</div>
                        </button>
                        
                        <button 
                            onClick={handleOpenDeposit}
                            className="p-5 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-sm hover:shadow-md hover:border-emerald-500 dark:hover:border-emerald-500 transition-all group text-left"
                        >
                            <div className="w-10 h-10 bg-emerald-50 dark:bg-emerald-900/30 rounded-full flex items-center justify-center text-emerald-600 dark:text-emerald-400 mb-3 group-hover:scale-110 transition-transform">
                                <PiggyBank size={20} />
                            </div>
                            <div className="font-bold text-slate-800 dark:text-white leading-tight">{t.openDeposit}</div>
                        </button>
                    </div>
                </div>

                {/* Right Column - Cards & Deposits List */}
                <div className="lg:col-span-2 space-y-10">
                    
                    {/* My Cards */}
                    <div>
                        <div className="flex items-center justify-between mb-6">
                            <h2 className="text-xl font-bold flex items-center gap-2 dark:text-white">
                                <CreditCard className="text-blue-600" size={24} /> 
                                {t.myCards}
                            </h2>
                        </div>
                        
                        <div className="flex gap-6 overflow-x-auto pb-8 no-scrollbar snap-x">
                            {cards.length === 0 ? (
                                <div className="w-full h-48 rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center text-slate-400">
                                    <CreditCard size={32} className="mb-2 opacity-50" />
                                    <p>{t.noCards}</p>
                                </div>
                            ) : (
                                cards.map(card => (
                                    <div key={card.id} className="snap-center shrink-0 w-[340px] group">
                                        {/* Visual Card */}
                                        <div className={`h-52 rounded-2xl bg-gradient-to-br ${card.color} text-white p-6 relative overflow-hidden shadow-xl transition-all hover:shadow-2xl hover:-translate-y-2`}>
                                            <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full blur-2xl -mr-10 -mt-10"></div>
                                            <div className="absolute bottom-0 left-0 w-32 h-32 bg-black/10 rounded-full blur-2xl -ml-10 -mb-10"></div>
                                            
                                            <div className="flex justify-between items-start mb-10 relative z-10">
                                                <span className="font-bold opacity-90 tracking-widest">{card.type.toUpperCase()}</span>
                                                <div className="flex gap-1">
                                                    <div className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-md"></div>
                                                    <div className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-md -ml-4 mix-blend-overlay"></div>
                                                </div>
                                            </div>
                                            
                                            <div className="text-2xl font-mono tracking-widest mb-6 drop-shadow-md relative z-10">{card.number}</div>
                                            
                                            <div className="flex justify-between items-end relative z-10">
                                                <div>
                                                    <div className="text-[10px] opacity-70 uppercase mb-0.5">{t.cardForm.cardHolder}</div>
                                                    <div className="font-medium uppercase text-sm tracking-wide text-shadow">{card.holder}</div>
                                                </div>
                                                <div className="text-xl font-bold">{card.balance.toLocaleString()} {t.currency}</div>
                                            </div>
                                        </div>

                                        {/* Quick Actions */}
                                        <div className="flex justify-between mt-4 px-2">
                                            <button onClick={() => openTopUp('card', card.id)} className="flex flex-col items-center gap-1 text-slate-600 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                                                <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center"><ArrowUpCircle size={20} /></div>
                                                <span className="text-xs font-medium">{t.actions.topUp}</span>
                                            </button>
                                            <button className="flex flex-col items-center gap-1 text-slate-600 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                                                <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center"><History size={20} /></div>
                                                <span className="text-xs font-medium">{t.actions.history}</span>
                                            </button>
                                            <button className="flex flex-col items-center gap-1 text-slate-600 dark:text-slate-400 hover:text-red-500 transition-colors">
                                                <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center"><Shield size={20} /></div>
                                                <span className="text-xs font-medium">{t.actions.block}</span>
                                            </button>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>

                    {/* My Deposits */}
                    <div>
                        <h2 className="text-xl font-bold flex items-center gap-2 mb-6 dark:text-white">
                            <PiggyBank className="text-emerald-600" size={24} /> 
                            {t.myDeposits}
                        </h2>
                        <div className="space-y-4">
                            {deposits.map(dep => (
                                <div key={dep.id} className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 flex items-center justify-between hover:shadow-md transition-shadow">
                                    <div className="flex items-center gap-4">
                                        <div className="w-14 h-14 bg-emerald-100 dark:bg-emerald-900/30 rounded-2xl flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                                            <PiggyBank size={28} />
                                        </div>
                                        <div>
                                            <h4 className="font-bold text-lg text-slate-800 dark:text-white">{dep.name}</h4>
                                            <p className="text-sm text-slate-500">{t.rate}: <span className="text-emerald-600 font-bold">{dep.rate}</span></p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-6">
                                        <div className="text-right hidden sm:block">
                                            <div className="text-xs text-slate-400 mb-0.5">{tGlobal.dashboard.title}</div>
                                            <div className="font-bold text-xl text-slate-800 dark:text-white">{dep.balance.toLocaleString()} {t.currency}</div>
                                        </div>
                                        <button 
                                            onClick={() => openTopUp('deposit', dep.id)}
                                            className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center hover:bg-blue-700 transition-colors shadow-lg shadow-blue-500/30"
                                        >
                                            <Plus size={20} />
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            {/* Top Up Modal */}
            {showTopUpModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-in fade-in">
                    <div className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-sm p-6 shadow-2xl animate-in zoom-in-95">
                        <h3 className="text-xl font-bold mb-4 dark:text-white">{t.actions.addFunds}</h3>
                        <form onSubmit={handleTopUpSubmit}>
                            <div className="mb-6">
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                                    {t.actions.enterAmount}
                                </label>
                                <div className="relative">
                                    <input 
                                        type="number" 
                                        value={topUpAmount}
                                        onChange={(e) => setTopUpAmount(e.target.value)}
                                        className="w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-black border border-slate-200 dark:border-slate-800 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none text-lg font-bold"
                                        placeholder="0"
                                        autoFocus
                                    />
                                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold">{t.currency}</span>
                                </div>
                            </div>
                            <div className="flex gap-3">
                                <button type="button" onClick={() => setShowTopUpModal(false)} className="flex-1 py-3 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-medium">
                                    {t.actions.cancel}
                                </button>
                                <button type="submit" className="flex-1 py-3 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700">
                                    {t.actions.confirm}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Open Card Modal */}
            {showCardModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md p-4 animate-in fade-in">
                    <div className={`bg-white dark:bg-slate-900 rounded-3xl w-full ${selectedTier === 'VIP' ? 'max-w-2xl' : 'max-w-md'} p-0 overflow-hidden shadow-2xl animate-in zoom-in-95 transition-all duration-500`}>
                        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
                            <h3 className="text-xl font-bold dark:text-white">
                                {selectedTier ? `${selectedTier} Card` : t.cardForm.selectTier}
                            </h3>
                            <button onClick={() => setShowCardModal(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors dark:text-white">
                                <X size={20} />
                            </button>
                        </div>
                        
                        <div className="p-6">
                            {!selectedTier ? (
                                <div className="space-y-4">
                                    {['Standard', 'Gold', 'VIP'].map((tier) => (
                                        <button
                                            key={tier}
                                            onClick={() => setSelectedTier(tier as any)}
                                            className={`w-full p-4 rounded-xl border-2 transition-all flex items-center justify-between group
                                                ${tier === 'Standard' ? 'border-slate-200 hover:border-blue-500 bg-slate-50' : ''}
                                                ${tier === 'Gold' ? 'border-amber-200 hover:border-amber-500 bg-amber-50' : ''}
                                                ${tier === 'VIP' ? 'border-slate-800 hover:border-black bg-slate-900 text-white' : ''}
                                            `}
                                        >
                                            <div className="flex items-center gap-4">
                                                <div className={`w-12 h-8 rounded bg-gradient-to-br shadow-sm
                                                    ${tier === 'Standard' ? 'from-blue-400 to-indigo-500' : ''}
                                                    ${tier === 'Gold' ? 'from-amber-300 to-orange-400' : ''}
                                                    ${tier === 'VIP' ? 'from-slate-700 to-black' : ''}
                                                `}></div>
                                                <div className="text-left">
                                                    <div className={`font-bold ${tier === 'VIP' ? 'text-white' : 'text-slate-800'}`}>{tier}</div>
                                                    <div className={`text-xs ${tier === 'VIP' ? 'text-slate-400' : 'text-slate-500'}`}>
                                                        {tier === 'Standard' ? 'Free' : tier === 'Gold' ? '5000 ₸ / year' : 'Premium Service'}
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                                                <ArrowUpCircle className="rotate-90" />
                                            </div>
                                        </button>
                                    ))}
                                </div>
                            ) : selectedTier === 'VIP' ? (
                                <ThreeDCardForm 
                                    t={t.cardForm} 
                                    onSubmit={confirmCardCreation}
                                    onBack={() => setSelectedTier(null)}
                                />
                            ) : (
                                <div className="text-center py-8">
                                    <div className={`w-64 h-40 mx-auto rounded-xl bg-gradient-to-br shadow-xl mb-8 relative overflow-hidden transform transition-transform hover:scale-105
                                        ${selectedTier === 'Gold' ? 'from-amber-400 to-orange-500' : 'from-blue-600 to-indigo-600'}
                                    `}>
                                        <div className="absolute top-4 left-4 font-bold text-white opacity-80">{selectedTier.toUpperCase()}</div>
                                        <div className="absolute bottom-4 left-4 text-white font-mono opacity-90">**** **** **** ****</div>
                                    </div>
                                    <p className="text-slate-500 mb-6">Confirm opening a new {selectedTier} card.</p>
                                    <div className="flex gap-3">
                                        <button onClick={() => setSelectedTier(null)} className="flex-1 py-3 bg-slate-100 text-slate-700 rounded-xl font-medium">
                                            {t.actions.cancel}
                                        </button>
                                        <button onClick={() => confirmCardCreation({})} className="flex-1 py-3 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700">
                                            {t.actions.confirm}
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

// ----------------------------------------------------------------------
// 3D Interactive Card Form Component
// ----------------------------------------------------------------------

const ThreeDCardForm = ({ t, onSubmit, onBack }: { t: any, onSubmit: (data: any) => void, onBack: () => void }) => {
    const [cardNumber, setCardNumber] = useState('');
    const [cardName, setCardName] = useState('');
    const [cardMonth, setCardMonth] = useState('MM');
    const [cardYear, setCardYear] = useState('YY');
    const [cardCvv, setCardCvv] = useState('');
    const [isFlipped, setIsFlipped] = useState(false);
    const [focusElementStyle, setFocusElementStyle] = useState<React.CSSProperties | null>(null);
    
    // Random background
    const bgIndex = useMemo(() => Math.floor(Math.random() * 25 + 1), []);

    // Format Card Number
    const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        let val = e.target.value.replace(/\D/g, '');
        if (val.length > 16) val = val.slice(0, 16);
        setCardNumber(val);
    };

    const getCardType = useMemo(() => {
        if (/^4/.test(cardNumber)) return "visa";
        if (/^5[1-5]/.test(cardNumber)) return "mastercard";
        if (/^3[47]/.test(cardNumber)) return "amex";
        if (/^6(?:011|5)/.test(cardNumber)) return "discover";
        return "visa";
    }, [cardNumber]);

    const handleSubmit = () => {
        if (cardNumber.length < 16 || !cardName || !cardCvv) {
            alert("Please fill all fields");
            return;
        }
        onSubmit({
            number: cardNumber.replace(/(\d{4})(?=\d)/g, '$1 '),
            holder: cardName,
            expiry: `${cardMonth}/${cardYear.slice(-2)}`
        });
    };

    // Styling
    const containerStyle = { perspective: '1000px' };
    const cardStyle = { 
        transformStyle: 'preserve-3d' as const, 
        transition: 'transform 0.6s cubic-bezier(0.71, 0.03, 0.56, 0.85)',
        transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)'
    };
    const frontStyle = { backfaceVisibility: 'hidden' as const, zIndex: 2, transform: 'rotateY(0deg)' };
    const backStyle = { backfaceVisibility: 'hidden' as const, zIndex: 1, transform: 'rotateY(180deg)', position: 'absolute' as const, top: 0, left: 0, width: '100%', height: '100%' };

    return (
        <div className="w-full">
            {/* Inject CSS for specific effects */}
            <style>{`
                .card-item-cover { background-image: url('https://raw.githubusercontent.com/muhammederdem/credit-card-form/master/src/assets/images/${bgIndex}.jpeg'); background-size: cover; }
            `}</style>

            {/* Visual 3D Card */}
            <div className="w-full max-w-[340px] h-[215px] mx-auto mb-10 relative" style={containerStyle}>
                <div className="w-full h-full relative rounded-xl shadow-2xl" style={cardStyle}>
                    
                    {/* Front */}
                    <div className="absolute w-full h-full rounded-xl overflow-hidden card-item-cover text-white p-5 flex flex-col justify-between shadow-lg" style={frontStyle}>
                        <div className="absolute inset-0 bg-black/30"></div>
                        
                        <div className="relative z-10 flex justify-between items-start">
                             <img src="https://raw.githubusercontent.com/muhammederdem/credit-card-form/master/src/assets/images/chip.png" className="w-12 opacity-90" />
                             <img src={`https://raw.githubusercontent.com/muhammederdem/credit-card-form/master/src/assets/images/${getCardType}.png`} className="h-8 object-contain" />
                        </div>

                        <div className="relative z-10">
                            <div className="text-2xl font-mono tracking-widest mb-6 drop-shadow-md min-h-[32px]">
                                {cardNumber ? cardNumber.replace(/(\d{4})(?=\d)/g, '$1 ') : '#### #### #### ####'}
                            </div>
                            <div className="flex justify-between">
                                <div>
                                    <div className="text-[10px] opacity-70 uppercase mb-0.5">{t.cardHolder}</div>
                                    <div className="font-medium uppercase text-sm tracking-wide">{cardName || 'FULL NAME'}</div>
                                </div>
                                <div>
                                    <div className="text-[10px] opacity-70 uppercase mb-0.5">{t.expires}</div>
                                    <div className="font-medium text-sm tracking-wide">{cardMonth}/{cardYear.slice(-2)}</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Back */}
                    <div className="absolute w-full h-full rounded-xl overflow-hidden card-item-cover" style={backStyle}>
                        <div className="absolute inset-0 bg-black/30"></div>
                        <div className="w-full h-10 bg-black/80 mt-6 relative z-10"></div>
                        <div className="p-5 relative z-10">
                            <div className="text-right text-xs text-white font-bold mb-1">{t.cvv}</div>
                            <div className="w-full bg-white h-10 rounded text-right flex items-center justify-end pr-3 text-slate-800 font-mono text-lg">
                                {cardCvv.replace(/./g, '*')}
                            </div>
                            <div className="mt-4 flex justify-end">
                                <img src={`https://raw.githubusercontent.com/muhammederdem/credit-card-form/master/src/assets/images/${getCardType}.png`} className="h-8 object-contain opacity-70" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Form Inputs */}
            <div className="space-y-4">
                <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase">{t.cardNumber}</label>
                    <input 
                        type="text" 
                        value={cardNumber} 
                        onChange={handleNumberChange}
                        onFocus={() => setIsFlipped(false)}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-black dark:text-white focus:ring-2 focus:ring-blue-500 outline-none font-mono"
                    />
                </div>
                <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase">{t.cardHolder}</label>
                    <input 
                        type="text" 
                        value={cardName} 
                        onChange={(e) => setCardName(e.target.value)}
                        onFocus={() => setIsFlipped(false)}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-black dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                </div>
                <div className="flex gap-4">
                    <div className="flex-2 w-full">
                        <label className="block text-xs font-bold text-slate-500 mb-1 uppercase">{t.expires}</label>
                        <div className="flex gap-2">
                             <select value={cardMonth} onChange={(e) => setCardMonth(e.target.value)} onFocus={() => setIsFlipped(false)} className="w-full px-2 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-black dark:text-white focus:ring-2 focus:ring-blue-500 outline-none">
                                <option disabled>MM</option>
                                {Array.from({length: 12}, (_, i) => i + 1).map(m => (
                                    <option key={m} value={m < 10 ? `0${m}` : `${m}`}>{m < 10 ? `0${m}` : m}</option>
                                ))}
                             </select>
                             <select value={cardYear} onChange={(e) => setCardYear(e.target.value)} onFocus={() => setIsFlipped(false)} className="w-full px-2 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-black dark:text-white focus:ring-2 focus:ring-blue-500 outline-none">
                                <option disabled>YY</option>
                                {Array.from({length: 10}, (_, i) => new Date().getFullYear() + i).map(y => (
                                    <option key={y} value={y}>{y}</option>
                                ))}
                             </select>
                        </div>
                    </div>
                    <div className="flex-1 w-full">
                        <label className="block text-xs font-bold text-slate-500 mb-1 uppercase">{t.cvv}</label>
                        <input 
                            type="text" 
                            maxLength={3}
                            value={cardCvv} 
                            onChange={(e) => setCardCvv(e.target.value)}
                            onFocus={() => setIsFlipped(true)}
                            onBlur={() => setIsFlipped(false)}
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-black dark:text-white focus:ring-2 focus:ring-blue-500 outline-none font-mono"
                        />
                    </div>
                </div>

                <div className="flex gap-3 pt-4">
                    <button onClick={onBack} className="flex-1 py-3 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-medium">
                        Back
                    </button>
                    <button onClick={handleSubmit} className="flex-1 py-3 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700 shadow-lg shadow-blue-500/30">
                        {t.submit}
                    </button>
                </div>
            </div>
        </div>
    );
}

export default BankView;