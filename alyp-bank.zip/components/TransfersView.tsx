
import React, { useState } from 'react';
import { Smartphone, CreditCard, Globe, ArrowRight, Clock, Check, Contact } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../utils/translations';

interface TransfersViewProps {
  lang: Language;
}

const TransfersView: React.FC<TransfersViewProps> = ({ lang }) => {
  const t = translations[lang].transfers;
  const [activeTab, setActiveTab] = useState<'phone' | 'card' | 'international'>('phone');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [amount, setAmount] = useState('');

  const handleTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
        setLoading(false);
        setSuccess(true);
        setTimeout(() => setSuccess(false), 3000);
        setAmount('');
    }, 1500);
  };

  const tabs = [
    { id: 'phone', label: t.tabs.phone, icon: <Smartphone size={20} /> },
    { id: 'card', label: t.tabs.card, icon: <CreditCard size={20} /> },
    { id: 'international', label: t.tabs.international, icon: <Globe size={20} /> },
  ];

  return (
    <div className="p-4 md:p-8 animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 dark:text-white">{t.title}</h1>

      {/* Tabs */}
      <div className="flex p-1 bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800 mb-8 overflow-x-auto">
        {tabs.map(tab => (
            <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all whitespace-nowrap
                    ${activeTab === tab.id 
                    ? 'bg-blue-600 text-white shadow-md' 
                    : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'}
                `}
            >
                {tab.icon}
                {tab.label}
            </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Form Area */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 shadow-xl border border-slate-100 dark:border-slate-800 relative overflow-hidden">
            {success && (
                <div className="absolute inset-0 bg-white/90 dark:bg-slate-900/90 backdrop-blur-sm z-20 flex flex-col items-center justify-center animate-in fade-in">
                    <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center text-green-600 dark:text-green-400 mb-4 animate-in zoom-in-50 duration-300">
                        <Check size={40} />
                    </div>
                    <h3 className="text-xl font-bold text-slate-800 dark:text-white">{t.success}</h3>
                </div>
            )}

            <form onSubmit={handleTransfer} className="space-y-6">
                
                {/* Phone Transfer Fields */}
                {activeTab === 'phone' && (
                    <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
                         <div>
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">{t.phone.label}</label>
                            <div className="relative">
                                <Smartphone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                                <input 
                                    type="tel" 
                                    placeholder={t.phone.placeholder}
                                    className="w-full pl-12 pr-4 py-4 rounded-xl bg-slate-50 dark:bg-black border border-slate-200 dark:border-slate-800 text-lg font-medium focus:ring-2 focus:ring-blue-500 outline-none dark:text-white"
                                />
                                <button type="button" className="absolute right-3 top-1/2 -translate-y-1/2 p-2 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg text-slate-400 transition-colors">
                                    <Contact size={20} />
                                </button>
                            </div>
                         </div>
                    </div>
                )}

                {/* Card Transfer Fields */}
                {activeTab === 'card' && (
                    <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
                         <div>
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">{t.card.dest}</label>
                            <div className="relative">
                                <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                                <input 
                                    type="text" 
                                    placeholder={t.card.placeholder}
                                    className="w-full pl-12 pr-4 py-4 rounded-xl bg-slate-50 dark:bg-black border border-slate-200 dark:border-slate-800 text-lg font-medium focus:ring-2 focus:ring-blue-500 outline-none dark:text-white"
                                />
                            </div>
                         </div>
                    </div>
                )}

                {/* International Fields */}
                {activeTab === 'international' && (
                    <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
                         <div className="flex gap-4">
                             <div className="flex-1">
                                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">{t.international.country}</label>
                                <select className="w-full px-4 py-4 rounded-xl bg-slate-50 dark:bg-black border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-white font-medium focus:ring-2 focus:ring-blue-500 outline-none appearance-none">
                                    <option>USA 🇺🇸</option>
                                    <option>Turkey 🇹🇷</option>
                                    <option>Russia 🇷🇺</option>
                                    <option>China 🇨🇳</option>
                                    <option>Europe 🇪🇺</option>
                                </select>
                             </div>
                             <div className="flex-1">
                                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">{t.international.method}</label>
                                <select className="w-full px-4 py-4 rounded-xl bg-slate-50 dark:bg-black border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-white font-medium focus:ring-2 focus:ring-blue-500 outline-none appearance-none">
                                    <option>{t.international.card}</option>
                                    <option>{t.international.swift}</option>
                                </select>
                             </div>
                         </div>
                         <div>
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">{t.international.name}</label>
                            <input 
                                type="text" 
                                className="w-full px-4 py-4 rounded-xl bg-slate-50 dark:bg-black border border-slate-200 dark:border-slate-800 text-lg font-medium focus:ring-2 focus:ring-blue-500 outline-none dark:text-white"
                            />
                         </div>
                    </div>
                )}

                {/* Common Fields */}
                <div>
                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">{t.amount}</label>
                    <div className="relative">
                        <input 
                            type="number" 
                            value={amount}
                            onChange={(e) => setAmount(e.target.value)}
                            placeholder="0"
                            className="w-full px-4 py-4 rounded-xl bg-slate-50 dark:bg-black border border-slate-200 dark:border-slate-800 text-2xl font-bold focus:ring-2 focus:ring-blue-500 outline-none dark:text-white"
                        />
                        <span className="absolute right-6 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-xl">₸</span>
                    </div>
                </div>

                 <div>
                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">{t.message}</label>
                    <input 
                        type="text" 
                        className="w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-black border border-slate-200 dark:border-slate-800 focus:ring-2 focus:ring-blue-500 outline-none dark:text-white"
                    />
                </div>

                <button 
                    type="submit" 
                    disabled={loading || !amount}
                    className="w-full py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl font-bold text-lg shadow-lg shadow-blue-500/30 hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    {loading ? <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"/> : <>{t.send} <ArrowRight size={20} /></>}
                </button>
            </form>
        </div>

        {/* History / Info */}
        <div className="space-y-6">
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-800">
                <div className="flex items-center justify-between mb-6">
                    <h3 className="font-bold text-lg dark:text-white flex items-center gap-2">
                        <Clock className="text-slate-400" size={20} />
                        {t.recent}
                    </h3>
                </div>
                
                <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                        <div key={i} className="flex items-center gap-4 p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer group">
                            <div className="w-12 h-12 rounded-full bg-blue-50 dark:bg-blue-900/20 flex items-center justify-center text-blue-600 dark:text-blue-400 font-bold text-lg">
                                {i === 1 ? 'A' : i === 2 ? 'K' : 'M'}
                            </div>
                            <div className="flex-1">
                                <div className="font-bold text-slate-800 dark:text-white">Alibek K.</div>
                                <div className="text-xs text-slate-500 dark:text-slate-400">Kaspi Gold • 4400</div>
                            </div>
                            <div className="text-right">
                                <div className="font-bold text-slate-800 dark:text-white">- 5,000 ₸</div>
                                <div className="text-xs text-slate-400 group-hover:text-blue-500 cursor-pointer">Replay</div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl p-6 text-white shadow-lg relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl -mr-10 -mt-10"></div>
                <h3 className="font-bold text-lg mb-2 relative z-10">AlypBank Premium</h3>
                <p className="text-indigo-100 text-sm mb-4 relative z-10">International transfers with 0% commission for VIP clients.</p>
                <button className="px-4 py-2 bg-white/20 hover:bg-white/30 backdrop-blur-sm rounded-lg text-sm font-semibold transition-colors relative z-10">Upgrade</button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default TransfersView;
