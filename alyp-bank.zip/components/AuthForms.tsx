
import React, { useState } from 'react';
import { Eye, EyeOff, Check, AlertCircle, Mail, User, Lock } from 'lucide-react';
import { ViewState, Language } from '../types';
import { translations } from '../utils/translations';

interface AuthFormsProps {
  view: 'login' | 'register';
  onSwitch: (view: ViewState) => void;
  onSuccess: (name: string, email: string) => void;
  lang: Language;
}

const AuthForms: React.FC<AuthFormsProps> = ({ view, onSwitch, onSuccess, lang }) => {
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const t = translations[lang].auth;

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setError('');
  };

  const validatePassword = (password: string): string | null => {
    if (password.length <= 6) return t.errors.passLen;
    if (password.length > 20) return t.errors.passMax;
    if (!/[A-Z]/.test(password)) return t.errors.passUpper;
    if (!/[a-z]/.test(password)) return t.errors.passLower;
    if (!/[+\-*!?]/.test(password)) return t.errors.passSpecial;
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 800));

    try {
      const users = JSON.parse(localStorage.getItem('alypbank_users') || '[]');

      if (view === 'register') {
        // Registration Validation
        if (!formData.name.trim()) throw new Error(t.errors.nameReq);
        
        // Email Validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(formData.email)) throw new Error(t.errors.emailInv);

        // Password Validation
        const pwdError = validatePassword(formData.password);
        if (pwdError) throw new Error(pwdError);

        // Confirm Password
        if (formData.password !== formData.confirmPassword) {
          throw new Error(t.errors.passMatch);
        }

        // Check if user exists
        if (users.find((u: any) => u.email === formData.email)) {
          throw new Error(t.errors.emailExists);
        }

        // Save User
        const newUser = {
          name: formData.name,
          email: formData.email,
          password: formData.password
        };
        localStorage.setItem('alypbank_users', JSON.stringify([...users, newUser]));
        
        onSuccess(newUser.name, newUser.email);
      } else {
        // Login Validation
        const user = users.find((u: any) => u.email === formData.email && u.password === formData.password);
        
        if (!user) {
          throw new Error(t.errors.loginFail);
        }

        onSuccess(user.name, user.email);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto p-6">
      <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl p-8 border border-slate-100 dark:border-slate-800 relative overflow-hidden animate-in fade-in zoom-in duration-300">
        {/* Decorative Top Bar */}
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500" />
        
        <div className="text-center mb-8">
          <img 
            src="https://i.ibb.co.com/vCN59q6B/95e7c81d-66e6-42d4-bb3e-46875952e46e.jpg" 
            alt="Alyp Bank"
            className="w-20 h-20 rounded-2xl mx-auto mb-4 shadow-lg shadow-blue-500/30 object-cover"
          />
          <h2 className="text-2xl font-bold text-slate-800 dark:text-white">
            {view === 'login' ? t.loginTitle : t.registerTitle}
          </h2>
          <p className="text-slate-500 dark:text-slate-400 mt-2">
            {view === 'login' ? t.loginSubtitle : t.registerSubtitle}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {view === 'register' && (
             <div className="space-y-1.5">
             <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">{t.name}</label>
             <div className="relative">
               <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
               <input 
                 name="name"
                 type="text" 
                 value={formData.name}
                 onChange={handleChange}
                 className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-black dark:text-white focus:bg-white dark:focus:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
                 placeholder="Alyp Bank"
               />
             </div>
           </div>
          )}

          <div className="space-y-1.5">
            <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">{t.email}</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                name="email"
                type="email" 
                value={formData.email}
                onChange={handleChange}
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-black dark:text-white focus:bg-white dark:focus:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
                placeholder="example@mail.com"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">{t.password}</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                name="password"
                type={showPassword ? "text" : "password"}
                value={formData.password}
                onChange={handleChange}
                className="w-full pl-10 pr-12 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-black dark:text-white focus:bg-white dark:focus:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
                placeholder="••••••••"
              />
              <button 
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
            {view === 'register' && (
              <p className="text-xs text-slate-400 px-1">
                {t.passwordHint}
              </p>
            )}
          </div>

          {view === 'register' && (
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">{t.confirmPassword}</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input 
                  name="confirmPassword"
                  type={showPassword ? "text" : "password"}
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-black dark:text-white focus:bg-white dark:focus:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
                  placeholder="••••••••"
                />
              </div>
            </div>
          )}

          {error && (
            <div className="flex items-start gap-2 text-red-500 text-sm p-3 bg-red-50 dark:bg-red-900/20 rounded-lg animate-in slide-in-from-top-2">
              <AlertCircle size={16} className="mt-0.5 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <button 
            type="submit" 
            disabled={loading}
            className="w-full py-3.5 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl font-semibold shadow-lg shadow-blue-500/30 hover:shadow-xl hover:shadow-blue-500/40 hover:-translate-y-0.5 active:translate-y-0 transition-all disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2 mt-4"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                {view === 'login' ? t.loginBtn : t.registerBtn}
                <div className="bg-white/20 p-1 rounded-full">
                   <Check size={14} />
                </div>
              </>
            )}
          </button>
        </form>

        <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 text-center text-sm text-slate-500 dark:text-slate-400">
          {view === 'login' ? (
            <p>
              {t.noAccount}{' '}
              <button onClick={() => {setError(''); onSwitch('register');}} className="text-blue-600 dark:text-blue-400 font-semibold hover:underline">
                {t.registerLink}
              </button>
            </p>
          ) : (
            <p>
              {t.hasAccount}{' '}
              <button onClick={() => {setError(''); onSwitch('login');}} className="text-blue-600 dark:text-blue-400 font-semibold hover:underline">
                {t.loginLink}
              </button>
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default AuthForms;
