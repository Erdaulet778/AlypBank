
import React from 'react';
import { Youtube, Send, MessageCircle, Gamepad2, Facebook, Instagram } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../utils/translations';

interface FooterProps {
    lang: Language;
}

const Footer: React.FC<FooterProps> = ({ lang }) => {
  const t = translations[lang].footer;

  return (
    <footer className="relative mt-24 bg-gradient-to-br from-blue-900 to-indigo-900 text-white overflow-hidden">
        {/* Background Overlay */}
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
        
        <div className="relative max-w-7xl mx-auto px-6 py-16">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
                <div className="space-y-6">
                    <div className="flex items-center gap-3">
                        <img 
                            src="https://i.ibb.co.com/vCN59q6B/95e7c81d-66e6-42d4-bb3e-46875952e46e.jpg" 
                            alt="Alyp Bank"
                            className="w-10 h-10 rounded-xl object-cover"
                        />
                        <span className="font-bold text-xl">Alyp Bank</span>
                    </div>
                    <p className="text-blue-200 text-sm leading-relaxed">
                        {t.desc}
                    </p>
                    <div className="flex gap-4">
                        <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/20 hover:scale-110 transition-all text-blue-200 hover:text-white">
                            <Youtube size={18} />
                        </a>
                        <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/20 hover:scale-110 transition-all text-blue-200 hover:text-white">
                            <Instagram size={18} />
                        </a>
                        <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/20 hover:scale-110 transition-all text-blue-200 hover:text-white">
                            <Facebook size={18} />
                        </a>
                    </div>
                </div>

                <div>
                    <h3 className="font-bold text-lg mb-6">{t.projects}</h3>
                    <ul className="space-y-4 text-sm text-blue-200">
                        <li><a href="#" className="hover:text-white hover:translate-x-2 transition-all inline-block">🤝 {t.links.trade}</a></li>
                        <li><a href="#" className="hover:text-white hover:translate-x-2 transition-all inline-block">🚗 {t.links.auto}</a></li>
                        <li><a href="#" className="hover:text-white hover:translate-x-2 transition-all inline-block">🧳 {t.links.travel}</a></li>
                        <li><a href="#" className="hover:text-white hover:translate-x-2 transition-all inline-block">🛒 {t.links.market}</a></li>
                    </ul>
                </div>

                <div>
                    <h3 className="font-bold text-lg mb-6">{t.clients}</h3>
                    <ul className="space-y-4 text-sm text-blue-200">
                        <li><a href="#" className="hover:text-white hover:translate-x-2 transition-all inline-block">{t.links.tariffs}</a></li>
                        <li><a href="#" className="hover:text-white hover:translate-x-2 transition-all inline-block">{t.links.security}</a></li>
                        <li><a href="#" className="hover:text-white hover:translate-x-2 transition-all inline-block">{t.links.map}</a></li>
                        <li><a href="#" className="hover:text-white hover:translate-x-2 transition-all inline-block">{t.links.feedback}</a></li>
                    </ul>
                </div>

                <div>
                    <h3 className="font-bold text-lg mb-6">{t.contact}</h3>
                    <ul className="space-y-4 text-sm text-blue-200">
                        <li className="flex items-start gap-3">
                            <span className="opacity-70">Call-center:</span>
                            <span className="font-semibold text-white">7711</span>
                        </li>
                        <li className="flex items-start gap-3">
                            <span className="opacity-70">Email:</span>
                            <span className="font-semibold text-white">info@alypbank.kz</span>
                        </li>
                        <li className="text-xs opacity-60 pt-4 border-t border-white/10">
                            Алматы қ., Абай даңғылы 10, <br/> "Алып" БО, 1-қабат
                        </li>
                    </ul>
                </div>
            </div>

            <div className="pt-8 border-t border-white/10 text-center text-sm text-blue-300/60">
                <p>&copy; {new Date().getFullYear()} Alyp Bank. {t.rights}</p>
            </div>
        </div>
    </footer>
  );
};

export default Footer;
