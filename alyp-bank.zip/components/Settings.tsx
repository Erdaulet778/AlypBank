import React, { useState } from 'react';
import { User, Lock, Moon, Sun, Save, AlertCircle, Check, Palette } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../utils/translations';

interface SettingsProps {
  currentUserEmail: string;
  isDarkMode: boolean;
  toggleTheme: () => void;
  onProfileUpdate: (newName: string, newEmail: string) => void;
  lang: Language;
  setLang: (l: Language) => void;
}

const Settings: React.FC<SettingsProps> = ({ currentUserEmail, isDarkMode, toggleTheme, onProfileUpdate, lang, setLang }) => {
  const t = translations[lang].settings;
  const tAuth = translations[lang].auth;

  // Load current user data
  const users = JSON.parse(localStorage.getItem('alypbank_users') || '[]');
  const currentUser = users.find((u: any) => u.email === currentUserEmail) || {};

  const [formData, setFormData] = useState({
    name: currentUser.name || '',
    email: currentUser.email || '',
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const [message, setMessage] = useState({ type: '', text: '' });
  const [loading, setLoading] = useState(false);

  // Accent Color State (managed by body class)
  const colors = [
    { id: 'theme-blue', color: 'bg-blue-600', label: 'Blue' },
    { id: 'theme-purple', color: 'bg-purple-600', label: 'Purple' },
    { id: 'theme-emerald', color: 'bg-emerald-600', label: 'Emerald' },
    { id: 'theme-rose', color: 'bg-rose-600', label: 'Rose' },
  ];

  const changeAccent = (themeId: string) => {
      document.body.className = document.body.className.replace(/theme-\w+/, '');
      document.body.classList.add(themeId);
      localStorage.setItem('accentTheme', themeId);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setMessage({ type: '', text: '' });
  };

  const validatePassword = (password: string): string | null => {
    if (password.length <= 6) return tAuth.errors.passLen;
    if (password.length > 20) return tAuth.errors.passMax;
    if (!/[A-Z]/.test(password)) return tAuth.errors.passUpper;
    if (!/[a-z]/.test(password)) return tAuth.errors.passLower;
    if (!/[+\-*!?]/.test(password)) return tAuth.errors.passSpecial;
    return null;
  };

  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    setTimeout(() => {
      try {
        const allUsers = JSON.parse(localStorage.getItem('alypbank_users') || '[]');
        const userIndex = allUsers.findIndex((u: any) => u.email === currentUserEmail);

        if (userIndex === -1) throw new Error(t.errorUserNotFound);

        // Update fields if changed
        allUsers[userIndex].name = formData.name;
        
        // If email changed, check for duplicates
        if (formData.email !== currentUserEmail) {
            if (allUsers.find((u: any) => u.email === formData.email)) {
                throw new Error(t.errorEmailExists);
            }
            allUsers[userIndex].email = formData.email;
        }

        localStorage.setItem('alypbank_users', JSON.stringify(allUsers));
        onProfileUpdate(formData.name, formData.email);
        setMessage({ type: 'success', text: t.successProfile });
      } catch (err: any) {
        setMessage({ type: 'error', text: err.message });
      } finally {
        setLoading(false);
      }
    }, 500);
  };

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    setTimeout(() => {
      try {
        const allUsers = JSON.parse(localStorage.getItem('alypbank_users') || '[]');
        const userIndex = allUsers.findIndex((u: any) => u.email === currentUserEmail);

        if (userIndex === -1) throw new Error(t.errorUserNotFound);
        
        // Verify old password
        if (allUsers[userIndex].password !== formData.currentPassword) {
            throw new Error(t.errorOldPass);
        }

        // Validate new password
        const pwdError = validatePassword(formData.newPassword);
        if (pwdError) throw new Error(pwdError);

        if (formData.newPassword !== formData.confirmPassword) {
            throw new Error(t.errorPassMatch);
        }

        // Update
        allUsers[userIndex].password = formData.newPassword;
        localStorage.setItem('alypbank_users', JSON.stringify(allUsers));
        
        setFormData(prev => ({ ...prev, currentPassword: '', newPassword: '', confirmPassword: '' }));
        setMessage({ type: 'success', text: t.successPassword });
      } catch (err: any) {
        setMessage({ type: 'error', text: err.message });
      } finally {
        setLoading(false);
      }
    }, 500);
  };

  return (
    <div className="p-4 md:p-8 animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-6xl mx-auto">
      <h1 className="text-4xl font-extrabold mb-8 dark:text-white tracking-tight">{t.title}</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Left Column: Theme & Profile */}
        <div className="space-y-8">
            {/* Visual Customization Card */}
            <div className="glass rounded-3xl p-8 shadow-xl">
                <div className="flex items-center gap-3 mb-6">
                    <div className="p-3 bg-accent-100 dark:bg-accent-900/30 rounded-xl text-accent-600">
                        <Palette size={24} />
                    </div>
                    <div>
                        <h3 className="text-xl font-bold dark:text-white">{t.appearance}</h3>
                        <p className="text-slate-500 text-sm">Customize your experience</p>
                    </div>
                </div>

                {/* Dark Mode */}
                <div className="flex items-center justify-between mb-8 p-4 bg-white/50 dark:bg-black/20 rounded-2xl border border-white/40 dark:border-white/5">
                    <span className="font-medium dark:text-slate-200">{t.themeDesc}</span>
                    <button 
                        onClick={toggleTheme}
                        className={`p-3 rounded-full transition-all duration-500 transform hover:scale-110 ${isDarkMode ? 'bg-slate-800 text-yellow-400 shadow-[0_0_15px_rgba(250,204,21,0.3)]' : 'bg-white text-orange-500 shadow-md'}`}
                    >
                        {isDarkMode ? <Moon size={24} fill="currentColor" /> : <Sun size={24} fill="currentColor" />}
                    </button>
                </div>

                {/* Accent Colors */}
                <div className="mb-8">
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-3">Accent Color</label>
                    <div className="flex gap-4">
                        {colors.map(c => (
                            <button
                                key={c.id}
                                onClick={() => changeAccent(c.id)}
                                className={`w-12 h-12 rounded-full ${c.color} shadow-lg transition-transform hover:scale-110 hover:shadow-xl ring-2 ring-offset-2 ring-transparent focus:ring-slate-400`}
                                title={c.label}
                            />
                        ))}
                    </div>
                </div>

                {/* Language */}
                <div>
                     <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-3">{t.language}</label>
                     <div className="flex items-center gap-2 bg-slate-100 dark:bg-black/40 p-1.5 rounded-xl">
                        {(['kk', 'ru', 'en'] as const).map(l => (
                            <button 
                                key={l}
                                onClick={() => setLang(l)} 
                                className={`flex-1 py-2.5 rounded-lg text-sm font-bold transition-all ${lang === l ? 'bg-white dark:bg-accent-600 text-accent-600 dark:text-white shadow-md' : 'text-slate-500 dark:text-slate-400 hover:text-slate-800'}`}
                            >
                                {l.toUpperCase()}
                            </button>
                        ))}
                    </div>
                </div>
            </div>

            {/* Profile Edit */}
            <div className="glass rounded-3xl p-8 shadow-xl">
                <div className="flex items-center gap-3 mb-6">
                    <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-xl text-blue-600">
                        <User size={24} />
                    </div>
                    <h3 className="text-xl font-bold dark:text-white">{t.profile}</h3>
                </div>
                
                <form onSubmit={handleUpdateProfile} className="space-y-5">
                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 ml-1">{tAuth.name}</label>
                        <input 
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            className="w-full px-5 py-3.5 rounded-2xl border-none bg-slate-50 dark:bg-black/50 dark:text-white focus:outline-none focus:ring-2 focus:ring-accent-500 transition-shadow shadow-inner"
                        />
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 ml-1">{tAuth.email}</label>
                        <input 
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            className="w-full px-5 py-3.5 rounded-2xl border-none bg-slate-50 dark:bg-black/50 dark:text-white focus:outline-none focus:ring-2 focus:ring-accent-500 transition-shadow shadow-inner"
                        />
                    </div>
                    <button disabled={loading} className="w-full py-4 bg-accent-600 text-white rounded-2xl font-bold hover:bg-accent-500 transition-colors shadow-lg shadow-accent-500/30 flex items-center justify-center gap-2 mt-4">
                        <Save size={20} /> {t.save}
                    </button>
                </form>
            </div>
        </div>

        {/* Right Column: Security */}
        <div className="glass rounded-3xl p-8 shadow-xl h-fit">
             <div className="flex items-center gap-3 mb-6">
                 <div className="p-3 bg-red-100 dark:bg-red-900/30 rounded-xl text-red-600">
                    <Lock size={24} />
                 </div>
                 <h3 className="text-xl font-bold dark:text-white">{t.security}</h3>
             </div>

            <form onSubmit={handleChangePassword} className="space-y-5">
                <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 ml-1">{t.oldPassword}</label>
                    <input 
                        type="password"
                        name="currentPassword"
                        value={formData.currentPassword}
                        onChange={handleChange}
                        className="w-full px-5 py-3.5 rounded-2xl border-none bg-slate-50 dark:bg-black/50 dark:text-white focus:outline-none focus:ring-2 focus:ring-red-500 transition-shadow shadow-inner"
                    />
                </div>
                <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 ml-1">{t.newPassword}</label>
                    <input 
                        type="password"
                        name="newPassword"
                        value={formData.newPassword}
                        onChange={handleChange}
                        className="w-full px-5 py-3.5 rounded-2xl border-none bg-slate-50 dark:bg-black/50 dark:text-white focus:outline-none focus:ring-2 focus:ring-red-500 transition-shadow shadow-inner"
                    />
                     <p className="text-xs text-slate-400 mt-2 ml-1">
                        {tAuth.passwordHint}
                    </p>
                </div>
                <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 ml-1">{t.confirmPassword}</label>
                    <input 
                        type="password"
                        name="confirmPassword"
                        value={formData.confirmPassword}
                        onChange={handleChange}
                        className="w-full px-5 py-3.5 rounded-2xl border-none bg-slate-50 dark:bg-black/50 dark:text-white focus:outline-none focus:ring-2 focus:ring-red-500 transition-shadow shadow-inner"
                    />
                </div>
                
                {message.text && (
                    <div className={`flex items-center gap-2 p-4 rounded-xl text-sm font-medium ${message.type === 'error' ? 'bg-red-50 text-red-600 dark:bg-red-900/20 dark:text-red-300' : 'bg-green-50 text-green-600 dark:bg-green-900/20 dark:text-green-300'}`}>
                        {message.type === 'error' ? <AlertCircle size={18} /> : <Check size={18} />}
                        {message.text}
                    </div>
                )}

                <button disabled={loading} className="w-full py-4 bg-slate-800 dark:bg-white dark:text-slate-900 text-white rounded-2xl font-bold hover:bg-slate-700 dark:hover:bg-slate-200 transition-colors shadow-lg flex items-center justify-center gap-2 mt-4">
                    <Lock size={20} /> {t.updatePassword}
                </button>
            </form>
        </div>
      </div>
    </div>
  );
};

export default Settings;