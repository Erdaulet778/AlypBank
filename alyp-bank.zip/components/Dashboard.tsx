
import React, { useState } from 'react';
import { Gift, TrendingUp, TrendingDown, ArrowUpRight, Plus } from 'lucide-react';
import { translations } from '../utils/translations';
import { Language } from '../types';

interface DashboardProps {
    userName: string;
    lang: Language;
}

const Dashboard: React.FC<DashboardProps> = ({ userName, lang }) => {
    const t = translations[lang].dashboard;
    const [spinning, setSpinning] = useState(false);
    const [reward, setReward] = useState<string | null>(null);

    // Get time-based greeting
    const hour = new Date().getHours();
    let greeting = 'Good Day';
    if (hour < 12) greeting = 'Good Morning';
    else if (hour < 18) greeting = 'Good Afternoon';
    else greeting = 'Good Evening';

    if (lang === 'kk') greeting = hour < 12 ? 'Қайырлы таң' : hour < 18 ? 'Қайырлы күн' : 'Қайырлы кеш';
    if (lang === 'ru') greeting = hour < 12 ? 'Доброе утро' : hour < 18 ? 'Добрый день' : 'Добрый вечер';

    const handleSpin = () => {
        if (spinning || reward) return;
        setSpinning(true);
        
        // Simple mock spin logic
        setTimeout(() => {
            setSpinning(false);
            const rewards = ['50 Bonus Points', '1% Cashback', 'Free Transfer', '100 ₸'];
            setReward(rewards[Math.floor(Math.random() * rewards.length)]);
        }, 2000);
    };

    return (
        <div className="p-4 md:p-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Header / Greeting */}
            <div className="mb-10 flex flex-col md:flex-row md:items-end justify-between gap-4">
                <div>
                    <h2 className="text-xl text-slate-500 dark:text-slate-400 font-medium mb-1">{greeting},</h2>
                    <h1 className="text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                        {userName} <span className="animate-pulse-slow">👋</span>
                    </h1>
                </div>
                <div className="flex items-center gap-3 bg-white dark:bg-slate-900 p-2 pr-4 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800">
                    <img 
                        src="https://i.ibb.co.com/vCN59q6B/95e7c81d-66e6-42d4-bb3e-46875952e46e.jpg" 
                        alt="Alyp Bank"
                        className="w-10 h-10 rounded-xl object-cover"
                    />
                    <div>
                        <div className="text-xs text-slate-500 font-bold uppercase tracking-wider">Alyp Score</div>
                        <div className="text-lg font-bold text-slate-800 dark:text-white">850 <span className="text-green-500 text-sm">Excellent</span></div>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                
                {/* Main Card (Glassmorphism) */}
                <div className="lg:col-span-2 space-y-8">
                    <div className="relative h-64 rounded-[2.5rem] bg-gradient-to-br from-slate-900 to-black text-white p-8 overflow-hidden shadow-2xl group transition-transform hover:scale-[1.01]">
                         {/* Animated Mesh Gradient Background */}
                         <div className="absolute top-0 left-0 w-full h-full opacity-40">
                             <div className="absolute top-[-50%] left-[-20%] w-[500px] h-[500px] bg-accent-600/50 rounded-full blur-[100px] animate-blob" />
                             <div className="absolute bottom-[-20%] right-[-20%] w-[400px] h-[400px] bg-purple-600/50 rounded-full blur-[100px] animate-blob animation-delay-2000" />
                         </div>

                         {/* Card Content */}
                         <div className="relative z-10 flex flex-col justify-between h-full">
                             <div className="flex justify-between items-start">
                                 <div>
                                     <p className="text-slate-400 font-medium mb-1">Total Balance</p>
                                     <h3 className="text-4xl font-bold tracking-tight">₸ 2,450,000.00</h3>
                                 </div>
                                 <div className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center">
                                     <ArrowUpRight className="text-white" />
                                 </div>
                             </div>

                             <div className="flex justify-between items-end">
                                 <div className="flex gap-2">
                                     <div className="w-10 h-6 rounded bg-white/20 backdrop-blur-sm" />
                                     <div className="w-14 h-6 rounded bg-white/20 backdrop-blur-sm" />
                                 </div>
                                 <div className="text-right">
                                     <p className="text-sm text-slate-400 mb-1">Universal Card</p>
                                     <p className="font-mono text-xl tracking-widest">•••• 4589</p>
                                 </div>
                             </div>
                         </div>
                    </div>

                    {/* Stats Row */}
                    <div className="grid grid-cols-2 gap-4">
                        <div className="glass p-6 rounded-3xl hover:-translate-y-1 transition-transform cursor-pointer">
                             <div className="flex items-center gap-3 mb-4">
                                 <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-full text-green-600">
                                     <TrendingUp size={20} />
                                 </div>
                                 <span className="text-sm font-bold text-slate-500">Income</span>
                             </div>
                             <div className="text-2xl font-bold dark:text-white">+ 450,000 ₸</div>
                        </div>
                        <div className="glass p-6 rounded-3xl hover:-translate-y-1 transition-transform cursor-pointer">
                             <div className="flex items-center gap-3 mb-4">
                                 <div className="p-2 bg-red-100 dark:bg-red-900/30 rounded-full text-red-600">
                                     <TrendingDown size={20} />
                                 </div>
                                 <span className="text-sm font-bold text-slate-500">Expense</span>
                             </div>
                             <div className="text-2xl font-bold dark:text-white">- 120,500 ₸</div>
                        </div>
                    </div>
                </div>

                {/* Right Column: Gamification & Quick Actions */}
                <div className="space-y-8">
                    
                    {/* Daily Bonus Widget */}
                    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-accent-500 to-purple-600 text-white p-6 shadow-xl text-center">
                         <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10" />
                         
                         <div className="relative z-10">
                             <div className="w-16 h-16 mx-auto bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mb-4 shadow-lg shadow-black/10">
                                 <Gift size={32} className={`${spinning ? 'animate-spin' : 'animate-bounce'}`} />
                             </div>
                             <h3 className="text-xl font-bold mb-2">Daily Bonus</h3>
                             
                             {reward ? (
                                 <div className="py-3 bg-white text-accent-600 font-bold rounded-xl animate-in zoom-in">
                                     🎉 {reward}
                                 </div>
                             ) : (
                                 <>
                                     <p className="text-accent-100 text-sm mb-4">Spin to win cashback or points!</p>
                                     <button 
                                         onClick={handleSpin}
                                         disabled={spinning}
                                         className="w-full py-3 bg-white text-accent-600 font-bold rounded-xl hover:bg-accent-50 transition-colors shadow-lg active:scale-95 disabled:opacity-70"
                                     >
                                         {spinning ? 'Spinning...' : 'Spin Now'}
                                     </button>
                                 </>
                             )}
                         </div>
                    </div>

                    {/* Quick Transfer Targets */}
                    <div className="glass p-6 rounded-3xl">
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="font-bold dark:text-white">Quick Send</h3>
                            <button className="text-accent-500 text-sm font-bold">See All</button>
                        </div>
                        <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2">
                             <div className="flex flex-col items-center gap-2 cursor-pointer group">
                                 <div className="w-14 h-14 rounded-full border-2 border-dashed border-slate-300 dark:border-slate-700 flex items-center justify-center text-slate-400 group-hover:border-accent-500 group-hover:text-accent-500 transition-colors">
                                     <Plus size={24} />
                                 </div>
                                 <span className="text-xs font-medium text-slate-500">Add</span>
                             </div>
                             {[1, 2, 3].map(i => (
                                 <div key={i} className="flex flex-col items-center gap-2 cursor-pointer group">
                                     <div className="w-14 h-14 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden ring-2 ring-transparent group-hover:ring-accent-500 transition-all">
                                         <img src={`https://i.pravatar.cc/150?img=${i + 10}`} alt="User" className="w-full h-full object-cover" />
                                     </div>
                                     <span className="text-xs font-medium dark:text-slate-300">User {i}</span>
                                 </div>
                             ))}
                        </div>
                    </div>

                </div>
            </div>
        </div>
    );
};

export default Dashboard;
